package com.mlmc.test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;

import com.ford.ftcp.util.StringUtil;
import com.ford.ftcp.util.SyncpUtil;
import com.ford.ftcp.v305.FTCP3;
import com.ford.ftcp.v305.FTCP3.AuthStatusEnum;
import com.ford.ftcp.v305.FTCP3.ClearLowTirePressureAlert;
import com.ford.ftcp.v305.FTCP3.CommonFromVehicle;
import com.ford.ftcp.v305.FTCP3.HECDateTime;
import com.ford.ftcp.v305.FTCP3.ModuleMetadata;
import com.ford.ftcp.v305.FTCP3.ProvisioningAlert;
import com.ford.ftcp.v305.FTCP3.ProvisioningData;
import com.ford.ftcp.v305.FTCP3.TCUAlert;
import com.ford.ftcp.v305.FTCP3.TCUCommand;
import com.ford.ftcp.v305.FTCP3.TCUConnectionStatusAlert;
import com.ford.ftcp.v305.FTCP3.TCUConnectionStatusAlert.TCUConnectionStatusEnum;
import com.ford.ftcp.v305.FTCP3.TCUGenericAlert;
import com.ford.ftcp.v305.FTCP3.TCUNonGenericAlert;
import com.ford.ftcp.v305.FTCP3.UTCDateTime;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

public class TCUClient305UPG_Provisioning {

//	Hi Sandy, Alan,
//	 
//	Here are the ESN you can try for the tests from China on Monday in MSQA FB1 China I1.
//	 
//	E0327501
//	E0327506
//	E0327507
//	E0327508
//	E0327514
//	 
//	For each of these you may use the below PSKey and MQTT –
//	 
//	PSKey –
//	i3c+MIxhRtjRnBpU1c6dXA==
//	 
//	MQTT –
//	4wN5e6mQ0kkuL0f/nQ7caw==
	
	public static void main(String[] args) throws Exception {
		String esn = "E9650001";
		final String psKey = "i3c+MIxhRtjRnBpU1c6dXA==";
		String mqttPsw = "4wN5e6mQ0kkuL0f/nQ7caw==";
/*		String esn = "T4860034";
		String psKey = "E6K58hHWL4WIFgARcVDIQQ==";
		String mqttPsw = "PvX72hsnYtCPmvLbHonC6w==";*/
		
		/*String esn = "H1000005";
		String psKey = "kZ8MQD1d8Iqm2biTUhFprN==";
		String mqttPsw = "81g5fgGunBi1kWiLjkqdyQ==";*/
		
		/*String esn = "T4CF0052";
		String psKey = "ofpKs1sE0Ye172EKLNkEcw==";
		String mqttPsw = "CPI5gJdy1T7KL394tK+bhg==";*/
		
		/*String esn = "T4860029";
		String psKey = "h7Qx9UVgF2jPJJPSLKIpKg==";
		String mqttPsw = "XMd/kVB9SQaxG/MC8o6vSQ==";*/
		
		/*String esn = "T4860025";
		String psKey = "Riduc1Mc4U9vJhZaev36ew==";
		String mqttPsw = "QMM2VareTyJQxKr+RjuyYQ==";*/
		
		/*String esn = "T4CF0028";
		String psKey = "SVyGr0ba1e6Zof7hNF7iQg==";
		String mqttPsw = "XOKK+cZPoWAJoMPjcDJCSw==";*/
		
		String vin = "5LMCJ2AN0FUJ10556";
//		String vin = "5LMCJ2ANXFUJ16493";
		String region = "CN";
		String MQTT_URL = "tcp://meus0001vehups2qa.cloudapp.net:1883";//"tcp://fcne0001vehqa.chinacloudapp.cn:1883";//"tcp://Mqa1cnveh.cv.ford.com:1883";//"tcp://mqa1cnveh.cv.ford.com:1883";//
		
		MqttConnectOptions _mqttConnOpt = new MqttConnectOptions();
		_mqttConnOpt.setCleanSession(false);
		_mqttConnOpt.setConnectionTimeout(30);
		_mqttConnOpt.setKeepAliveInterval(30);
		_mqttConnOpt.setUserName(esn);
		_mqttConnOpt.setPassword(mqttPsw.toCharArray());
        
		MqttDefaultFilePersistence dataStore = new MqttDefaultFilePersistence("C:\\temp");
		MqttAsyncClient mqttclient = new MqttAsyncClient(MQTT_URL, vin, dataStore);
		
		IMqttToken mqttConnToken = mqttclient.connect(_mqttConnOpt);
		
		try
		{
			mqttConnToken.waitForCompletion();
			System.out.println("--------------- TCU Simulator connect to MQTT successfully.");
		} // end-try
		catch (MqttException mqttex)
		{
			if (mqttclient != null)
			{
				mqttclient.close();
				mqttclient = null;
			} // end-if
			throw mqttex;
		} // end-catch
		
		mqttclient.setCallback(new MqttCallback() {
			
			@Override
			public void messageArrived(String topicName, MqttMessage msg) throws Exception {
				System.out.println("+++++: " + topicName + new Date());
				
				byte[] syncpBytes = msg.getPayload();
				
				System.out.println("+++++Payload(HexString): " + StringUtil.bytesToHexString(syncpBytes));
				byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(syncpBytes, psKey);
				System.out.println("+++++Syncpayload(HexString): " + StringUtil.bytesToHexString(decodedBytes));
				
				if (topicName.contains("TCU_COMMAND")) {
					TCUCommand tucCommand = TCUCommand.parseFrom(decodedBytes);
					ByteString homeURL = tucCommand.getTimeSensitiveCommand().getChangeHomeURLCommand().getHomeURL();
					
					System.out.println(tucCommand);
					String s = new String(homeURL.toByteArray());
					System.out.println(s);
				} 
			}
			
			@Override
			public void deliveryComplete(IMqttDeliveryToken arg0) {
				System.out.println("deliveryComplete" + new Date());
			}
			
			@Override
			public void connectionLost(Throwable arg0) {
				
			}
		});

		List<String> needToSubList = StringUtil.createTCUSubcribeTopics(region, vin);
		
		for(String topic : needToSubList) {
			mqttclient.subscribe(topic, 2);
			System.out.println("Subcribe to topic: " + topic);
		}
		
		String topicAlert = StringUtil.getPublishTopic(region, vin, "TCU_ALERT");
		/*	String topicConnectAlert = StringUtil.getPublishTopic(region, vin, "TCU_CONNECTION_STATUS_ALERT");
		
		byte[] cmdBytes = buildTCUConnectionStatusAlert(esn, vin);//getProvisioningAlert(esn, vin);//getClearLowTirePressure(esn, vin);//buildTCUConnectionStatusAlert();//buildAlert(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_DATA_MONITOR_VALUE, FTCP3.TCUAlert.AlertType.NON_GENERIC_VALUE);
		
		byte[] bytesToPublish = SyncpUtil.encodeSyncpPacket(cmdBytes, esn, psKey);
		System.out.println(StringUtil.bytesToHexString(bytesToPublish));
		mqttclient.publish(topicConnectAlert, new MqttMessage(bytesToPublish));
		System.out.println(topicConnectAlert);*/
		
		byte[] cmdBytes1 = getProvisioningAlert(esn, vin, esn, esn);//getClearLowTirePressure(esn, vin);//getClearLowTirePressure(esn, vin);//buildTCUConnectionStatusAlert();//buildAlert(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_DATA_MONITOR_VALUE, FTCP3.TCUAlert.AlertType.NON_GENERIC_VALUE);
		byte[] bytesToPublish1 = SyncpUtil.encodeSyncpPacket(cmdBytes1, esn, psKey);
		System.out.println(StringUtil.bytesToHexString(bytesToPublish1));
		IMqttDeliveryToken token = mqttclient.publish(topicAlert, new MqttMessage(bytesToPublish1));
		System.out.println(topicAlert);
		
		
	}

	public static byte[] buildTCUConnectionStatusAlert(String esn, String vin)
			throws InvalidProtocolBufferException 
	{
		TCUConnectionStatusAlert.Builder tcuAlertBuilder = TCUConnectionStatusAlert.newBuilder();
		
		CommonFromVehicle.Builder commonFromVehicleBuilder = buildVehicleCommon(esn, vin);
//		VehicleStatus.Builder vehicleStatus = buildVehicleStatus();

		tcuAlertBuilder.setConnectionStatus(TCUConnectionStatusEnum.CONNECTED);
		tcuAlertBuilder.setVehicleCommon(commonFromVehicleBuilder.build());

		TCUConnectionStatusAlert tcuAlert = tcuAlertBuilder.build();
		
		//System.out.println(tcuAlert);
		byte alertBytes[] = tcuAlert.toByteArray();
		StringBuilder sb = new StringBuilder();
		for (byte by : alertBytes) 
		{
	        sb.append(String.format("%02X ", by));
	    }
		return tcuAlert.toByteArray();
	}
	
	public static byte[] getClearLowTirePressure(String esn, String vin) {
		TCUAlert.Builder tcuAlertBuilder = TCUAlert.newBuilder();
		tcuAlertBuilder.setAlertType(FTCP3.TCUAlert.AlertType.GENERIC);
		TCUGenericAlert.Builder tcuGenericAlertBuilder = TCUGenericAlert.newBuilder();
		tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.CLEAR_LOW_TIRE_PRESSURE);
		ClearLowTirePressureAlert.Builder clearLowTirePressureAlertBuilder = ClearLowTirePressureAlert.newBuilder();
		
		CommonFromVehicle.Builder commonFromVehicleBuilder = buildVehicleCommon(esn, vin);
		
		clearLowTirePressureAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
		tcuGenericAlertBuilder.setClrLowTirePressureAlert(clearLowTirePressureAlertBuilder);
		
		tcuAlertBuilder.setGenericAlert(tcuGenericAlertBuilder);
		
		TCUAlert tcuAlert = tcuAlertBuilder.build();
		
		byte alertBytes[] = tcuAlert.toByteArray();
		StringBuilder sb = new StringBuilder();
		for (byte by : alertBytes) 
		{
	        sb.append(String.format("%02X ", by));
	    }
		return tcuAlert.toByteArray();
	}
	
	public static byte[] getProvisioningAlert(String esn, String vin, String IMEI, String MSISDN) {
		TCUAlert.Builder tcuAlertBuilder = TCUAlert.newBuilder();
		tcuAlertBuilder.setAlertType(TCUAlert.AlertType.NON_GENERIC);
		TCUNonGenericAlert.Builder tcuNonGenericAlertBuilder = TCUNonGenericAlert.newBuilder();
		tcuNonGenericAlertBuilder.setNonGenericAlertName(TCUNonGenericAlert.NonGenericAlertNameEnum.PROVISIONING);
		ProvisioningAlert.Builder provisioningAlertBuilder = ProvisioningAlert.newBuilder();

		CommonFromVehicle.Builder commonFromVehicleBuilder = buildVehicleCommon4Provisioning(esn, vin, esn);
		provisioningAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
		ModuleMetadata.Builder moduleMetadata = ModuleMetadata.newBuilder();
		moduleMetadata.setHardwarePartNumber("FA1T-14G145-AA");
		moduleMetadata.setFirmwareVersion("1.2.5");
		moduleMetadata.setStrategyPartNumber("FA1T-14G139-BB");
		moduleMetadata.setGlobalConfigVersion("2.1.10.m");
		moduleMetadata.setConfigPartNumber("FA1T-14G144-BBA");
		moduleMetadata.setAssemblyPartNumber("FA1T-14G087-AC");
		moduleMetadata.setCANDatabaseVersion("R32d");
		
		provisioningAlertBuilder.setModuleMetadata(moduleMetadata);
		
		ProvisioningData.Builder provisioningDataBuilder = ProvisioningData.newBuilder();
		provisioningDataBuilder.setImei(IMEI);
		provisioningDataBuilder.setSimMsisdn(MSISDN);
		provisioningDataBuilder.setSimImsi("460011092629070");
		provisioningDataBuilder.setFirmwareVersionTeseo2("2.1.1");
		provisioningDataBuilder.setFirmwareVersionHe920("1.1.2");
		provisioningDataBuilder.setBusArchitecture(4);
		provisioningDataBuilder.setDestinationRegionCode("CN");
		provisioningAlertBuilder.setProvisioningData(provisioningDataBuilder);

		tcuNonGenericAlertBuilder.setProvisioningAlert(provisioningAlertBuilder);
		
		tcuAlertBuilder.setNonGenericAlert(tcuNonGenericAlertBuilder);
		TCUAlert tcuAlert = tcuAlertBuilder.build();
		System.out.println(tcuAlert);
		byte alertBytes[] = tcuAlert.toByteArray();
		StringBuilder sb = new StringBuilder();
		for (byte by : alertBytes) 
		{
	        sb.append(String.format("%02X ", by));
	    }
		return tcuAlert.toByteArray();
	}
	
	
	public static CommonFromVehicle.Builder buildVehicleCommon4Provisioning(String esn, String vin, String ICCID)
	{
		UTCDateTime.Builder utcDateTimeBuilder = UTCDateTime.newBuilder();
		CommonFromVehicle.Builder commonFromVehicleBuilder = CommonFromVehicle.newBuilder();
		
		commonFromVehicleBuilder.setModemUTCDateTime(buildUTCDateTime(utcDateTimeBuilder));
		commonFromVehicleBuilder.setVin(vin);
		commonFromVehicleBuilder.setEsn(esn);
		commonFromVehicleBuilder.setIccid(ICCID);
		/*commonFromVehicleBuilder.setHardwarePartNumber("FA1T-14G145-AA");
		commonFromVehicleBuilder.setFirmwareVersion("1.2.4");
		commonFromVehicleBuilder.setAssemblyPartNumber("FA1T-14G087-AC");
		commonFromVehicleBuilder.setStrategyPartNumber("FA1T-14G139-BA");
		commonFromVehicleBuilder.setGlobalConfigVersion("2.1.9.m");
		commonFromVehicleBuilder.setConfigPartNumber("FA1T-14G144-BA");*/
		commonFromVehicleBuilder.setTcuMessageId(1431656473);
		commonFromVehicleBuilder.setCorrelationId(0);
		commonFromVehicleBuilder.setAuthStatus(AuthStatusEnum.UNPROVISIONED);
//		commonFromVehicleBuilder.setProtofileVersion("1.4.7");
		commonFromVehicleBuilder.setProtofileVersion("3.0.4");
		commonFromVehicleBuilder.setInCarHecTime(HECDateTime.getDefaultInstance());
		
		//HECDateTime.getDefaultInstance();
		
		return commonFromVehicleBuilder;
	}
	
	public static CommonFromVehicle.Builder buildVehicleCommon(String esn, String vin)
	{
		UTCDateTime.Builder utcDateTimeBuilder = UTCDateTime.newBuilder();
		CommonFromVehicle.Builder commonFromVehicleBuilder = CommonFromVehicle.newBuilder();
		
		commonFromVehicleBuilder.setModemUTCDateTime(buildUTCDateTime(utcDateTimeBuilder));
		commonFromVehicleBuilder.setVin(vin);
		commonFromVehicleBuilder.setEsn(esn);
		commonFromVehicleBuilder.setIccid("89860114623100287757");
		/*commonFromVehicleBuilder.setHardwarePartNumber("FA1T-14G145-AA");
		commonFromVehicleBuilder.setFirmwareVersion("1.2.4");
		commonFromVehicleBuilder.setAssemblyPartNumber("FA1T-14G087-AC");
		commonFromVehicleBuilder.setStrategyPartNumber("FA1T-14G139-BA");
		commonFromVehicleBuilder.setGlobalConfigVersion("2.1.9.m");
		commonFromVehicleBuilder.setConfigPartNumber("FA1T-14G144-BA");*/
		commonFromVehicleBuilder.setTcuMessageId(1431656473);
		commonFromVehicleBuilder.setCorrelationId(0);
		commonFromVehicleBuilder.setAuthStatus(AuthStatusEnum.AUTHORIZED);
		commonFromVehicleBuilder.setProtofileVersion("3.0.4");
		
		commonFromVehicleBuilder.setInCarHecTime(HECDateTime.getDefaultInstance());
		
		return commonFromVehicleBuilder;
	}
	
	private static UTCDateTime.Builder buildUTCDateTime(UTCDateTime.Builder utcDateTimeBuilder){
		
		GregorianCalendar date = new GregorianCalendar();
		utcDateTimeBuilder/*.setGpsUtcYrNoActl*/.setUTCYear(date.get(Calendar.YEAR));
		utcDateTimeBuilder/*.setGpsUtcMnthNoActl*/.setUTCMonth(date.get(Calendar.MONTH));
		utcDateTimeBuilder/*.setGpsUtcDayNoActl*/.setUTCDay(date.get(Calendar.DAY_OF_MONTH));
		utcDateTimeBuilder/*.setGPSUTCHours*/.setUTCHour(date.get(Calendar.HOUR));
		utcDateTimeBuilder/*.setGPSUTCMinutes*/.setUTCMin(date.get(Calendar.MINUTE));
		utcDateTimeBuilder/*.setGPSUTCSeconds*/.setUTCSecond(date.get(Calendar.SECOND));
		
		return utcDateTimeBuilder;
	}
}
