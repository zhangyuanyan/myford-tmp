package com.hev.test;

import static org.junit.Assert.assertEquals;

import java.util.Calendar;
import java.util.GregorianCalendar;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ford.ftcp.util.StringUtil;
import com.ford.ftcp.util.SyncpUtil;
import com.ford.ftcp.v304.FTCP3.AuthStatusEnum;
import com.ford.ftcp.v304.FTCP3.CommonFromVehicle;
import com.ford.ftcp.v304.FTCP3.HECDateTime;
import com.ford.ftcp.v304.FTCP3.HEVBatteryData;
import com.ford.ftcp.v304.FTCP3.HEVDataMonitoringAlert;
import com.ford.ftcp.v304.FTCP3.TCUAlert;
import com.ford.ftcp.v304.FTCP3.TCUNonGenericAlert;
import com.ford.ftcp.v304.FTCP3.UTCDateTime;
import com.ford.ftcp.v304.FTCP3.VehicleStatus;
import com.ford.ftcp.v304.FTCP3.VehicleStatus.BpedDrvApplENUM;

public class HevDataMonitorAlert_CEVDM_NCEVT03_VEHICLE_STATUS_NCEVT04_HEV_BATTERY_DTA_Test04 {
	MqttAsyncClient mqttclient;
	String esn;
	String psKey;
	String mqttPsw;
	String vin;
	String region;

	@Before
	public void before() throws Exception {

		esn = "T4CF0052";
		psKey = "ofpKs1sE0Ye172EKLNkEcw==";
		mqttPsw = "CPI5gJdy1T7KL394tK+bhg==";

		/*
		 * String esn = "T4860029"; String psKey = "h7Qx9UVgF2jPJJPSLKIpKg==";
		 * String mqttPsw = "XMd/kVB9SQaxG/MC8o6vSQ==";
		 */

		/*
		 * String esn = "T4860025"; String psKey = "Riduc1Mc4U9vJhZaev36ew==";
		 * String mqttPsw = "QMM2VareTyJQxKr+RjuyYQ==";
		 */

		/*
		 * String esn = "T4CF0028"; String psKey = "SVyGr0ba1e6Zof7hNF7iQg==";
		 * String mqttPsw = "XOKK+cZPoWAJoMPjcDJCSw==";
		 */
		// String vin = "5LMCJ2AN0FUJ10556";
		vin = "5LMCJ2ANXFUJ16493";
		region = "CN";
		String MQTT_URL = "tcp://fcne0001vehqa.chinacloudapp.cn:1883";// "tcp://Mqa1cnveh.cv.ford.com:1883";//"tcp://mqa1cnveh.cv.ford.com:1883";//

		MqttConnectOptions _mqttConnOpt = new MqttConnectOptions();
		_mqttConnOpt.setCleanSession(false);
		_mqttConnOpt.setConnectionTimeout(30);
		_mqttConnOpt.setKeepAliveInterval(30);
		_mqttConnOpt.setUserName(esn);
		_mqttConnOpt.setPassword(mqttPsw.toCharArray());

		MqttDefaultFilePersistence dataStore = new MqttDefaultFilePersistence(
				"C:\\temp");
		mqttclient = new MqttAsyncClient(MQTT_URL, vin, dataStore);

		IMqttToken mqttConnToken = mqttclient.connect(_mqttConnOpt);

		try {
			mqttConnToken.waitForCompletion();
			System.out
					.println("--------------- TCU Simulator connect to MQTT successfully.");
		} // end-try
		catch (MqttException mqttex) {
			if (mqttclient != null) {
				mqttclient.close();
				mqttclient = null;
			} // end-if
			throw mqttex;
		} // end-catch

		mqttclient.setCallback(new MqttCallback() {

			@Override
			public void messageArrived(String topicName, MqttMessage msg)
					throws Exception {
				System.out.println("+++++: " + topicName);

				/*
				 * byte[] syncpBytes = msg.getPayload();
				 * 
				 * System.out.println("+++++Payload(HexString): " +
				 * StringUtil.bytesToHexString(syncpBytes)); String esn =
				 * SyncpUtil.get_ESN_From_Syncp_Header(syncpBytes); String
				 * psKeyB64 = FTCPConstants.ESN_PSKEY_MAP.get(esn); byte[]
				 * decodedBytes = SyncpUtil.decodeSyncpPacket(syncpBytes,
				 * psKeyB64); System.out.println("+++++Syncpayload(HexString): "
				 * + StringUtil.bytesToHexString(decodedBytes));
				 * 
				 * if (topicName.contains("TCU_COMMAND")) { TCUCommand
				 * tucCommand = TCUCommand.parseFrom(decodedBytes);
				 * System.out.println(tucCommand); }
				 */
			}

			@Override
			public void deliveryComplete(IMqttDeliveryToken arg0) {
				System.out.println("deliveryComplete");
			}

			@Override
			public void connectionLost(Throwable arg0) {

			}
		});

	}

	@Test
	public void test() throws Exception {
		String topicAlert = StringUtil
				.getPublishTopic(region, vin, "TCU_ALERT");
		byte[] cmdBytes = getHevDataMonitorAlertByte(esn, vin);// getProvisioningAlert(esn,
																// vin, "",
																// "");//getClearLowTirePressure(esn,
																// vin);//getClearLowTirePressure(esn,
																// vin);//buildTCUConnectionStatusAlert();//buildAlert(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_DATA_MONITOR_VALUE,
																// FTCP3.TCUAlert.AlertType.NON_GENERIC_VALUE);
		byte[] bytesToPublish1 = SyncpUtil.encodeSyncpPacket(cmdBytes, esn,
				psKey);
		mqttclient.publish(topicAlert, new MqttMessage(bytesToPublish1));
		Thread.sleep(10000);

		String connectionString = "jdbc:sqlserver://uajwgye1jc.database.chinacloudapi.cn:1433"
				+ ";"
				+ "database=CEVDM_QA"
				+ ";"
				+ "user=TestUser"
				+ ";"
				+ "password=Test@123";
		Connection connection = null; // For making the connection
		PreparedStatement pstatement = null; // For the SQL statement
		ResultSet resultSet = null; // For the result set, if applicable

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			connection = DriverManager.getConnection(connectionString);

			StringBuffer sb = new StringBuffer();

			sb.append(" select top 1 CEVT01_VIN_C,CEVT03_ESN_D, CEVL05_MSG_N, *");
			sb.append(" from NCEVT03_VEHICLE_STATUS as A ");
			sb.append(" left join NCEVT02_HEV_HEADER as B on A.CEVT02_ACTVY_D = B.CEVT02_ACTVY_D ");
			sb.append(" left join NCEVT04_HEV_BATTERY_DTA as C on B.CEVT02_ACTVY_D = C.CEVT02_ACTVY_D ");
			sb.append(" left join NCEVP01_VEH_STAT_GPS as F on A.CEVT02_ACTVY_D = F.CEVT02_ACTVY_D ");
			sb.append(" where cevt03_esn_d = ? ");
			sb.append(" order by CEVT03_CREATE_S desc");

			pstatement = connection
					.prepareStatement(sb.toString());
			pstatement.setString(1, esn);

			resultSet = pstatement.executeQuery();

			while (resultSet.next()) {
				
				assertEquals("PwPckOff_TqNotAvailable", resultSet.getString("CEVT03_PWPCKTQ_D_STAT_X"));

				assertEquals("Drive", resultSet.getString("CEVT03_GEARLVRPOS_D_ACTL_X"));

				assertEquals("Run", resultSet.getString("CEVT03_IGN_STAT_X"));

				assertEquals(92.608992, resultSet.getDouble("CEVT03_FUELLVL_PC_DSPLY_R"), 0);

				assertEquals(10.000, resultSet.getDouble("CEVT03_VEH_V_ACTLENG_R"), 0);

				assertEquals(1000.00, resultSet.getDouble("CEVT03_FUELRANGE_L_DSPLY_R"), 0);

//				assertEquals(10000, resultSet.getInt("CEVT03_ODOMETERMASTERVALUE_R"));

//				assertEquals("Engine_Service_Required", resultSet.getString("CEVT03_ENGSRVCRQD_B_RQ_X"));
//
//				assertEquals("On", resultSet.getString("CEVT03_BATTTRACSRVCRQD_B_RQ_X"));
//
//				assertEquals("On", resultSet.getString("CEVT03_BATTTRACWARNLAMP_B_RQ_X"));

				assertEquals(122.000, resultSet.getDouble("CEVT03_AIRAMB_TE_ACTLFILT_R"), 0);

//				assertEquals(102.30, resultSet.getDouble("CEVT03_APEDPOS_PC_ACTLARB_R"), 0);

//				assertEquals(16382, resultSet.getInt("CEVT03_ENGAOUT_N_ACTL_R"));

				assertEquals(40, resultSet.getInt("CEVT03_ENGCLNT_TE_ACTL_R")); 

				assertEquals(-130672, resultSet.getInt("CEVT03_PRPLWHLTOT2_TQ_ACTL_R")); 

//				assertEquals(127, resultSet.getInt("CEVT03_BSBATTSOC_R")); 
				
				assertEquals(3, resultSet.getInt("CEVT03_BPEDDRVAPPLENUM_R")); 
				
				assertEquals(510.50, resultSet.getDouble("CEVT04_BATTTRAC_U_ACTL_R"), 0); 
				
				assertEquals(250.000, resultSet.getDouble("CEVT04_BATTTRAC_I_ACTL_R"), 0); 
				
				assertEquals(163.80, resultSet.getDouble("CEVT04_BATTTRACSOC2_PC_ACTL_R"), 0); 
				
				assertEquals(460.50, resultSet.getDouble("CEVT04_BATTTRAC_TE_ACTL_R"), 0); 
				
//				assertEquals("Yes", resultSet.getString("CEVT04_VEHSTRTINHBT_B_RQBATT_R")); 
//				
//				assertEquals("Yes", resultSet.getString("CEVT04_BATTTRACOFF_B_ACTL_R")); 
//				
//				assertEquals(250000.00, resultSet.getDouble("CEVT04_BATTTRAC_PW_LIMCHRG_R"), 0); 
//				
//				assertEquals(250000.00, resultSet.getDouble("CEVT04_BATTTRAC_PW_LIMDCHRG_R"), 0); 
				
				assertEquals("Unexpected_Contactor_Open", resultSet.getString("CEVT04_BATTTRACOFFFST_D_ACTL_R")); 
				
				Assert.fail("---data check OK---");
			}

		}
		catch (Exception e) {
			System.out.println("Exception " + e.getMessage());
			e.printStackTrace();
			Assert.fail();
		} finally {
			try {
				// Close resources.
				if (null != connection)
					connection.close();
				if (null != pstatement)
					pstatement.close();
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException sqlException) {
				// No additional action if close() statements fail.
			}
		}

	}

	@After
	public void after() throws Exception {
		if (mqttclient != null) {
			if (mqttclient.isConnected()) {
				mqttclient.disconnect();
			}
		}
	}
	
	public static VehicleStatus.Builder buildHEVVehicleStatus() {

		VehicleStatus.Builder vehicleStatus = VehicleStatus.newBuilder();
		// VehicleStatus.Veh_LockStatus
		vehicleStatus.setVehLockStatus(str2Int("0x0"));
//1. VehicleStatus.PwPckTqDStat CEVT03_PWPCKTQ_D_STAT_X
vehicleStatus.setPwPckTqDStat(str2Int("0x0"));
		// VehicleStatus.BattULoUActl
		vehicleStatus.setBattULoUActl(1);
		// VehicleStatus.TirepresssystemStat
		vehicleStatus.setTirePressSystemStat(0);
//2. VehicleStatus.GearLvrPosDActl CEVT03_GEARLVRPOS_D_ACTL_X
vehicleStatus.setGearLvrPosDActl(str2Int("0x3"));
//3. VehicleStatus.IgnitionStatus CEVT03_IGN_STAT_X
vehicleStatus.setIgnitionStatus(str2Int("0x4"));
		// VehicleStatus.PerimeterAlarmStatus
		vehicleStatus.setPerimeterAlarmStatus(0);
		// VehicleStatus.PrmtrAlrmEvntDStat
		vehicleStatus.setPrmtrAlrmEvntDStat(0);
//4. VehicleStatus.FuelLvlPcDsply CEVT03_FUELLVL_PC_DSPLY_R
vehicleStatus.setFuelLvlPcDsply(900);
		// VehicleStatus.EngOilLifePcActl
		vehicleStatus.setEngOilLifePcActl(0);
//5. VehicleStatus.VehVActlEng CEVT03_VEH_V_ACTLENG_R
vehicleStatus.setVehVActlEng(1000);
//6. VehicleStatus.FuelRangeLDsply CEVT03_FUELRANGE_L_DSPLY_R
vehicleStatus.setFuelRangeLDsply(10000);
//7. VehicleStatus.OdometerMasterValue CEVT03_ODOMETERMASTERVALUE_R
vehicleStatus.setOdometerMasterValue(10000);
		// VehicleStatus.BattTracSocPcDsply
		vehicleStatus.setBattTracSocPcDsply(0);
		// VehicleStatus.PtRmtRprtDRq
		vehicleStatus.setPtRmtRprtDRq(0);
		// VehicleStatus.PlgActvArbBActl
		vehicleStatus.setPlgActvArbBActl(0);
		// VehicleStatus.BattElecPerfDActl
		vehicleStatus.setBattElecPerfDActl(0);
		// VehicleStatus.TripSumEDsply
		vehicleStatus.setTripSumEDsply(0);
		// VehicleStatus.TripSumVlDsply
		vehicleStatus.setTripSumVlDsply(0);
		// VehicleStatus.TripSumLDsply
		vehicleStatus.setTripSumLDsply(0);
		// VehicleStatus.ActChrgStrtYrNoActl
		vehicleStatus.setActChrgStrtYrNoActl(0);
		// VehicleStatus.ActChrgStrMnthNoActl
		vehicleStatus.setActChrgStrMnthNoActl(0);
		// VehicleStatus.ActChrgStrtDayNoActl
		vehicleStatus.setActChrgStrtDayNoActl(0);
		// VehicleStatus.ActChrgStrtHrNoActl
		vehicleStatus.setActChrgStrtHrNoActl(0);
		// VehicleStatus.ActChrgStrtMinNoActl
		vehicleStatus.setActChrgStrtMinNoActl(0);
		// VehicleStatus.ActChrgEndYrNoActl
		vehicleStatus.setActChrgEndYrNoActl(0);
		// VehicleStatus.ActChrgEndMnthNoActl
		vehicleStatus.setActChrgEndMnthNoActl(0);
		// VehicleStatus.ActChrgEndDayNoActl
		vehicleStatus.setActChrgEndDayNoActl(0);
		// VehicleStatus.ActChrgEndHrNoActl
		vehicleStatus.setActChrgEndHrNoActl(0);
		// ActChrgEndMinNoActl
		vehicleStatus.setActChrgEndMinNoActl(0);
		// VehicleStatus.ChrgLocIDNoRq
		vehicleStatus.setChrgLocIDNoRq(0);
		// VehicleStatus.ChargeNowDurationSt
		vehicleStatus.setChargeNowDurationSt(0);
		// VehicleStatus.receivedSignalQuality
		vehicleStatus.setReceivedSignalQuality(0);
		// VehicleStatus.GSMDRXLevel
		vehicleStatus.setGSMDRXLevel(0);
		// VehicleStatus.GSMRoamingFlag
		vehicleStatus.setGSMRoamingFlag(0);
		// VehicleStatus.GSMNumberOfNeighbors
		vehicleStatus.setGSMNumberOfNeighbors(0);
		// VehicleStatus.RgenLongTermPcDsply
		vehicleStatus.setRgenLongTermPcDsply(0);
		// VehicleStatus.RgenTripPcDsply
		vehicleStatus.setRgenTripPcDsply(0);
		// VehicleStatus.RgenTripLDsply
		vehicleStatus.setRgenTripLDsply(0);
		// VehicleStatus.RgenLongTermLDsply
		vehicleStatus.setRgenLongTermLDsply(0);
		// VehicleStatus.ConsTipANoDsply
		vehicleStatus.setConsTipANoDsply(0);
		// VehicleStatus.ConsTipVNoDsply
		vehicleStatus.setConsTipVNoDsply(0);
		// VehicleStatus.ConsTipDecelNoDsply
		vehicleStatus.setConsTipDecelNoDsply(0);
		// VehicleStatus.ConsTipUnitPtDDsply
		vehicleStatus.setConsTipUnitPtDDsply(0);
		// VehicleStatus.ConsTipTotPcDsply
		vehicleStatus.setConsTipTotPcDsply(0);
		// VehicleStatus.ConsAvgTripNoDsply
		vehicleStatus.setConsAvgTripNoDsply(0);
		// VehicleStatus.ConsUnitIPCDDsply
		vehicleStatus.setConsUnitIPCDDsply(0);
		// VehicleStatus.ConsLongTermNoDsply
		vehicleStatus.setConsLongTermNoDsply(0);
//8. VehicleStatus.EngSrvcRqdBRq CEVT03_ENGSRVCRQD_B_RQ_X
vehicleStatus.setEngSrvcRqdBRq(str2Int("0x1"));
		// VehicleStatus.HtrnSrvcRqdBDsply
		vehicleStatus.setHtrnSrvcRqdBDsply(0);
		// VehicleStatus.HtrnWarnLampBDsply
		vehicleStatus.setHtrnWarnLampBDsply(0);
		// VehicleStatus.PtSrvcLampBRqHtrn
		vehicleStatus.setPtSrvcLampBRqHtrn(0);
		// VehicleStatus.PtWarnLampBRqHtrn
		vehicleStatus.setPtWarnLampBRqHtrn(0);
//9. VehicleStatus.BattTracSrvcRqdBRq CEVT03_BATTTRACSRVCRQD_B_RQ_X
vehicleStatus.setBattTracSrvcRqdBRq(1);
//10. VehicleStatus.BattTracWarnLampBRq CEVT03_BATTTRACWARNLAMP_B_RQ_X
vehicleStatus.setBattTracWarnLampBRq(1);
		// VehicleStatus.ChrgrSrvcRqdBRq
		vehicleStatus.setChrgrSrvcRqdBRq(0);
		// VehicleStatus.TrnSrvcRqdBRq
		vehicleStatus.setTrnSrvcRqdBRq(0);
		// VehicleStatus.TrnWarnLampBDsply
		vehicleStatus.setTrnWarnLampBDsply(0);
		// VehicleStatus.ElTripLDsply
		vehicleStatus.setElTripLDsply(0);
		// VehicleStatus.ElLongTermLDsply
		vehicleStatus.setElLongTermLDsply(0);
		// VehicleStatus.ConsAvgTripFeDsply
		vehicleStatus.setConsAvgTripFeDsply(0);
		// VehicleStatus.receivedSignalStrength
		vehicleStatus.setReceivedSignalStrength(0);
		// VehicleStatus.HybMdeStatDDsply
		vehicleStatus.setHybMdeStatDDsply(0);
		// VehicleStatus.VehElRngeLDsply
		vehicleStatus.setVehElRngeLDsply(0);
		// VehicleStatus.PreCondStatDDsply
		vehicleStatus.setPreCondStatDDsply(0);
		// VehicleStatus.CabnAmbTeActl
		vehicleStatus.setCabnAmbTeActl(0);
		// VehicleStatus.ChrgrInPwTypeDActl
		vehicleStatus.setChrgrInPwTypeDActl(0);
		// VehicleStatus.ChrgStatDDsply
		vehicleStatus.setChrgStatDDsply(0);
		// VehicleStatus.BattChrgTrgSocPtTEst
		vehicleStatus.setBattChrgTrgSocPtTEst(0);
		// VehicleStatus.BattChrgCmpltPtTEst
		vehicleStatus.setBattChrgCmpltPtTEst(0);
		// VehicleStatus.PlgActvDActlChrgr
		vehicleStatus.setPlgActvDActlChrgr(0);
		// VehicleStatus.ChrgrInPwMx
		vehicleStatus.setChrgrInPwMx(0);
//11. VehicleStatus.AirAmbTeActlFilt CEVT03_AIRAMB_TE_ACTLFILT_R
vehicleStatus.setAirAmbTeActlFilt(1000);
		// VehicleStatus.LifeCycMdeDActl
		vehicleStatus.setLifeCycMdeDActl(0);
		// VehicleStatus.Prkbrkstatus
		vehicleStatus.setPrkbrkstatus(0);
		// VehicleStatus.PrkBrkActvBActl
		vehicleStatus.setPrkBrkActvBActl(0);
		// VehicleStatus.parkrbrakehard
		vehicleStatus.setParkrbrakeHard(0);
		// VehicleStatus.parkbrakesoft
		vehicleStatus.setParkbrakeSoft(0);
//12. VehicleStatus.ApedPosPcActlArb CEVT03_APEDPOS_PC_ACTLARB_R
vehicleStatus.setApedPosPcActlArb(1023);
//13. VehicleStatus.EngAoutNActl CEVT03_ENGAOUT_N_ACTL_R
vehicleStatus.setEngAoutNActl(8191);
//14. VehicleStatus.EngClntTeActl CEVT03_ENGCLNT_TE_ACTL_R
vehicleStatus.setEngClntTeActl(100);
//15. VehicleStatus.PrplWhlTot2TqActl CEVT03_PRPLWHLTOT2_TQ_ACTL_R
vehicleStatus.setPrplWhlTot2TqActl(100);
//16. VehicleStatus.BSBattSOC CEVT03_BSBATTSOC_R 
vehicleStatus.setBSBattSOC(127);
//17. VehicleStatus.BpedDrvApplDActl CEVT03_BPEDDRVAPPLENUM_R
vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.NOT_ALLOWED_);
		// if (hevVehicleBean.getBpedDrvApplDActl() == 0) {
		// vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.NOT_ALLOWED);
		// } else if (hevVehicleBean.getBpedDrvApplDActl() == 3) {
		// vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.NOT_ALLOWED_);
		// } else if (hevVehicleBean.getBpedDrvApplDActl() == 1) {
		// vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.DRIVER_NOT_BRAKING);
		// } else if (hevVehicleBean.getBpedDrvApplDActl() == 2) {
		// vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.DRIVER_BRAKING);
		// }

		return vehicleStatus;
	}

	public static HEVBatteryData.Builder buildHEVBatteryData() {
		
		HEVBatteryData.Builder builder = HEVBatteryData.newBuilder();
		// HEV Data
// 18. CEVT04_BATTTRAC_U_ACTL_R
builder.setBattTracUActl(1021);// voltage
// 19. CEVT04_BATTTRAC_I_ACTL_R
builder.setBattTracIActl(20000);// current
// 20. CEVT04_BATTTRACSOC2_PC_ACTL_R
builder.setBattTracSoc2PcActl(1638);// SOC
// 21. CEVT04_BATTTRAC_TE_ACTL_R
builder.setBattTracTeActl(1021);// temperature
// 22. CEVT04_VEHSTRTINHBT_B_RQBATT_R
builder.setVehStrtInhbtBRqBatt(str2Int("0x1"));// inhibit
// 23. CEVT04_BATTTRACOFF_B_ACTL_R
builder.setBattTracOffBActl(str2Int("0x1"));// shutdown or about to
											// shutdown
// 24. CEVT04_BATTTRAC_PW_LIMCHRG_R
builder.setBattTracPwLimChrg(1000);
// 25. CEVT04_BATTTRAC_PW_LIMDCHRG_R
builder.setBattTracPwLimDchrg(1000);
// 26. CEVT04_BATTTRACOFFFST_D_ACTL_R
builder.setBattTracOffFstDActl(str2Int("0x3"));

		return builder;
	}

	public static byte[] getHevDataMonitorAlertByte(String esn, String vin) {
		TCUAlert.Builder tcuAlertBuilder = TCUAlert.newBuilder();
		tcuAlertBuilder.setAlertType(TCUAlert.AlertType.NON_GENERIC);
		TCUNonGenericAlert.Builder tcuNonGenericAlertBuilder = TCUNonGenericAlert
				.newBuilder();
		tcuNonGenericAlertBuilder
				.setNonGenericAlertName(TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_DATA_MONITOR);
		HEVDataMonitoringAlert.Builder hevDataMonitorAlert = HEVDataMonitoringAlert
				.newBuilder();

		hevDataMonitorAlert.setVehicleCommon(buildVehicleCommon(esn, vin));

		hevDataMonitorAlert.setHevVehicleStatus(buildHEVVehicleStatus());

		hevDataMonitorAlert.setHevBatteryData(buildHEVBatteryData());

		tcuNonGenericAlertBuilder
				.setHevDataMonitoringAlert(hevDataMonitorAlert);

		tcuAlertBuilder.setNonGenericAlert(tcuNonGenericAlertBuilder);
		TCUAlert tcuAlert = tcuAlertBuilder.build();
		System.out.println(tcuAlert);
		byte alertBytes[] = tcuAlert.toByteArray();
		StringBuilder sb = new StringBuilder();
		for (byte by : alertBytes) {
			sb.append(String.format("%02X ", by));
		}
		return tcuAlert.toByteArray();
	}

	private static UTCDateTime.Builder buildUTCDateTime(
			UTCDateTime.Builder utcDateTimeBuilder) {

		GregorianCalendar date = new GregorianCalendar();
		utcDateTimeBuilder/* .setGpsUtcYrNoActl */.setUTCYear(date
				.get(Calendar.YEAR));
		utcDateTimeBuilder/* .setGpsUtcMnthNoActl */.setUTCMonth(date
				.get(Calendar.MONTH));
		utcDateTimeBuilder/* .setGpsUtcDayNoActl */.setUTCDay(date
				.get(Calendar.DAY_OF_MONTH));
		utcDateTimeBuilder/* .setGPSUTCHours */.setUTCHour(date
				.get(Calendar.HOUR));
		utcDateTimeBuilder/* .setGPSUTCMinutes */.setUTCMin(date
				.get(Calendar.MINUTE));
		utcDateTimeBuilder/* .setGPSUTCSeconds */.setUTCSecond(date
				.get(Calendar.SECOND));

		return utcDateTimeBuilder;
	}

	public static CommonFromVehicle.Builder buildVehicleCommon(String esn,
			String vin) {
		UTCDateTime.Builder utcDateTimeBuilder = UTCDateTime.newBuilder();
		CommonFromVehicle.Builder commonFromVehicleBuilder = CommonFromVehicle
				.newBuilder();

		commonFromVehicleBuilder
				.setModemUTCDateTime(buildUTCDateTime(utcDateTimeBuilder));
		commonFromVehicleBuilder.setVin(vin);
		commonFromVehicleBuilder.setEsn(esn);
		commonFromVehicleBuilder.setIccid("89860114623100287757");
		/*
		 * commonFromVehicleBuilder.setHardwarePartNumber("FA1T-14G145-AA");
		 * commonFromVehicleBuilder.setFirmwareVersion("1.2.4");
		 * commonFromVehicleBuilder.setAssemblyPartNumber("FA1T-14G087-AC");
		 * commonFromVehicleBuilder.setStrategyPartNumber("FA1T-14G139-BA");
		 * commonFromVehicleBuilder.setGlobalConfigVersion("2.1.9.m");
		 * commonFromVehicleBuilder.setConfigPartNumber("FA1T-14G144-BA");
		 */
		commonFromVehicleBuilder.setTcuMessageId(1431656473);
		commonFromVehicleBuilder.setCorrelationId(0);
		commonFromVehicleBuilder.setAuthStatus(AuthStatusEnum.AUTHORIZED);
		commonFromVehicleBuilder.setProtofileVersion("3.0.4");

		commonFromVehicleBuilder.setInCarHecTime(HECDateTime
				.getDefaultInstance());

		return commonFromVehicleBuilder;
	}

	public static int str2Int(String str) {
		int tenCode = 0;

		if (str.toLowerCase().contains("0x")) {
			tenCode = Integer.parseInt(str.toLowerCase().replace("0x", ""), 16);
		} else {
			tenCode = Integer.parseInt(str);
		}

		return tenCode;
	}


}
