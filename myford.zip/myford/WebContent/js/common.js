var mapObj;

function commonUpdateProvinceCity() {
	var url = "hev/findAllProCityNullVehicles.action";
	$.ajax({
		type : "POST",
		url : url,
		data : {
		},
		beforeSend:function(){
			sending=true;
		},
		
		success: function(data, textStatus, jqXHR){
			
			$.each(data, function(i, n){
				
				var MGeocoder;
			    //加载地理编码插件
			    AMap.service(["AMap.Geocoder"], function() {        
			        MGeocoder = new AMap.Geocoder({ 
			            radius: 1000,
			            extensions: "all"
			        });
			        //逆地理编码
			        MGeocoder.getAddress(new AMap.LngLat(n.lng, n.lat), function(status, result){
			        	if(status === 'complete' && result.info === 'OK'){
			        		var province = result.regeocode.addressComponent.province;
			        		var city = result.regeocode.addressComponent.city;
			        		
							$.ajax({
								type : "POST",
								url : 'hev/updProvinceCity.action',
								contentType: "application/x-www-form-urlencoded; charset=utf-8", 
								data : {
									'vehicleBean.id' : n.id,
									'vehicleBean.province' : province,
									'vehicleBean.city' : city,
								},
								beforeSend:function(){
									sending=true;
								},
								
								success: function(data, textStatus, jqXHR){
									
								},
								
								error: function(){
									showMessage("系统繁忙，请稍后再试");
								},
								complete: function(){
									sending=false;
								},
							});
			        	}
			        });
			    });
			    
			});
		},
		
		error: function(){
			showMessage("系统繁忙，请稍后再试");
		},
		complete: function(){
			sending=false;
		},
	});
}

function searchByCity(city) {
	var url = "hev/findCityVehicles.action";
	$.ajax({
		type : "POST",
		url : url,
		data : {
			city: city
		},
		beforeSend:function(){
			sending=true;
		},
		
		success: function(data, textStatus, jqXHR){
			mapObj.clearMap();
			
			// 更新没有逆地理过的省和市
			commonUpdateProvinceCity();
			
			// 更新区域车辆数
			commonUpdateVehicleOfCityAndBounds();
			
			$.each(data, function(i, n){
				if (i == 0) {
					mapObj.setZoomAndCenter(8, new AMap.LngLat(n.lng, n.lat));
				}
				addMarker(n.id, n.vin, n.lng, n.lat, n.insertDate, n.errorFlg);
			});
		},
		
		error: function(){
			showMessage("系统繁忙，请稍后再试");
		},
		complete: function(){
			sending=false;
		},
	});
}

function addCirleMaker(city, vehicleCnt, lngLat) {
    //自定义点标记内容   
	var markerContent = document.createElement("div");
	markerContent.className = "markerContentDiv";
	markerContent.onclick = function() {
		searchByCity(city);
	};
	 //点标记中的文本
	 var markerSpan = document.createElement("span");
	 markerSpan.innerHTML = vehicleCnt;
	 markerContent.appendChild(markerSpan);
	 var marker = new AMap.Marker({
		map:mapObj,
		position: lngLat, //基点位置
		offset: new AMap.Pixel(-18,-36), //相对于基点的偏移位置
		draggable: true,  //是否可拖动
		content: markerContent   //自定义点标记覆盖物内容
	});
	marker.setMap(mapObj);  //在地图上添加点
	
}

function commonUpdateVehicleOfCityAndBounds() {
	var url = "hev/groupCityVehCnt.action";
	$.ajax({
		type : "POST",
		url : url,
		data : {
		},
		beforeSend:function(){
			sending=true;
		},
		
		success: function(data, textStatus, jqXHR){
			//mapObj.clearMap();
			
			$.each(data, function(i, n){
				//加载云图层插件
			    AMap.service('AMap.DistrictSearch', function () {
			        var opts = {
			            subdistrict: 1,   //返回下一级行政区
			            extensions: 'all',  //返回行政区边界坐标组等具体信息
			            level:'city'  //查询行政级别为 市
			        };

			        //实例化DistrictSearch
			        district = new AMap.DistrictSearch(opts); 
			        district.setLevel('city');
			        //行政区查询
			        district.search(n.city, function(status, result){
			        	var lngLat = result.districtList[0].center;
			        	
			        	// 添加区域车辆数
			        	addCirleMaker(n.city, n.cityCnt, lngLat);
			        	
			        	// 添加区域多边形
			        	var bounds = result.districtList[0].boundaries;
			            var polygons = [];
			            if(bounds) {
			                for(var i =0, l = bounds.length;i < l; i++){
			                  //生成行政区划polygon
			                  var polygon = new AMap.Polygon({
			                    map: mapObj,
			                    strokeWeight: 3,
			                    path: bounds[i],
			                    fillOpacity: 0.1,
			                    fillColor: '#CCC',
			                    strokeColor: '#FF3333'
			                  });
			                  polygons.push(polygon);
			                }
			                //map.setFitView();//地图自适应
			            }
			        }); 
			    });
			});
		},
		
		error: function(){
			showMessage("系统繁忙，请稍后再试");
		},
		complete: function(){
			sending=false;
		},
	});
}

$(document).ready(function(){

	mapObj = new AMap.Map("iCenter",{
		view: new AMap.View2D({
			//center:new AMap.LngLat(116.397428,39.90923),
			zoom:4 
		})
	});	
	// 更新没有逆地理过的省和市
	commonUpdateProvinceCity();
	
	// 更新区域车辆数
	commonUpdateVehicleOfCityAndBounds();
	
	//commonAddMarkers();
});

function commonAddMarkers() {
	var url = "hev/homeMapMain.action";
	$.ajax({
		type : "POST",
		url : url,
		data : {
		},
		beforeSend:function(){
			sending=true;
		},
		
		success: function(data, textStatus, jqXHR){
			mapObj.clearMap();
			
			$.each(data, function(i, n){
				if (i == 0) {
					mapObj.setZoomAndCenter(4, new AMap.LngLat(n.lng, n.lat));
				}		
				
				var MGeocoder;
			    //加载地理编码插件
			    AMap.service(["AMap.Geocoder"], function() {        
			        MGeocoder = new AMap.Geocoder({ 
			            radius: 1000,
			            extensions: "all"
			        });
			        //逆地理编码
			        MGeocoder.getAddress(new AMap.LngLat(n.lng, n.lat), function(status, result){
			        	if(status === 'complete' && result.info === 'OK'){
			        		addMarker(n.id, n.vin, n.lng, n.lat, n.insertDate, n.errorFlg);
			        		var cityName = result.regeocode.addressComponent.city;
			        		addCityBound(cityName);
			        	}
			        });
			    });
				
			});
		},
		
		error: function(){
			showMessage("系统繁忙，请稍后再试");
		},
		complete: function(){
			sending=false;
		},
	});
}

//叠加云数据图层
function addCityBound(cityName) {
    //加载云图层插件
    AMap.service('AMap.DistrictSearch', function () {
        var opts = {
            subdistrict: 1,   //返回下一级行政区
            extensions: 'all',  //返回行政区边界坐标组等具体信息
            level:'city'  //查询行政级别为 市
        };

        //实例化DistrictSearch
        district = new AMap.DistrictSearch(opts); 
        district.setLevel('city');
        //行政区查询
        district.search(cityName, function(status, result){
        	var bounds = result.districtList[0].boundaries;
            var polygons = [];
            if(bounds) {
                for(var i =0, l = bounds.length;i < l; i++){
                  //生成行政区划polygon
                  var polygon = new AMap.Polygon({
                    map: mapObj,
                    strokeWeight: 1,
                    path: bounds[i],
                    fillOpacity: 0.1,
                    fillColor: '#CCF3FF',
                    strokeColor: '#CC66CC'
                  });
                  polygons.push(polygon);
                }
                //map.setFitView();//地图自适应
            }
        }); 
    });
}

// n.id, n.vin, n.lng, n.lat, n.insertDate
function addMarker(id, vin, lng, lat, insertDate, errorFlg){
	var marker_icon = "";
	var smartInfo = "";
	if (errorFlg == 1) { // request service
		marker_icon = "../images/red_marker.png";
		smartInfo = "Request Service";
	} else if (errorFlg == 2) { // warning
		marker_icon = "../images/yellow_marker.png";
		smartInfo = "Warning";
	} else if (errorFlg == 3) { // offline
		marker_icon = "../images/gray_marker.png";
		smartInfo = "Offline";
	} else { // online
		marker_icon = "../images/green_marker.png";
		smartInfo = "Online";
	}
	var marker = new AMap.Marker({				  
		icon:marker_icon, //复杂图标
		offset: new AMap.Pixel(-24,-48), 
		position:new AMap.LngLat(lng, lat)
	});

	marker.setMap(mapObj);  
	//实例化信息窗体
	var infoWindow = new AMap.InfoWindow({
			isCustom:true,  //使用自定义窗体
			content:createInfoWindow("ID: "+ id +"&nbsp;&nbsp;<span style='font-size:11px;color:#F00;'> Vin: "+ vin + "</span>","<div style='color: red; font-weight: bold;'>"+ smartInfo +"</div>(Lng, Lat): "+ lng + "," + lat +"<br/><a href='vehicleDetail.action?vin="+ vin +"'>Detail</a>"),
			offset:new AMap.Pixel(12, -60)//-113, -140
	});
   AMap.event.addListener(marker,'click',function(){ //鼠标点击marker弹出自定义的信息窗体
		 infoWindow.open(mapObj,marker.getPosition());	
   });
}

//构建自定义信息窗体	
function createInfoWindow(title,content){
	var info = document.createElement("div");
	info.className = "info";

	//可以通过下面的方式修改自定义窗体的宽高
	//info.style.width = "400px";

	// 定义顶部标题
	var top = document.createElement("div");
	top.className = "info-top";
	  var titleD = document.createElement("div");
	  titleD.innerHTML = title;
	  var closeX = document.createElement("img");
	  closeX.src = "http://webapi.amap.com/images/close2.gif";
	  closeX.onclick = closeInfoWindow;
	  
	top.appendChild(titleD);
	top.appendChild(closeX);
	info.appendChild(top);
	
    
	// 定义中部内容
	var middle = document.createElement("div");
	middle.className = "info-middle";
	middle.style.backgroundColor='white';
	middle.innerHTML = content;
	info.appendChild(middle);
	
	// 定义底部内容
	var bottom = document.createElement("div");
	bottom.className = "info-bottom";
	bottom.style.position = 'relative';
	bottom.style.top = '0px';
	bottom.style.margin = '0 auto';
	var sharp = document.createElement("img");
	sharp.src = "http://webapi.amap.com/images/sharp.png";
	bottom.appendChild(sharp);	
	info.appendChild(bottom);
	return info;
}

//关闭信息窗体
function closeInfoWindow(){
	mapObj.clearInfoWindow();
}

function searchByVin() {
	var searchVin = $("#vin_id").val();
	var url = "hev/searchByVin.action";
	$.ajax({
		type : "POST",
		url : url,
		data : {
			vin : searchVin
		},
		beforeSend:function(){
			sending=true;
		},
		
		success: function(data, textStatus, jqXHR){
			mapObj.clearMap();
			$.each(data, function(i, n){
				addMarker(n.id, n.vin, n.lng, n.lat, n.insertDate, n.errorFlg);
			});
		},
		
		error: function(){
			showMessage("系统繁忙，请稍后再试");
		},
		complete: function(){
			sending=false;
		},
	});
}

function searchByCityName() {
	if ($('.province').val() == '0') {
		alert('Please select a province');
		return;
	}
	if ($('.city').val() == '0') {
		alert('Please select a city');
		return;
	}
	searchByCity($('.city').val());
}