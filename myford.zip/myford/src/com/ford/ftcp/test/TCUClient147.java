package com.ford.ftcp.test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;

import com.ford.ftcp.util.FTCPConstants;
import com.ford.ftcp.util.StringUtil;
import com.ford.ftcp.util.SyncpUtil;
import com.ford.ftcp.v147.FTCP;
import com.ford.ftcp.v147.FTCP.ClearLowTirePressureAlert;
import com.ford.ftcp.v147.FTCP.CommonFromVehicle;
import com.ford.ftcp.v147.FTCP.DoorAjarStatus.DoorType;
import com.ford.ftcp.v147.FTCP.Latitude;
import com.ford.ftcp.v147.FTCP.Longitude;
import com.ford.ftcp.v147.FTCP.ProvisioningAlert;
import com.ford.ftcp.v147.FTCP.ProvisioningData;
import com.ford.ftcp.v147.FTCP.TCUAlert;
import com.ford.ftcp.v147.FTCP.TCUCommand;
import com.ford.ftcp.v147.FTCP.TCUGenericAlert;
import com.ford.ftcp.v147.FTCP.TCUNonGenericAlert;
import com.ford.ftcp.v147.FTCP.UTCDateTime;
import com.ford.ftcp.v147.FTCP.VehicleStatus;
import com.ford.ftcp.v147.FTCP.WindowPosition.WindowType;

public class TCUClient147 {

	public static void main(String[] args) throws Exception {
		
		/*String s = "eyJtZXNzYWdlIjoiRHdBQUFBQUJzbFEwUTBZd01ESTQ2QTBZWlpnY0JINDFpZGdNUGcybmJNVnM4N0JDY1p4QmJILzJQOWdiZDJ5cGVXMmhuZjhYVGlXck1ub3Y3L2VNOENncC8yZnMwQzlXSVFKNjRGcnVubTRxejY5NXo0RkFxaEg4di8zK2FrOFdxZk9CVlg1N3ZVZllPOVdTQTZDekJCQ1lhZ0grRVRTUTlqbTRnRlk0YkdhQVlSMU1GMVI2bG5ZcFh2UG5oRGxCNEUzY09CRmI5RHdxd05tLzlpZVBsNnpPU1k4RThSVFNPOTdXTFk1R3NuTW9EVnYrQjg2QkhhRkw4VTQ5Tk5TblNVS3B6K3llRkpFbDJBN0t6VmpSS0NTdHpXQStYQUk3bmdvQitsNDEvcFkwbExsTU9lS0NXZWNJV04raVV5Y01PRkFtWG1wTml4emkrWG1ndHhGUmwyOUp5eDg0WWhSSDBXa0pGVDVjUHg5bFRHaVZGZUcreXpsek8wUWFjVzNIRUxnb0hQMzlaRUxLMFlKVkYza2IxV3laN0hWbUlHcnZUVmZiSU81M2NOZlRRb0E1U0VUVUo2TVJHeHFUc0xmYWhPTDZYRm94MlBBNFArR1FxSFpDR09iQ282RjhhN2VON05sdHpZMFRqdG84K2JPaDlnRlRSUDlIaWJSd1JHTUJlUmphamRqcnVYVlRBMmI3cERDT2I1eUFkS1NQYTErQkRUVjBRQ0hPNCtnMHRUSG96S0NjdDdIbTVPMUx5d0pqR1JhRTl5THpGcXFrNWNONnJYV2ZhRkE5RU9ZVkh2MEorRkdiM2dPSm1BNzVJb1hNZDhOamEvak5WMFljVVEzM1pBPT0ifQ==";
		byte[] syncpBytes = Base64.decodeBase64(s);
		String jsonMessage = new String(syncpBytes, "utf-8");
		System.out.println(jsonMessage);
		String messageVal = new JSONObject(jsonMessage).getString("message");
		byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(Base64.decodeBase64(messageVal), "SVyGr0ba1e6Zof7hNF7iQg==");
		TCUAlert alert = TCUAlert.parseFrom(decodedBytes);
		System.out.println(alert);*/
		
		/*String esn = "T4860029";
		String psKey = "h7Qx9UVgF2jPJJPSLKIpKg==";
		String mqttPsw = "XMd/kVB9SQaxG/MC8o6vSQ==";*/
		
		/*String esn = "T4860034";
		String psKey = "E6K58hHWL4WIFgARcVDIQQ==";
		String mqttPsw = "PvX72hsnYtCPmvLbHonC6w==";*/
		
		String esn = "T4CF0052";
		String psKey = "ofpKs1sE0Ye172EKLNkEcw==";
		String mqttPsw = "CPI5gJdy1T7KL394tK+bhg==";
		
		/*String esn = "T4860025";
		String psKey = "Riduc1Mc4U9vJhZaev36ew==";
		String mqttPsw = "QMM2VareTyJQxKr+RjuyYQ==";*/
		
		/*		String esn = "T4CF0052";
		String psKey = "ofpKs1sE0Ye172EKLNkEcw==";
		String mqttPsw = "CPI5gJdy1T7KL394tK+bhg==";*/
		
		String vin = "5LMCJ2ANXFUJ16493";
		String region = "CN";
		
		String MQTT_URL = "tcp://fcne0001vehqa.chinacloudapp.cn:1883";//"tcp://mqa1cnveh.cv.ford.com:1883";
		
		MqttConnectOptions _mqttConnOpt = new MqttConnectOptions();
		_mqttConnOpt.setCleanSession(false);
		_mqttConnOpt.setConnectionTimeout(30);
		_mqttConnOpt.setKeepAliveInterval(30);
		_mqttConnOpt.setUserName(esn);
		_mqttConnOpt.setPassword(mqttPsw.toCharArray());
        
		MqttDefaultFilePersistence dataStore = new MqttDefaultFilePersistence("C:\\temp");
		MqttAsyncClient mqttclient = new MqttAsyncClient(MQTT_URL, StringUtil.generateUniqueClientId(), dataStore);
		
		IMqttToken mqttConnToken = mqttclient.connect(_mqttConnOpt);
		
		try
		{
			mqttConnToken.waitForCompletion();
		} // end-try
		catch (MqttException mqttex)
		{
			if (mqttclient != null)
			{
				mqttclient.close();
				mqttclient = null;
			} // end-if
			throw mqttex;
		} // end-catch
		
		mqttclient.setCallback(new MqttCallback() {
			
			@Override
			public void messageArrived(String topicName, MqttMessage msg) throws Exception {
				System.out.println("+++++ȡ��������: " + topicName);
				
				byte[] syncpBytes = msg.getPayload();
				
				System.out.println("+++++ȡ����Payload(HexString): " + StringUtil.bytesToHexString(syncpBytes));
				String esn = SyncpUtil.get_ESN_From_Syncp_Header(syncpBytes);
				String psKeyB64 = FTCPConstants.ESN_PSKEY_MAP.get(esn);
				byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(syncpBytes, psKeyB64);
				System.out.println("+++++Syncp�������Payload(HexString): " + StringUtil.bytesToHexString(decodedBytes));
				
				if (topicName.contains("TCU_COMMAND")) {
					TCUCommand tucCommand = TCUCommand.parseFrom(decodedBytes);
					System.out.println(tucCommand);
				} 
			}
			
			@Override
			public void deliveryComplete(IMqttDeliveryToken arg0) {
				System.out.println("deliveryComplete");
			}
			
			@Override
			public void connectionLost(Throwable arg0) {
				
			}
		});

		/*List<String> needToSubList = StringUtil.createTCUSubcribeTopics(region, vin);
		
		for(String topic : needToSubList) {
			mqttclient.subscribe(topic, 2);
			System.out.println("Subcribe to topic: " + topic);
		}*/
		
		String topic = StringUtil.getPublishTopic(region, vin, "TCU_ALERT");
		System.out.println(topic);
//		AlertCreativeMock creative = new AlertCreativeMock(esn, vin, 0);
		byte[] cmdBytes = getClearLowTirePressure(esn, vin);//getProvisioningAlert(esn, vin);////////buildTCUConnectionStatusAlert();//buildAlert(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_DATA_MONITOR_VALUE, FTCP3.TCUAlert.AlertType.NON_GENERIC_VALUE);
		
		byte[] bytesToPublish = SyncpUtil.encodeSyncpPacket(cmdBytes, esn, psKey);
		System.out.println(StringUtil.bytesToHexString(bytesToPublish));
		mqttclient.publish(topic, new MqttMessage(bytesToPublish));
		
	}

	public static byte[] getProvisioningAlert(String esn, String vin) {
		TCUAlert.Builder tcuAlertBuilder = TCUAlert.newBuilder();
		tcuAlertBuilder.setAlertType(FTCP.TCUAlert.AlertType.NON_GENERIC);
		TCUNonGenericAlert.Builder tcuNonGenericAlertBuilder = TCUNonGenericAlert.newBuilder();
		tcuNonGenericAlertBuilder.setNonGenericAlertName(FTCP.TCUNonGenericAlert.NonGenericAlertNameEnum.PROVISIONING);
		ProvisioningAlert.Builder provisioningAlertBuilder = ProvisioningAlert.newBuilder();

		CommonFromVehicle.Builder commonFromVehicleBuilder = buildVehicleCommon4Prosisioning(esn, vin);
		provisioningAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
		
		VehicleStatus.Builder vehicleStatus = buildVehicleStatus();
		provisioningAlertBuilder.setVstat(vehicleStatus);
		
		ProvisioningData.Builder provisioningDataBuilder = ProvisioningData.newBuilder();
		provisioningDataBuilder.setImei("352807050109828");
		provisioningDataBuilder.setSimMsisdn("8618621031164");
		provisioningDataBuilder.setSimImsi("460011092629084");
		provisioningDataBuilder.setFirmwareVersionTeseo2("FA1T-14G139-BB");
		provisioningDataBuilder.setFirmwareVersionHe920("14.12.001-B029");
		provisioningDataBuilder.setBusArchitecture(3);
		provisioningDataBuilder.setDestinationRegionCode("CN");
		provisioningAlertBuilder.setProvisioningData(provisioningDataBuilder);
		
		
		tcuNonGenericAlertBuilder.setProvisioningAlert(provisioningAlertBuilder);
		
		tcuAlertBuilder.setNonGenericAlert(tcuNonGenericAlertBuilder);
		TCUAlert tcuAlert = tcuAlertBuilder.build();
		System.out.println("------------\n" + tcuAlert);
		byte alertBytes[] = tcuAlert.toByteArray();
		StringBuilder sb = new StringBuilder();
		for (byte by : alertBytes) 
		{
	        sb.append(String.format("%02X ", by));
	    }
		return tcuAlert.toByteArray();
	}
	
	public static VehicleStatus.Builder buildVehicleStatus()
	{
		VehicleStatus.Builder vehicleStatus = VehicleStatus.newBuilder();
		vehicleStatus.setOdometerMasterValue(0);
		vehicleStatus.setVehLockStatus(1);
		vehicleStatus.setTirePressSystemStat(30);
		vehicleStatus.setVehLockStatus(1); //Duplicate 
		vehicleStatus.setIgnitionStatus(0);
		//new for 1.4.5
		ArrayList<FTCP.WindowPosition> wpal = new ArrayList<FTCP.WindowPosition>();
		FTCP.WindowPosition.Builder wpbldr = FTCP.WindowPosition.newBuilder();
		wpbldr.setWindowType(WindowType.DriverWindowPosition);
		wpbldr.setPosition(0);
		wpal.add(wpbldr.build());
		
		wpbldr = FTCP.WindowPosition.newBuilder();
		wpbldr.setWindowType(WindowType.PassWindowPosition);
		wpbldr.setPosition(1);
		wpal.add(wpbldr.build());

		vehicleStatus.addAllWindowPosition1(wpal);
		
		ArrayList<FTCP.DoorAjarStatus> dajal = new ArrayList<FTCP.DoorAjarStatus>();
		FTCP.DoorAjarStatus.Builder dabldr = FTCP.DoorAjarStatus.newBuilder();
		dabldr.setAjarStatus(0);
		dabldr.setDoorType(DoorType.DrStatHood_B_Actl);
		dajal.add(dabldr.build());

		dabldr.setAjarStatus(1);
		dabldr.setDoorType(DoorType.DrStatDrv_B_Actl);
		dajal.add(dabldr.build());
		
		vehicleStatus.addAllDoorAjarStatus1(dajal);

		vehicleStatus.setPwPckTqDStat(4);
		vehicleStatus.setRemoteDeviceFeedback(1);
		vehicleStatus.setRstrtSettingTActl(1);
		vehicleStatus.setRstrtTActl(1);
		vehicleStatus.setBattULoUActl(1);
		vehicleStatus.setGearLvrPosDActl(1);
		vehicleStatus.setPerimeterAlarmStatus(1);
		vehicleStatus.setPrmtrAlrmEvntDStat(1);
		vehicleStatus.setFuelLvlPcDsply(1);
		vehicleStatus.setEngOilLifePcActl(1);
		vehicleStatus.setVehVActlEng(1);
		vehicleStatus.setFuelRangeLDsply(1);

		FTCP.GPSInfo.Builder gpsbldr = FTCP.GPSInfo.newBuilder();
		FTCP.UTCDateTimeFromCAN.Builder utcbldr = FTCP.UTCDateTimeFromCAN.newBuilder();
		utcbldr.setGpsUtcDayNoActl(0);
		utcbldr.setGPSUTCHours(0);
		gpsbldr.setCANUTCDateTime(utcbldr.build());
		gpsbldr.setGPSActualVsInferPos(0);
		gpsbldr.setGpsBFalt(0);
		gpsbldr.setGPSCompassDirection(0);
		gpsbldr.setGPSDimension(0);
		gpsbldr.setGPSHeading(0);
		gpsbldr.setGpsHsphLattSthDActl(0);
		gpsbldr.setGpsHsphLongEastDActl(0);
		gpsbldr.setGPSMSLAltitude(314);
		gpsbldr.setGPSSpeed(0);
		
		Latitude.Builder latbldr = Latitude.newBuilder();
		latbldr.setGPSLatitudeDegrees(0);
		latbldr.setGPSLatitudeMinDec(0);
		latbldr.setGPSLatitudeMinutes(0);
		gpsbldr.setLatitude(latbldr.build());
		Longitude.Builder longbldr = Longitude.newBuilder();
		longbldr.setGPSLongitudeDegrees(0);
		longbldr.setGPSLongitudeMinDec(0);
		longbldr.setGPSLongitudeMinutes(0);
		gpsbldr.setLongitude(longbldr.build());
		vehicleStatus.setGpsInfo(gpsbldr.build());

		vehicleStatus.setPepsKeyActvDStat(1);
		vehicleStatus.setLifeCycMdeDActl(1);
		vehicleStatus.setVehKeyActvDStat(1);
		
		return vehicleStatus;
		
	}
	
	public static byte[] getClearLowTirePressure(String esn, String vin) {
		TCUAlert.Builder tcuAlertBuilder = TCUAlert.newBuilder();
		tcuAlertBuilder.setAlertType(FTCP.TCUAlert.AlertType.GENERIC);
		TCUGenericAlert.Builder tcuGenericAlertBuilder = TCUGenericAlert.newBuilder();
		tcuGenericAlertBuilder.setGenericAlertName(FTCP.TCUGenericAlert.GenericAlertNameEnum.CLEAR_LOW_TIRE_PRESSURE);
		ClearLowTirePressureAlert.Builder clearLowTirePressureAlertBuilder = ClearLowTirePressureAlert.newBuilder();
		
		CommonFromVehicle.Builder commonFromVehicleBuilder = buildVehicleCommon(esn, vin);
		
		clearLowTirePressureAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
		tcuGenericAlertBuilder.setClearLowTirePressureAlert(clearLowTirePressureAlertBuilder);
		
		tcuAlertBuilder.setGenericAlert(tcuGenericAlertBuilder);
		
		TCUAlert tcuAlert = tcuAlertBuilder.build();
		
		byte alertBytes[] = tcuAlert.toByteArray();
		StringBuilder sb = new StringBuilder();
		for (byte by : alertBytes) 
		{
	        sb.append(String.format("%02X ", by));
	    }
		return tcuAlert.toByteArray();
	}
	
	public static CommonFromVehicle.Builder buildVehicleCommon4Prosisioning(String esn, String vin)
	{
		UTCDateTime.Builder utcDateTimeBuilder = UTCDateTime.newBuilder();
		CommonFromVehicle.Builder commonFromVehicleBuilder = CommonFromVehicle.newBuilder();
		
		commonFromVehicleBuilder.setModemUTCDateTime(buildUTCDateTime(utcDateTimeBuilder));
		commonFromVehicleBuilder.setVin(vin);
		commonFromVehicleBuilder.setEsn(esn);
		commonFromVehicleBuilder.setIccid("89860114623100287898");
		commonFromVehicleBuilder.setHardwarePartNumber("FA1T-14G145-AA");
		commonFromVehicleBuilder.setFirmwareVersion("1.2.5");
		commonFromVehicleBuilder.setAssemblyPartNumber("FA1T-14G087-AC");
		commonFromVehicleBuilder.setStrategyPartNumber("FA1T-14G139-BB");
		commonFromVehicleBuilder.setGlobalConfigVersion("2.1.10.m");
		commonFromVehicleBuilder.setConfigPartNumber("FA1T-14G144-BBA");
		commonFromVehicleBuilder.setTcuMessageId(745);
		commonFromVehicleBuilder.setCorrelationId(0);
		commonFromVehicleBuilder.setAuthStatus(FTCP.AuthStatusEnum.WAITING_FOR_PROVISIONING_ACK);
		commonFromVehicleBuilder.setProtofileVersion("1.4.7");
		
		commonFromVehicleBuilder.setInCarHecTime(FTCP.HECDateTime.getDefaultInstance());
		
		return commonFromVehicleBuilder;
	}
	
	public static CommonFromVehicle.Builder buildVehicleCommon(String esn, String vin)
	{
		UTCDateTime.Builder utcDateTimeBuilder = UTCDateTime.newBuilder();
		CommonFromVehicle.Builder commonFromVehicleBuilder = CommonFromVehicle.newBuilder();
		
		commonFromVehicleBuilder.setModemUTCDateTime(buildUTCDateTime(utcDateTimeBuilder));
		commonFromVehicleBuilder.setVin(vin);
		commonFromVehicleBuilder.setEsn(esn);
		commonFromVehicleBuilder.setIccid("89860114623100287757");
		commonFromVehicleBuilder.setHardwarePartNumber("FA1T-14G145-AA");
		commonFromVehicleBuilder.setFirmwareVersion("1.2.4");
		commonFromVehicleBuilder.setAssemblyPartNumber("FA1T-14G087-AC");
		commonFromVehicleBuilder.setStrategyPartNumber("FA1T-14G139-BA");
		commonFromVehicleBuilder.setGlobalConfigVersion("2.1.9.m");
		commonFromVehicleBuilder.setConfigPartNumber("FA1T-14G144-BA");
		commonFromVehicleBuilder.setTcuMessageId(1431656473);
		commonFromVehicleBuilder.setCorrelationId(0);
		commonFromVehicleBuilder.setAuthStatus(FTCP.AuthStatusEnum.AUTHORIZED);
		commonFromVehicleBuilder.setProtofileVersion("1.4.7");
		
		commonFromVehicleBuilder.setInCarHecTime(FTCP.HECDateTime.getDefaultInstance());
		
		return commonFromVehicleBuilder;
	}
	
	private static UTCDateTime.Builder buildUTCDateTime(UTCDateTime.Builder utcDateTimeBuilder){
		
		GregorianCalendar date = new GregorianCalendar();
		utcDateTimeBuilder/*.setGpsUtcYrNoActl*/.setUTCYear(date.get(Calendar.YEAR));
		utcDateTimeBuilder/*.setGpsUtcMnthNoActl*/.setUTCMonth(date.get(Calendar.MONTH));
		utcDateTimeBuilder/*.setGpsUtcDayNoActl*/.setUTCDay(date.get(Calendar.DAY_OF_MONTH));
		utcDateTimeBuilder/*.setGPSUTCHours*/.setUTCHour(date.get(Calendar.HOUR));
		utcDateTimeBuilder/*.setGPSUTCMinutes*/.setUTCMin(date.get(Calendar.MINUTE));
		utcDateTimeBuilder/*.setGPSUTCSeconds*/.setUTCSecond(date.get(Calendar.SECOND));
		
		return utcDateTimeBuilder;
	}
}
