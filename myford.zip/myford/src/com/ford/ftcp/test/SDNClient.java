package com.ford.ftcp.test;

import java.util.Date;
import java.util.List;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;

import com.ford.ftcp.FTCP3.GPSInfo;
import com.ford.ftcp.FTCP3.HEVBatteryData;
import com.ford.ftcp.FTCP3.TCUAlert;
import com.ford.ftcp.FTCP3.TCUCommandResponse;
import com.ford.ftcp.FTCP3.TCUConnectionStatusAlert;
import com.ford.ftcp.FTCP3.VehicleStatus;
import com.ford.ftcp.util.FTCPConstants;
import com.ford.ftcp.util.StringUtil;
import com.ford.ftcp.util.SyncpUtil;
import com.fp.domain.VehicleBean;
import com.fp.service.VehicleService;
import com.google.protobuf.InvalidProtocolBufferException;

public class SDNClient {

	private VehicleService service;
	public VehicleService getService() {
		return service;
	}
	public void setService(VehicleService service) {
		this.service = service;
	}
	
	private MqttAsyncClient mqttclient;
	String vin = "5LMCJ2A90FUJ00101";
	String region = "CN";
	
	public static void main(String[] args) {
		SDNClient sdnClient = new SDNClient();
		sdnClient.connectMQTT();
		sdnClient.subcribeTopics();
	}
	
	private void subcribeTopics() {
		try {
			List<String> needToSubList = StringUtil.createSDNSubcribeTopics(region, vin);
			
			for(String topic : needToSubList) {
				mqttclient.subscribe(topic, 2);
				System.out.println("Subcribe to topic: " + topic);
			} 
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public MqttAsyncClient getMQTTClient() throws MqttException, InvalidProtocolBufferException {
		MqttConnectOptions _mqttConnOpt = new MqttConnectOptions();
		_mqttConnOpt.setCleanSession(false);
		_mqttConnOpt.setConnectionTimeout(30);
		_mqttConnOpt.setKeepAliveInterval(30);
		
		MqttDefaultFilePersistence dataStore = new MqttDefaultFilePersistence("C:\\temp");
		MqttAsyncClient mqttclient = new MqttAsyncClient(FTCPConstants.MQTT_URL, StringUtil.generateUniqueClientId(), dataStore);
		
		IMqttToken mqttConnToken = mqttclient.connect(_mqttConnOpt);
		
		try
		{
			mqttConnToken.waitForCompletion();
		} // end-try
		catch (MqttException mqttex)
		{
			if (mqttclient != null)
			{
				mqttclient.close();
				mqttclient = null;
			} // end-if
			throw mqttex;
		} // end-catch
		return mqttclient;
	}

	public void initMQTT() {
		connectMQTT();
		subcribeTopics();
	}
	private void connectMQTT() {
		try {
			mqttclient = getMQTTClient();
			mqttclient.setCallback(new MqttCallback() {

				@Override
				public void messageArrived(String topicName, MqttMessage msg)
						throws Exception {
					System.out.println("+++++ȡ��������: " + topicName);

					byte[] syncpBytes = msg.getPayload();

					System.out.println("+++++ȡ����Payload(HexString): "
							+ StringUtil.bytesToHexString(syncpBytes));
					String esn = SyncpUtil
							.get_ESN_From_Syncp_Header(syncpBytes);
					String psKeyB64 = FTCPConstants.ESN_PSKEY_MAP.get(esn);
					byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(
							syncpBytes, psKeyB64);
					System.out.println("+++++Syncp�������Payload(HexString): "
							+ StringUtil.bytesToHexString(decodedBytes));

					if (topicName.contains("TCU_ALERT")) {
						TCUAlert alert = TCUAlert.parseFrom(decodedBytes);
						System.out.println(alert);
						/*GPSInfo gpsInfo = alert.getNonGenericAlert().getHevDataMonitoringAlert().getHevVehicleStatus().getGpsInfo();
						int GPS_Latitude_Degrees = gpsInfo.getShiftedGPSInfo().getLatitude().getGPSLatitudeDegrees();
						int GPS_Latitude_Min_dec = gpsInfo.getLatitude().getGPSLatitudeMinDec();
						int GPS_Latitude_Minutes = gpsInfo.getLatitude().getGPSLatitudeMinutes();
						int GPS_Longitude_Degrees = gpsInfo.getLongitude().getGPSLongitudeDegrees();
						int GPS_Longitude_Min_dec = gpsInfo.getLongitude().getGPSLongitudeMinDec();
						int GPS_Longitude_Minutes = gpsInfo.getLongitude().getGPSLongitudeMinutes();
						VehicleStatus hevVehicleStatus = alert.getNonGenericAlert().getHevDataMonitoringAlert().getHevVehicleStatus();
						HEVBatteryData hevBatteryData = alert.getNonGenericAlert().getHevDataMonitoringAlert().getHevBatteryData();
						VehicleBean vehicleBean = new VehicleBean();
						
						String vin = alert.getNonGenericAlert().getHevDataMonitoringAlert().getVehicleCommon().getVin();
						vehicleBean.setVin(vin);
						vehicleBean.setEsn(esn);
						double lat = GPS_Latitude_Degrees + (GPS_Latitude_Minutes + GPS_Latitude_Min_dec*0.0001)/60;
						vehicleBean.setLat(lat);
						double lng = GPS_Longitude_Degrees + (GPS_Longitude_Minutes + GPS_Longitude_Min_dec*0.0001)/60;
						vehicleBean.setLng(lng);
						int GPS_Speed = gpsInfo.getGPSSpeed();
						vehicleBean.setGPSSpeed(GPS_Speed);
						int GPS_Compass_direction = gpsInfo.getGPSCompassDirection();
						vehicleBean.setGPSCompassDirection(GPS_Compass_direction);
						int GPS_Heading = gpsInfo.getGPSHeading();
						vehicleBean.setGPSHeading(GPS_Heading);
						
						int Ignition_status = hevVehicleStatus.getIgnitionStatus();
						vehicleBean.setIgnitionStatus(Ignition_status);
						int Veh_V_ActlEng = hevVehicleStatus.getVehVActlEng();
						vehicleBean.setVehVActlEng(Veh_V_ActlEng);
						int OdometerMasterValue = hevVehicleStatus.getOdometerMasterValue();
						vehicleBean.setOdometerMasterValue(OdometerMasterValue);
						int FuelRange_L_Dsply = hevVehicleStatus.getFuelRangeLDsply();
						vehicleBean.setFuelRangeLDsply(FuelRange_L_Dsply);
						int GearLvrPos_D_Actl = hevVehicleStatus.getGearLvrPosDActl();
						vehicleBean.setGearLvrPosDActl(GearLvrPos_D_Actl);
						int BpedDrvAppl_D_Actl = hevVehicleStatus.getBpedDrvApplDActl().getNumber();// TODO
						vehicleBean.setBpedDrvApplDActl(BpedDrvAppl_D_Actl);
						int ApedPos_Pc_ActlArb = hevVehicleStatus.getApedPosPcActlArb();
						vehicleBean.setApedPosPcActlArb(ApedPos_Pc_ActlArb);
						int EngAout_N_Actl = hevVehicleStatus.getEngAoutNActl();
						vehicleBean.setEngAoutNActl(EngAout_N_Actl);
						int EngClnt_Te_Actl = hevVehicleStatus.getEngClntTeActl();
						vehicleBean.setEngClntTeActl(EngClnt_Te_Actl);
						int EngSrvcRqd_B_Rq = hevVehicleStatus.getEngSrvcRqdBRq();
						vehicleBean.setEngSrvcRqdBRq(EngSrvcRqd_B_Rq);
						int FuelLvl_Pc_Dsply = hevVehicleStatus.getFuelLvlPcDsply();
						vehicleBean.setFuelLvlPcDsply(FuelLvl_Pc_Dsply);
						int AirAmb_Te_ActlFilt = hevVehicleStatus.getAirAmbTeActlFilt();
						vehicleBean.setAirAmbTeActlFilt(AirAmb_Te_ActlFilt);
						int PrplWhlTot2_Tq_Actl = hevVehicleStatus.getPrplWhlTot2TqActl();
						vehicleBean.setPrplWhlTot2TqActl(PrplWhlTot2_Tq_Actl);
						int PwPckTq_D_Stat = hevVehicleStatus.getPwPckTqDStat();
						vehicleBean.setPwPckTqDStat(PwPckTq_D_Stat);
						int BSBattSOC = hevVehicleStatus.getBSBattSOC();
						vehicleBean.setbSBattSOC(BSBattSOC);
						
						int BattTrac_U_Actl = hevBatteryData.getBattTracUActl();
						vehicleBean.setBattTracUActl(BattTrac_U_Actl);
						int BattTrac_I_Actl = hevBatteryData.getBattTracIActl();
						vehicleBean.setBattTracIActl(BattTrac_I_Actl);
						int BattTracSoc2_Pc_Actl = hevBatteryData.getBattTracSoc2PcActl();
						vehicleBean.setBattTracSoc2PcActl(BattTracSoc2_Pc_Actl);
						int BattTrac_Te_Actl = hevBatteryData.getBattTracTeActl();
						vehicleBean.setBattTracTeActl(BattTrac_Te_Actl);
						int VehStrtInhbt_B_RqBatt = hevBatteryData.getVehStrtInhbtBRqBatt();
						vehicleBean.setVehStrtInhbtBRqBatt(VehStrtInhbt_B_RqBatt);
						int BattTracOff_B_Actl = hevBatteryData.getBattTracOffBActl();
						vehicleBean.setBattTracOffBActl(BattTracOff_B_Actl);
						int BattTrac_Pw_LimChrg = hevBatteryData.getBattTracPwLimChrg();
						vehicleBean.setBattTracPwLimChrg(BattTrac_Pw_LimChrg);
						int BattTrac_Pw_LimDchrg = hevBatteryData.getBattTracPwLimDchrg();
						vehicleBean.setBattTracOffFstDActl(BattTrac_Pw_LimDchrg);
						int BattTracOffFst_D_Actl = hevBatteryData.getBattTracOffFstDActl();
						vehicleBean.setBattTracOffFstDActl(BattTracOffFst_D_Actl);
						int BattTracWarnLamp_B_Rq = hevVehicleStatus.getBattTracWarnLampBRq();
						vehicleBean.setBattTracWarnLampBRq(BattTracWarnLamp_B_Rq);
						int BattTracSrvcRqd_B_Rq = hevVehicleStatus.getBattTracSrvcRqdBRq();
						vehicleBean.setBattTracSrvcRqdBRq(BattTracSrvcRqd_B_Rq);
						vehicleBean.setInsertDate(new Date());
						
						service.insertVehicleRecord(vehicleBean);*/
						
					} else if (topicName.contains("COMMAND_RESPONSE")) {
						TCUCommandResponse commandResponse = TCUCommandResponse
								.parseFrom(decodedBytes);
						System.out.println(commandResponse);
					} else if (topicName
							.contains("TCU_CONNECTION_STATUS_ALERT")) {
						TCUConnectionStatusAlert connectAlert = TCUConnectionStatusAlert
								.parseFrom(decodedBytes);
						System.out.println(connectAlert);
					}
				}

				@Override
				public void deliveryComplete(IMqttDeliveryToken arg0) {

				}

				@Override
				public void connectionLost(Throwable arg0) {
					System.out.println("connectionLost");
				}
			});
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
