package com.ford.ftcp.test;

import java.util.Calendar;

public class TestDateDiff {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
        int hour=cal.get(Calendar.HOUR_OF_DAY);//小时 
        if (hour>=8 && hour<=18)
        System.out.println(hour);
	}
	
}
