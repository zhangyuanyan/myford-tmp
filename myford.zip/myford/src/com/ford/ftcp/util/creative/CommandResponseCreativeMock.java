package com.ford.ftcp.util.creative;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;

import com.ford.ftcp.FTCP3;
import com.ford.ftcp.FTCP3.CommonFromVehicle;
import com.ford.ftcp.FTCP3.NonTimeSensitiveCommandNameEnum;
import com.ford.ftcp.FTCP3.NonTimeSensitiveCommandResponse;
import com.ford.ftcp.FTCP3.TCUCommandResponse;
import com.ford.ftcp.FTCP3.UTCDateTime;
import com.ford.ftcp.FTCP3.VehicleDiagnosticDataRequestCommandResponse;
import com.ford.ftcp.FTCP3.VehicleStatus;

public class CommandResponseCreativeMock {

	private String esn = "";
	private String vin = "";
	private int correlationId = 0;
	
	public CommandResponseCreativeMock(String esn, String vin, int correlationId) {
		super();
		this.esn = esn;
		this.vin = vin;
		this.correlationId = correlationId;
	}
	
	private static Random random = new Random();
	private static int generateRandom(){
		int randomId = random.nextInt(999999999);
		return randomId;
	}
	
	private static UTCDateTime.Builder buildUTCDateTime(UTCDateTime.Builder utcDateTimeBuilder){
		
		GregorianCalendar date = new GregorianCalendar();
		utcDateTimeBuilder/*.setGpsUtcYrNoActl*/.setUTCYear(date.get(Calendar.YEAR));
		utcDateTimeBuilder/*.setGpsUtcMnthNoActl*/.setUTCMonth(date.get(Calendar.MONTH));
		utcDateTimeBuilder/*.setGpsUtcDayNoActl*/.setUTCDay(date.get(Calendar.DAY_OF_MONTH));
		utcDateTimeBuilder/*.setGPSUTCHours*/.setUTCHour(date.get(Calendar.HOUR));
		utcDateTimeBuilder/*.setGPSUTCMinutes*/.setUTCMin(date.get(Calendar.MINUTE));
		utcDateTimeBuilder/*.setGPSUTCSeconds*/.setUTCSecond(date.get(Calendar.SECOND));
		
		return utcDateTimeBuilder;
	}
	
	public static CommonFromVehicle.Builder buildVehicleCommon(String esn, String vin, int correlationId)
	{
		UTCDateTime.Builder utcDateTimeBuilder = UTCDateTime.newBuilder();
		CommonFromVehicle.Builder commonFromVehicleBuilder = CommonFromVehicle.newBuilder();
		if (correlationId == 0) {
			commonFromVehicleBuilder.setCorrelationId(new Integer(generateRandom()));
		} else {
			commonFromVehicleBuilder.setCorrelationId(correlationId);
		}
		commonFromVehicleBuilder.setTcuMessageId(new Integer(generateRandom()));
		commonFromVehicleBuilder.setEsn(esn);
//		commonFromVehicleBuilder.setFirmwareVersion("2.1.1");
//		commonFromVehicleBuilder.setGlobalConfigVersion("2.1.1MFM3.1.0");
		commonFromVehicleBuilder.setVin(vin);
		commonFromVehicleBuilder.setModemUTCDateTime(buildUTCDateTime(utcDateTimeBuilder));
		//new for 1.4.5
		commonFromVehicleBuilder.setIccid("4321");
//		commonFromVehicleBuilder.setHardwarePartNumber("123");
//		commonFromVehicleBuilder.setStrategyPartNumber("1234");
//		commonFromVehicleBuilder.setConfigPartNumber("321");
		//commonFromVehicleBuilder.setAuthStatus(FTCP.AuthStatusEnum.FACTORY_MODE);
		
		commonFromVehicleBuilder.setAuthStatus(FTCP3.AuthStatusEnum.AUTHORIZED);
		commonFromVehicleBuilder.setInCarHecTime(FTCP3.HECDateTime.getDefaultInstance());
//		commonFromVehicleBuilder.setProtofileVersion("1.4.5");
		return commonFromVehicleBuilder;
	}
	
	private VehicleStatus.Builder buildVehicleStatus()
	{
		VehicleStatus.Builder vehicleStatus = VehicleStatus.newBuilder();
		vehicleStatus.setOdometerMasterValue(generateRandom());
		vehicleStatus.setVehLockStatus(1);
		vehicleStatus.setTirePressSystemStat(30);
		vehicleStatus.setVehLockStatus(1);
		vehicleStatus.setIgnitionStatus(0);
		
		return vehicleStatus;
		
	}
	
	public byte[] buildCommandResponse() {
		VehicleStatus.Builder vehicleStatus = buildVehicleStatus();
		
		CommonFromVehicle.Builder commonFromVehicleBuilder = buildVehicleCommon(esn,vin, correlationId);

		TCUCommandResponse.Builder tcuCommandResponseBuilder=null;
		
		NonTimeSensitiveCommandResponse.Builder nonTimeSensitiveCommandResponseBuilder = NonTimeSensitiveCommandResponse.newBuilder();
		
		nonTimeSensitiveCommandResponseBuilder.setNonTimeSensitiveCommandResponseNameEnum(NonTimeSensitiveCommandNameEnum.VEHICLE_DIAGNOSTIC_DATA_REQUEST);
		VehicleDiagnosticDataRequestCommandResponse.Builder vehicleDiagnosticDataRequestCommandResponse = VehicleDiagnosticDataRequestCommandResponse.newBuilder();
		

		vehicleDiagnosticDataRequestCommandResponse.setVehicleCommon(commonFromVehicleBuilder);
		vehicleDiagnosticDataRequestCommandResponse.setStatus(FTCP3.CommandStatusEnum.SUCCESS );
		vehicleDiagnosticDataRequestCommandResponse.setVstat(vehicleStatus);
		
		nonTimeSensitiveCommandResponseBuilder.setVehicleDiagnosticDataRequestCommandResponse(vehicleDiagnosticDataRequestCommandResponse);
		tcuCommandResponseBuilder = TCUCommandResponse.newBuilder();
		tcuCommandResponseBuilder.setCommandResponseType(FTCP3.TCUCommandResponse.CommandResponseType.NON_TIME_SENSITIVE);
		tcuCommandResponseBuilder.setNonTimeSensitiveCommandResponse(nonTimeSensitiveCommandResponseBuilder);
		
		TCUCommandResponse tcuCommandResponse = tcuCommandResponseBuilder.build();
		
		byte cmdBytes[] = tcuCommandResponse.toByteArray();
		StringBuilder sb = new StringBuilder();
		for (byte by : cmdBytes) 
		{
			sb.append(String.format("%02X ", by));
			
		}
		
		return tcuCommandResponse.toByteArray();
	}
}
