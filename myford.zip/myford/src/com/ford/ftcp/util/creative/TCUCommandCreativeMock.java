package com.ford.ftcp.util.creative;

import com.ford.ftcp.FTCP3;
import com.ford.ftcp.FTCP3.CancelRemoteStartCommand;
import com.ford.ftcp.FTCP3.ClearUserSettingsCommand;
import com.ford.ftcp.FTCP3.CommonFromCloud;
import com.ford.ftcp.FTCP3.InitiateRemoteStartCommand;
import com.ford.ftcp.FTCP3.LockCommand;
import com.ford.ftcp.FTCP3.NonTimeSensitiveCommand;
import com.ford.ftcp.FTCP3.ProvisioningDataRequestCommand;
import com.ford.ftcp.FTCP3.TCUCommand;
import com.ford.ftcp.FTCP3.TimeSensitiveCommand;
import com.ford.ftcp.FTCP3.UTCDateTime;
import com.ford.ftcp.FTCP3.UnlockCommand;
import com.ford.ftcp.FTCP3.UserAuthorizationCommand;
import com.ford.ftcp.FTCP3.VehicleDiagnosticData;
import com.ford.ftcp.FTCP3.VehicleDiagnosticData.DiagnosticStateEnum;
import com.ford.ftcp.FTCP3.VehicleDiagnosticDataRequestCommand;
import com.ford.ftcp.FTCP3.VehicleStatusUpdateCommand;
import com.ford.ftcp.util.StringUtil;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

public class TCUCommandCreativeMock {

	private String esn = "";
	public TCUCommandCreativeMock(String esn, String vin) {
		super();
		this.esn = esn;
		this.vin = vin;
	}

	private String vin = "";
	private FTCP3.AuthStatusEnum authStatusParam = FTCP3.AuthStatusEnum.FACTORY_MODE;
	public FTCP3.AuthStatusEnum getAuthStatusParam() {
		return authStatusParam;
	}

	public void setAuthStatusParam(FTCP3.AuthStatusEnum authStatusParam) {
		this.authStatusParam = authStatusParam;
	}

	public FTCP3.AuthorizationRequestType getAuthRequestType() {
		return authRequestType;
	}

	public void setAuthRequestType(FTCP3.AuthorizationRequestType authRequestType) {
		this.authRequestType = authRequestType;
	}

	private FTCP3.AuthorizationRequestType authRequestType = FTCP3.AuthorizationRequestType.FINAL;
	
	private int cloundMessageId;
	
	public int getCloundMessageId() {
		return cloundMessageId;
	}

	public void setCloundMessageId(int cloundMessageId) {
		this.cloundMessageId = cloundMessageId;
	}

	public byte[] createTCUCommandByteArray(int command, int commandType)
			throws InvalidProtocolBufferException {
		
		TCUCommand.Builder tcuCommandBuilder = TCUCommand.newBuilder();
		CommonFromCloud.Builder cloudCommonBuilder = CommonFromCloud.newBuilder();
		UTCDateTime.Builder utcDateTimeBuilder = UTCDateTime.newBuilder();
		
		cloudCommonBuilder.setCloudUTCDateTime(StringUtil.buildUTCDateTime(utcDateTimeBuilder));
		
		cloundMessageId = StringUtil.generateRandom();
		cloudCommonBuilder.setCloudMessageId(cloundMessageId);
		
//		cloudCommonBuilder.setCorrelationId(StringUtil.generateRandom());
	
		if(commandType == FTCP3.TCUCommand.TCUCommandType.TIME_SENSITIVE_VALUE)
		{
			tcuCommandBuilder.setTcuCommandType(FTCP3.TCUCommand.TCUCommandType.TIME_SENSITIVE);
			
			TimeSensitiveCommand.Builder timeSensitiveCommandBuilder = TimeSensitiveCommand.newBuilder();
			
			if(command == FTCP3.TimeSensitiveCommandNameEnum.VSTAT_UPDATE_VALUE){
				timeSensitiveCommandBuilder.setTimeSensitiveCommandName(FTCP3.TimeSensitiveCommandNameEnum.VSTAT_UPDATE);
				VehicleStatusUpdateCommand.Builder vStatUpdateCommandBuilder = VehicleStatusUpdateCommand.newBuilder();
				vStatUpdateCommandBuilder.setCloudCommon(cloudCommonBuilder);
				timeSensitiveCommandBuilder.setVehicleStatusUpdateCommand(vStatUpdateCommandBuilder);
			}else if(command == FTCP3.TimeSensitiveCommandNameEnum.INITIATE_REMOTE_START_VALUE){
				timeSensitiveCommandBuilder.setTimeSensitiveCommandName(FTCP3.TimeSensitiveCommandNameEnum.INITIATE_REMOTE_START);				
				InitiateRemoteStartCommand.Builder initiateRemoteStartCommandBuilder = InitiateRemoteStartCommand.newBuilder();
				initiateRemoteStartCommandBuilder.setCloudCommon(cloudCommonBuilder);
				timeSensitiveCommandBuilder.setInitiateRemoteStartCommand(initiateRemoteStartCommandBuilder);
			}else if(command == FTCP3.TimeSensitiveCommandNameEnum.CANCEL_REMOTE_START_VALUE){
				timeSensitiveCommandBuilder.setTimeSensitiveCommandName(FTCP3.TimeSensitiveCommandNameEnum.CANCEL_REMOTE_START);				
				CancelRemoteStartCommand.Builder cancelRemoteStartCommandBuilder = CancelRemoteStartCommand.newBuilder();
				cancelRemoteStartCommandBuilder.setCloudCommon(cloudCommonBuilder);
				timeSensitiveCommandBuilder.setCancelRemoteStartCommand(cancelRemoteStartCommandBuilder);
			}else if(command == FTCP3.TimeSensitiveCommandNameEnum.LOCK_VALUE){
				timeSensitiveCommandBuilder.setTimeSensitiveCommandName(FTCP3.TimeSensitiveCommandNameEnum.LOCK);
				LockCommand.Builder lockCommandBuilder = LockCommand.newBuilder();
				lockCommandBuilder.setCloudCommon(cloudCommonBuilder);
				timeSensitiveCommandBuilder.setLockCommand(lockCommandBuilder);
			}else if(command == FTCP3.TimeSensitiveCommandNameEnum.UNLOCK_VALUE){
				timeSensitiveCommandBuilder.setTimeSensitiveCommandName(FTCP3.TimeSensitiveCommandNameEnum.UNLOCK);
				UnlockCommand.Builder unlockCommandBuilder = UnlockCommand.newBuilder();
				unlockCommandBuilder.setCloudCommon(cloudCommonBuilder);
				timeSensitiveCommandBuilder.setUnlockCommand(unlockCommandBuilder);
			}else if(command == FTCP3.TimeSensitiveCommandNameEnum.CLEAR_USER_SETTINGS_VALUE){
				timeSensitiveCommandBuilder.setTimeSensitiveCommandName(FTCP3.TimeSensitiveCommandNameEnum.CLEAR_USER_SETTINGS);
				ClearUserSettingsCommand.Builder clearUserSettingsCommandBuilder = ClearUserSettingsCommand.newBuilder();
				clearUserSettingsCommandBuilder.setCloudCommon(cloudCommonBuilder);
				timeSensitiveCommandBuilder.setClrUserSettingsCommand(clearUserSettingsCommandBuilder);
			} 

			tcuCommandBuilder.setTimeSensitiveCommand(timeSensitiveCommandBuilder);
			
		}
		else if(commandType == FTCP3.TCUCommand.TCUCommandType.NON_TIME_SENSITIVE_VALUE)
		{
			tcuCommandBuilder.setTcuCommandType(FTCP3.TCUCommand.TCUCommandType.NON_TIME_SENSITIVE);

			NonTimeSensitiveCommand.Builder nonTimeSensitiveCommandBuilder = NonTimeSensitiveCommand.newBuilder();
			
			if(command == FTCP3.NonTimeSensitiveCommandNameEnum.PROVISIONING_DATA_REQUEST_VALUE){ //LR
				nonTimeSensitiveCommandBuilder.setNonTimeSensitiveCommandName(FTCP3.NonTimeSensitiveCommandNameEnum.PROVISIONING_DATA_REQUEST);
				ProvisioningDataRequestCommand.Builder provisioningDataRequestCommandBuilder = ProvisioningDataRequestCommand.newBuilder();
				provisioningDataRequestCommandBuilder.setCloudCommon(cloudCommonBuilder);
				nonTimeSensitiveCommandBuilder.setProvisioningDataRequestCommand(provisioningDataRequestCommandBuilder);
			}
			else if(command == FTCP3.NonTimeSensitiveCommandNameEnum.USER_AUTHORIZATION_VALUE){
				
				nonTimeSensitiveCommandBuilder.setNonTimeSensitiveCommandName(FTCP3.NonTimeSensitiveCommandNameEnum.USER_AUTHORIZATION);
				UserAuthorizationCommand.Builder userAuthorizationCommandBuilder = UserAuthorizationCommand.newBuilder();
				userAuthorizationCommandBuilder.setCloudCommon(cloudCommonBuilder);
				userAuthorizationCommandBuilder.setRequestType(authRequestType);
				nonTimeSensitiveCommandBuilder.setUserAuthorizationCommand(userAuthorizationCommandBuilder);
			}
			else if(command == FTCP3.NonTimeSensitiveCommandNameEnum.VEHICLE_DIAGNOSTIC_DATA_REQUEST_VALUE){
				
				nonTimeSensitiveCommandBuilder.setNonTimeSensitiveCommandName(FTCP3.NonTimeSensitiveCommandNameEnum.VEHICLE_DIAGNOSTIC_DATA_REQUEST);
				
				VehicleDiagnosticDataRequestCommand.Builder diagnosticDataRequestCommandBuilder = VehicleDiagnosticDataRequestCommand.newBuilder();
				diagnosticDataRequestCommandBuilder.setCloudCommon(cloudCommonBuilder);
				
				VehicleDiagnosticData.Builder vehicleDiagnosticData = VehicleDiagnosticData.newBuilder();
				vehicleDiagnosticData.setTargetECUId(1);
				byte[] bytes = {1,1};
				ByteString bs = ByteString.copyFrom(bytes);
				vehicleDiagnosticData.setDiagnosticRequestDataFromCloud(bs);
				vehicleDiagnosticData.setDiagnosticRequestExpiration(StringUtil.buildUTCDateTime(utcDateTimeBuilder));
				vehicleDiagnosticData.setDiagnosticState(DiagnosticStateEnum.KOEC);
				diagnosticDataRequestCommandBuilder.setDiagnosticData(vehicleDiagnosticData);
				
				nonTimeSensitiveCommandBuilder.setVehicleDiagnosticDataRequestCommand(diagnosticDataRequestCommandBuilder);
			}
			tcuCommandBuilder.setNonTimeSensitiveCommand(nonTimeSensitiveCommandBuilder);
		}
		TCUCommand tcuCommand = tcuCommandBuilder.build();
		System.out.println("TCUCommand for publish :\n\r" + tcuCommand);
		byte cmdBytes[] = tcuCommand.toByteArray();
		StringBuilder sb = new StringBuilder();
		for (byte by : cmdBytes) {
	        sb.append(String.format("%02X ", by));
//	        logger.info(sb);
	    }
		return tcuCommand.toByteArray();
	} 

}
