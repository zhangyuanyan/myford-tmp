package com.ford.ftcp.util.creative;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;

import com.ford.ftcp.FTCP3;
import com.ford.ftcp.FTCP3.AlarmTriggeredAlert;
import com.ford.ftcp.FTCP3.AuthorizationRequestType;
import com.ford.ftcp.FTCP3.ClearHEVBatteryFaultAlert;
import com.ford.ftcp.FTCP3.ClearLow12VBatteryAlert;
import com.ford.ftcp.FTCP3.ClearLowTirePressureAlert;
import com.ford.ftcp.FTCP3.CommonFromVehicle;
import com.ford.ftcp.FTCP3.ECUData;
import com.ford.ftcp.FTCP3.ECUData.DTCInfo;
import com.ford.ftcp.FTCP3.HEVBatteryData;
import com.ford.ftcp.FTCP3.HEVBatteryFaultAlert;
import com.ford.ftcp.FTCP3.HEVDataMonitoringAlert;
import com.ford.ftcp.FTCP3.Low12VBatteryAlert;
import com.ford.ftcp.FTCP3.LowTirePressureAlert;
import com.ford.ftcp.FTCP3.MasterResetAlert;
import com.ford.ftcp.FTCP3.MotiveModeBeginAlert;
import com.ford.ftcp.FTCP3.MotiveModeEndAlert;
import com.ford.ftcp.FTCP3.ProvisioningAlert;
import com.ford.ftcp.FTCP3.ProvisioningData;
import com.ford.ftcp.FTCP3.RemoteStartBeginAlert;
import com.ford.ftcp.FTCP3.RemoteStartEndAlert;
import com.ford.ftcp.FTCP3.ShiftedGPSInfo;
import com.ford.ftcp.FTCP3.SleepStateChangeAlert;
import com.ford.ftcp.FTCP3.TCUAlert;
import com.ford.ftcp.FTCP3.TCUConnectionStatusAlert;
import com.ford.ftcp.FTCP3.TCUConnectionStatusAlert.TCUConnectionStatusEnum;
import com.ford.ftcp.FTCP3.TCUGenericAlert;
import com.ford.ftcp.FTCP3.TCUNonGenericAlert;
import com.ford.ftcp.FTCP3.UTCDateTime;
import com.ford.ftcp.FTCP3.UserAuthorizationResponseAlert;
import com.ford.ftcp.FTCP3.VehicleDiagnosticData;
import com.ford.ftcp.FTCP3.VehicleDiagnosticDataResponseAlert;
import com.ford.ftcp.FTCP3.VehicleDiagnosticDataResponseAlert.DiagnosticRequestStatusEnum;
import com.ford.ftcp.FTCP3.VehicleDiagnosticResponseData;
import com.ford.ftcp.FTCP3.VehicleStatus;
import com.ford.ftcp.FTCP3.VehicleStatus.BpedDrvApplENUM;
import com.fp.domain.BFDTCInfo;
import com.fp.domain.BatteryFault;
import com.fp.domain.TcuVehicle;
import com.fp.domain.VehicleBean;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

public class AlertCreativeMock {
	private String esn = "";
	private String vin = "";
	private String imei = "";
	private String iccid = "";
	private String msisdn = "";
	private String simImsi = "";
	private FTCP3.AuthStatusEnum authStatus = FTCP3.AuthStatusEnum.FACTORY_MODE;
	
	public AlertCreativeMock(TcuVehicle tv) {
		super();
		this.esn = tv.getEsn();
		this.vin = tv.getVin();
		this.imei = tv.getImei();
		this.iccid = tv.getIccid();
		this.msisdn = tv.getMsisdn();
		this.simImsi = tv.getSimImsi();
		this.authStatus = tv.getAuthStatus();
	}
	
	public String getSimImsi() {
		return simImsi;
	}

	public void setSimImsi(String simImsi) {
		this.simImsi = simImsi;
	}

	private int cloundMsgId = 0;
	private VehicleBean hevVehicleBean;
	private BatteryFault batteryFaultBean;
	public BatteryFault getBatteryFaultBean() {
		return batteryFaultBean;
	}

	public void setBatteryFaultBean(BatteryFault batteryFaultBean) {
		this.batteryFaultBean = batteryFaultBean;
	}

	public VehicleBean getHevVehicleBean() {
		return hevVehicleBean;
	}

	public void setHevVehicleBean(VehicleBean hevVehicleBean) {
		this.hevVehicleBean = hevVehicleBean;
	}

	public String getIccid() {
		return iccid;
	}

	public void setIccid(String iccid) {
		this.iccid = iccid;
	}

	public static boolean _simulateFileDownloadError = false;
	
	public byte[] buildTCUConnectionStatusAlert()
			throws InvalidProtocolBufferException 
	{
		TCUConnectionStatusAlert.Builder tcuAlertBuilder = TCUConnectionStatusAlert.newBuilder();
		
		CommonFromVehicle.Builder commonFromVehicleBuilder = buildVehicleCommon(esn, vin, 0);
//		VehicleStatus.Builder vehicleStatus = buildVehicleStatus();

		tcuAlertBuilder.setConnectionStatus(TCUConnectionStatusEnum.CONNECTED);
		tcuAlertBuilder.setVehicleCommon(commonFromVehicleBuilder.build());
		
		TCUConnectionStatusAlert tcuAlert = tcuAlertBuilder.build();
		
		byte alertBytes[] = tcuAlert.toByteArray();
		StringBuilder sb = new StringBuilder();
		for (byte by : alertBytes) 
		{
	        sb.append(String.format("%02X ", by));
	    }
		return tcuAlert.toByteArray();
	}
	
	public CommonFromVehicle.Builder buildVehicleCommon(String esn, String vin, int cloundMsgId)
	{
		UTCDateTime.Builder utcDateTimeBuilder = UTCDateTime.newBuilder();
		CommonFromVehicle.Builder commonFromVehicleBuilder = CommonFromVehicle.newBuilder();
		if (cloundMsgId == 0 ) {
			commonFromVehicleBuilder.setCorrelationId(new Integer(generateRandom()));
		} else {
			commonFromVehicleBuilder.setCorrelationId(cloundMsgId);
		}
		commonFromVehicleBuilder.setTcuMessageId(new Integer(generateRandom()));
		commonFromVehicleBuilder.setEsn(esn);
//		commonFromVehicleBuilder.setFirmwareVersion("2.1.1");
//		commonFromVehicleBuilder.setGlobalConfigVersion("2.1.1MFM3.1.0");
		commonFromVehicleBuilder.setVin(vin);
		commonFromVehicleBuilder.setModemUTCDateTime(buildUTCDateTime(utcDateTimeBuilder));
		commonFromVehicleBuilder.setIccid(this.iccid);
//		commonFromVehicleBuilder.setHardwarePartNumber("123");
//		commonFromVehicleBuilder.setStrategyPartNumber("1234");
//		commonFromVehicleBuilder.setConfigPartNumber("321");
		//commonFromVehicleBuilder.setAuthStatus(FTCP.AuthStatusEnum.FACTORY_MODE);
		commonFromVehicleBuilder.setAuthStatus(this.authStatus);
		commonFromVehicleBuilder.setInCarHecTime(FTCP3.HECDateTime.getDefaultInstance());
//		commonFromVehicleBuilder.setProtofileVersion("1.4.5");
		commonFromVehicleBuilder.setProtofileVersion("3.0.4");
		return commonFromVehicleBuilder;
	}
	
	public static VehicleStatus.Builder buildVehicleStatus()
	{
		VehicleStatus.Builder vehicleStatus = VehicleStatus.newBuilder();
		vehicleStatus.setOdometerMasterValue(generateRandom());
		vehicleStatus.setVehLockStatus(1);
		vehicleStatus.setTirePressSystemStat(30);
		vehicleStatus.setVehLockStatus(1); //Duplicate 
		vehicleStatus.setIgnitionStatus(0);
		
		vehicleStatus.setPwPckTqDStat(4);
		vehicleStatus.setRemoteDeviceFeedback(1);
		vehicleStatus.setRstrtSettingTActl(1);
		vehicleStatus.setRstrtTActl(1);
		vehicleStatus.setBattULoUActl(1);
		vehicleStatus.setGearLvrPosDActl(1);
		vehicleStatus.setPerimeterAlarmStatus(1);
		vehicleStatus.setPrmtrAlrmEvntDStat(1);
		vehicleStatus.setFuelLvlPcDsply(1);
		vehicleStatus.setEngOilLifePcActl(1);
		vehicleStatus.setVehVActlEng(1);
		vehicleStatus.setFuelRangeLDsply(1);

		FTCP3.GPSInfo.Builder gpsbldr = FTCP3.GPSInfo.newBuilder();
		/*FTCP3.UTCDateTimeFromCAN.Builder utcbldr = FTCP3.UTCDateTimeFromCAN.newBuilder();
		utcbldr.setGpsUtcDayNoActl(0);
		utcbldr.setGPSUTCHours(0);
		gpsbldr.setCANUTCDateTime(utcbldr.build());
		gpsbldr.setGPSActualVsInferPos(0);
		gpsbldr.setGpsBFalt(0);
		gpsbldr.setGPSCompassDirection(0);
		gpsbldr.setGPSDimension(0);
		gpsbldr.setGPSHeading(0);
		gpsbldr.setGpsHsphLattSthDActl(0);
		gpsbldr.setGpsHsphLongEastDActl(0);
		gpsbldr.setGPSMSLAltitude(314);
		gpsbldr.setGPSSpeed(0);
		
		Latitude.Builder latbldr = Latitude.newBuilder();
		latbldr.setGPSLatitudeDegrees(31);
		latbldr.setGPSLatitudeMinDec(1237);
		latbldr.setGPSLatitudeMinutes(17);
		gpsbldr.setLatitude(latbldr.build());
		Longitude.Builder longbldr = Longitude.newBuilder();
		longbldr.setGPSLongitudeDegrees(121);
		longbldr.setGPSLongitudeMinDec(6292);
		longbldr.setGPSLongitudeMinutes(9);
		gpsbldr.setLongitude(longbldr.build());*/
		ShiftedGPSInfo.Builder shiftedGPSInfo = ShiftedGPSInfo.newBuilder();
		shiftedGPSInfo.setLatitidueDegreesInteger(29);//度-整数
		shiftedGPSInfo.setLatitudeDegreesFractional(2981);//度-小数
		
		shiftedGPSInfo.setLongitudeDegreesInteger(119);
		shiftedGPSInfo.setLongitudeDegreesFractional(2981);
		gpsbldr.setShiftedGPSInfo(shiftedGPSInfo);
		
		vehicleStatus.setGpsInfo(gpsbldr.build());

		vehicleStatus.setPepsKeyActvDStat(1);
		vehicleStatus.setLifeCycMdeDActl(1);
		vehicleStatus.setVehKeyActvDStat(1);
		
		// HEV 2015/01/19 
		vehicleStatus.setBattTracWarnLampBRq(1);
		vehicleStatus.setBattTracSrvcRqdBRq(0);
		
		return vehicleStatus;
		
	}
	
	public CommonFromVehicle.Builder buildHEVVehicleCommon(String esn, String vin, int cloundMsgId)
	{
		UTCDateTime.Builder utcDateTimeBuilder = UTCDateTime.newBuilder();
		CommonFromVehicle.Builder commonFromVehicleBuilder = CommonFromVehicle.newBuilder();
		if (cloundMsgId == 0 ) {
			commonFromVehicleBuilder.setCorrelationId(new Integer(generateRandom()));
		} else {
			commonFromVehicleBuilder.setCorrelationId(cloundMsgId);
		}
		commonFromVehicleBuilder.setTcuMessageId(new Integer(generateRandom()));
		commonFromVehicleBuilder.setEsn(hevVehicleBean.getEsn());
		commonFromVehicleBuilder.setVin(hevVehicleBean.getVin());
		commonFromVehicleBuilder.setModemUTCDateTime(buildUTCDateTime(utcDateTimeBuilder));
		commonFromVehicleBuilder.setIccid(this.iccid);
		commonFromVehicleBuilder.setAuthStatus(FTCP3.AuthStatusEnum.AUTHORIZED);
		commonFromVehicleBuilder.setInCarHecTime(FTCP3.HECDateTime.getDefaultInstance());
		return commonFromVehicleBuilder;
	}
	
	public VehicleStatus.Builder buildHEVVehicleStatus(VehicleStatus vehicleStatusBean)
	{
		VehicleStatus.Builder vehicleStatus = VehicleStatus.newBuilder();
		//VehicleStatus.Veh_LockStatus
		vehicleStatus.setVehLockStatus(0);
		//VehicleStatus.PwPckTqDStat
		vehicleStatus.setPwPckTqDStat(0);
		//VehicleStatus.BattULoUActl
		vehicleStatus.setBattULoUActl(0);
		//VehicleStatus.TirepresssystemStat
		vehicleStatus.setTirePressSystemStat(0);
		//VehicleStatus.GearLvrPosDActl
		vehicleStatus.setGearLvrPosDActl(0);
		//VehicleStatus.IgnitionStatus
		vehicleStatus.setIgnitionStatus(0);
		//VehicleStatus.PerimeterAlarmStatus
		vehicleStatus.setPerimeterAlarmStatus(0);
		//VehicleStatus.PrmtrAlrmEvntDStat
		vehicleStatus.setPrmtrAlrmEvntDStat(0);
		//VehicleStatus.FuelLvlPcDsply
		vehicleStatus.setFuelLvlPcDsply(0);
		//VehicleStatus.EngOilLifePcActl
		vehicleStatus.setEngOilLifePcActl(0);
		//VehicleStatus.VehVActlEng
		vehicleStatus.setVehVActlEng(0);
		//VehicleStatus.FuelRangeLDsply
		vehicleStatus.setFuelRangeLDsply(0);
		//VehicleStatus.OdometerMasterValue
		vehicleStatus.setOdometerMasterValue(0);
		//VehicleStatus.BattTracSocPcDsply
		vehicleStatus.setBattTracSocPcDsply(0);
		//VehicleStatus.PtRmtRprtDRq
		vehicleStatus.setPtRmtRprtDRq(0);
		//VehicleStatus.PlgActvArbBActl
		vehicleStatus.setPlgActvArbBActl(0);
		//VehicleStatus.BattElecPerfDActl
		vehicleStatus.setBattElecPerfDActl(0);
		//VehicleStatus.TripSumEDsply
		vehicleStatus.setTripSumEDsply(0);
		//VehicleStatus.TripSumVlDsply
		vehicleStatus.setTripSumVlDsply(0);
		//VehicleStatus.TripSumLDsply
		vehicleStatus.setTripSumLDsply(0);
		//VehicleStatus.ActChrgStrtYrNoActl
		vehicleStatus.setActChrgStrtYrNoActl(0);
		//VehicleStatus.ActChrgStrMnthNoActl
		vehicleStatus.setActChrgStrMnthNoActl(0);
		//VehicleStatus.ActChrgStrtDayNoActl
		vehicleStatus.setActChrgStrtDayNoActl(0);
		//VehicleStatus.ActChrgStrtHrNoActl
		vehicleStatus.setActChrgStrtHrNoActl(0);
		//VehicleStatus.ActChrgStrtMinNoActl
		vehicleStatus.setActChrgStrtMinNoActl(0);
		//VehicleStatus.ActChrgEndYrNoActl
		vehicleStatus.setActChrgEndYrNoActl(0);
		//VehicleStatus.ActChrgEndMnthNoActl
		vehicleStatus.setActChrgEndMnthNoActl(0);
		//VehicleStatus.ActChrgEndDayNoActl
		vehicleStatus.setActChrgEndDayNoActl(0);
		//VehicleStatus.ActChrgEndHrNoActl
		vehicleStatus.setActChrgEndHrNoActl(0);
		//ActChrgEndMinNoActl
		vehicleStatus.setActChrgEndMinNoActl(0);
		//VehicleStatus.ChrgLocIDNoRq
		vehicleStatus.setChrgLocIDNoRq(0);
		//VehicleStatus.ChargeNowDurationSt
		vehicleStatus.setChargeNowDurationSt(0);
		//VehicleStatus.receivedSignalQuality
		vehicleStatus.setReceivedSignalQuality(0);
		//VehicleStatus.GSMDRXLevel
		vehicleStatus.setGSMDRXLevel(0);
		//VehicleStatus.GSMRoamingFlag
		vehicleStatus.setGSMRoamingFlag(0);
		//VehicleStatus.GSMNumberOfNeighbors
		vehicleStatus.setGSMNumberOfNeighbors(0);
		//VehicleStatus.RgenLongTermPcDsply
		vehicleStatus.setRgenLongTermPcDsply(0);
		//VehicleStatus.RgenTripPcDsply
		vehicleStatus.setRgenTripPcDsply(0);
		//VehicleStatus.RgenTripLDsply
		vehicleStatus.setRgenTripLDsply(0);
		//VehicleStatus.RgenLongTermLDsply
		vehicleStatus.setRgenLongTermLDsply(0);
		//VehicleStatus.ConsTipANoDsply
		vehicleStatus.setConsTipANoDsply(0);
		//VehicleStatus.ConsTipVNoDsply
		vehicleStatus.setConsTipVNoDsply(0);
		//VehicleStatus.ConsTipDecelNoDsply
		vehicleStatus.setConsTipDecelNoDsply(0);
		//VehicleStatus.ConsTipUnitPtDDsply
		vehicleStatus.setConsTipUnitPtDDsply(0);
		//VehicleStatus.ConsTipTotPcDsply
		vehicleStatus.setConsTipTotPcDsply(0);
		//VehicleStatus.ConsAvgTripNoDsply
		vehicleStatus.setConsAvgTripNoDsply(0);
		//VehicleStatus.ConsUnitIPCDDsply
		vehicleStatus.setConsUnitIPCDDsply(0);
		//VehicleStatus.ConsLongTermNoDsply
		vehicleStatus.setConsLongTermNoDsply(0);
		//VehicleStatus.EngSrvcRqdBRq
		vehicleStatus.setEngSrvcRqdBRq(0);
		//VehicleStatus.HtrnSrvcRqdBDsply
		vehicleStatus.setHtrnSrvcRqdBDsply(0);
		//VehicleStatus.HtrnWarnLampBDsply
		vehicleStatus.setHtrnWarnLampBDsply(0);
		//VehicleStatus.PtSrvcLampBRqHtrn
		vehicleStatus.setPtSrvcLampBRqHtrn(0);
		//VehicleStatus.PtWarnLampBRqHtrn
		vehicleStatus.setPtWarnLampBRqHtrn(0);
		//VehicleStatus.BattTracSrvcRqdBRq
		vehicleStatus.setBattTracSrvcRqdBRq(0);
		//VehicleStatus.BattTracWarnLampBRq
		vehicleStatus.setBattTracWarnLampBRq(0);
		//VehicleStatus.ChrgrSrvcRqdBRq
		vehicleStatus.setChrgrSrvcRqdBRq(0);
		//VehicleStatus.TrnSrvcRqdBRq
		vehicleStatus.setTrnSrvcRqdBRq(0);
		//VehicleStatus.TrnWarnLampBDsply
		vehicleStatus.setTrnWarnLampBDsply(0);
		//VehicleStatus.ElTripLDsply
		vehicleStatus.setElTripLDsply(0);
		//VehicleStatus.ElLongTermLDsply
		vehicleStatus.setElLongTermLDsply(0);
		//VehicleStatus.ConsAvgTripFeDsply
		vehicleStatus.setConsAvgTripFeDsply(0);
		//VehicleStatus.receivedSignalStrength
		vehicleStatus.setReceivedSignalStrength(0);
		//VehicleStatus.HybMdeStatDDsply
		vehicleStatus.setHybMdeStatDDsply(0);
		//VehicleStatus.VehElRngeLDsply
		vehicleStatus.setVehElRngeLDsply(0);
		//VehicleStatus.PreCondStatDDsply
		vehicleStatus.setPreCondStatDDsply(0);
		//VehicleStatus.CabnAmbTeActl
		vehicleStatus.setCabnAmbTeActl(0);
		//VehicleStatus.ChrgrInPwTypeDActl
		vehicleStatus.setChrgrInPwTypeDActl(0);
		//VehicleStatus.ChrgStatDDsply
		vehicleStatus.setChrgStatDDsply(0);
		//VehicleStatus.BattChrgTrgSocPtTEst
		vehicleStatus.setBattChrgTrgSocPtTEst(0);
		//VehicleStatus.BattChrgCmpltPtTEst
		vehicleStatus.setBattChrgCmpltPtTEst(0);
		//VehicleStatus.PlgActvDActlChrgr
		vehicleStatus.setPlgActvDActlChrgr(0);
		//VehicleStatus.ChrgrInPwMx
		vehicleStatus.setChrgrInPwMx(0);
		//VehicleStatus.AirAmbTeActlFilt
		vehicleStatus.setAirAmbTeActlFilt(0);
		//VehicleStatus.LifeCycMdeDActl
		vehicleStatus.setLifeCycMdeDActl(0);
		//VehicleStatus.Prkbrkstatus
		vehicleStatus.setPrkbrkstatus(0);
		//VehicleStatus.PrkBrkActvBActl
		vehicleStatus.setPrkBrkActvBActl(0);
		//VehicleStatus.parkrbrakehard
		vehicleStatus.setParkrbrakeHard(0);
		//VehicleStatus.parkbrakesoft
		vehicleStatus.setParkbrakeSoft(0);
		//VehicleStatus.ApedPosPcActlArb
		vehicleStatus.setApedPosPcActlArb(0);
		//VehicleStatus.EngAoutNActl
		vehicleStatus.setEngAoutNActl(0);
		//VehicleStatus.EngClntTeActl
		vehicleStatus.setEngClntTeActl(0);
		//VehicleStatus.PrplWhlTot2TqActl
		vehicleStatus.setPrplWhlTot2TqActl(0);
		//VehicleStatus.BSBattSOC
		vehicleStatus.setBSBattSOC(0);
		//VehicleStatus.BpedDrvApplDActl
		vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.DRIVER_NOT_BRAKING);
//		if (hevVehicleBean.getBpedDrvApplDActl() == 0) {
//			vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.NOT_ALLOWED);
//		} else if (hevVehicleBean.getBpedDrvApplDActl() == 3) {
//			vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.NOT_ALLOWED_);
//		} else if (hevVehicleBean.getBpedDrvApplDActl() == 1) {
//			vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.DRIVER_NOT_BRAKING);
//		} else if (hevVehicleBean.getBpedDrvApplDActl() == 2) {
//			vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.DRIVER_BRAKING);
//		}
		
		return vehicleStatus;
	}
	
	public VehicleStatus.Builder buildHEVVehicleStatus()
	{
		VehicleStatus.Builder vehicleStatus = VehicleStatus.newBuilder();
		vehicleStatus.setOdometerMasterValue(hevVehicleBean.getOdometerMasterValue());
		vehicleStatus.setVehLockStatus(1);
		vehicleStatus.setTirePressSystemStat(30);
		vehicleStatus.setVehLockStatus(1); //Duplicate 
		vehicleStatus.setIgnitionStatus(hevVehicleBean.getIgnitionStatus());
		
		vehicleStatus.setPwPckTqDStat(4);
		vehicleStatus.setRemoteDeviceFeedback(1);
		vehicleStatus.setRstrtSettingTActl(1);
		vehicleStatus.setRstrtTActl(1);
		vehicleStatus.setBattULoUActl(1);
		vehicleStatus.setGearLvrPosDActl(hevVehicleBean.getGearLvrPosDActl());
		vehicleStatus.setPerimeterAlarmStatus(1);
		vehicleStatus.setPrmtrAlrmEvntDStat(1);
		vehicleStatus.setEngOilLifePcActl(1);
		vehicleStatus.setVehVActlEng(hevVehicleBean.getVehVActlEng());
		vehicleStatus.setFuelRangeLDsply(hevVehicleBean.getFuelRangeLDsply());
		vehicleStatus.setApedPosPcActlArb(hevVehicleBean.getApedPosPcActlArb());
		vehicleStatus.setChrgStatDDsply(0);
		vehicleStatus.setPlgActvDActlChrgr(0);
		if (hevVehicleBean.getBpedDrvApplDActl() == 0) {
			vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.NOT_ALLOWED);
		} else if (hevVehicleBean.getBpedDrvApplDActl() == 3) {
			vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.NOT_ALLOWED_);
		} else if (hevVehicleBean.getBpedDrvApplDActl() == 1) {
			vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.DRIVER_NOT_BRAKING);
		} else if (hevVehicleBean.getBpedDrvApplDActl() == 2) {
			vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.DRIVER_BRAKING);
		}
		vehicleStatus.setEngAoutNActl(hevVehicleBean.getEngAoutNActl());
		vehicleStatus.setEngClntTeActl(hevVehicleBean.getEngClntTeActl());
		vehicleStatus.setEngSrvcRqdBRq(hevVehicleBean.getEngSrvcRqdBRq());
		vehicleStatus.setFuelLvlPcDsply(hevVehicleBean.getFuelLvlPcDsply());
		vehicleStatus.setAirAmbTeActlFilt(hevVehicleBean.getAirAmbTeActlFilt());
		vehicleStatus.setPrplWhlTot2TqActl(hevVehicleBean.getPrplWhlTot2TqActl());
		vehicleStatus.setPwPckDStat(hevVehicleBean.getPwPckTqDStat());
		vehicleStatus.setBSBattSOC(hevVehicleBean.getbSBattSOC());
		
		FTCP3.GPSInfo.Builder gpsbldr = FTCP3.GPSInfo.newBuilder();
		/*FTCP3.UTCDateTimeFromCAN.Builder utcbldr = FTCP3.UTCDateTimeFromCAN.newBuilder();
		utcbldr.setGpsUtcDayNoActl(0);
		utcbldr.setGPSUTCHours(0);
		gpsbldr.setCANUTCDateTime(utcbldr.build());
		gpsbldr.setGPSActualVsInferPos(hevVehicleBean.getGPSActualVsInferPos());
		gpsbldr.setGpsBFalt(0);
		gpsbldr.setGPSCompassDirection(hevVehicleBean.getGPSCompassDirection());
		gpsbldr.setGPSDimension(0);
		gpsbldr.setGPSHeading(hevVehicleBean.getGPSHeading());
		gpsbldr.setGpsHsphLattSthDActl(0);
		gpsbldr.setGpsHsphLongEastDActl(0);
		gpsbldr.setGPSMSLAltitude(314);
		gpsbldr.setGPSSpeed(hevVehicleBean.getGPSSpeed());
		
		Latitude.Builder latbldr = Latitude.newBuilder();
//		double lat = hevVehicleBean.getLat();
//		int du = (int)Math.floor(lat);
//		int fen = (int)Math.floor((lat - du)*60);
//		double miao = ((lat - du)*60 - fen)*60;
		latbldr.setGPSLatitudeDegrees(hevVehicleBean.getGPS_Latitude_Degrees());
		latbldr.setGPSLatitudeMinutes(hevVehicleBean.getGPS_Latitude_Minutes());
		latbldr.setGPSLatitudeMinDec(hevVehicleBean.getGPS_Latitude_Min_dec());
		gpsbldr.setLatitude(latbldr.build());
		
		Longitude.Builder longbldr = Longitude.newBuilder();
//		double lng = hevVehicleBean.getLng();
//		int du1 = (int)Math.floor(lng);
//		int fen1 = (int)Math.floor((lng - du)*60);
//		double miao1 = ((lng - du)*60 - fen)*60;
		longbldr.setGPSLongitudeDegrees(hevVehicleBean.getGPS_Longitude_Degrees());
		longbldr.setGPSLongitudeMinutes(hevVehicleBean.getGPS_Longitude_Minutes());
		longbldr.setGPSLongitudeMinDec(hevVehicleBean.getGPS_Longitude_Min_dec());
		gpsbldr.setLongitude(longbldr.build());*/
		
		ShiftedGPSInfo.Builder shiftedGPSInfo = ShiftedGPSInfo.newBuilder();
		shiftedGPSInfo.setLatitidueDegreesInteger(hevVehicleBean.getGPS_Latitude_Degrees());//经度-整数
		shiftedGPSInfo.setLatitudeDegreesFractional(hevVehicleBean.getGPS_Latitude_Minutes());//经度-小数
		
		shiftedGPSInfo.setLongitudeDegreesInteger(hevVehicleBean.getGPS_Longitude_Degrees()); //纬度-整数
		shiftedGPSInfo.setLongitudeDegreesFractional(hevVehicleBean.getGPS_Longitude_Minutes());//纬度-小数
		gpsbldr.setShiftedGPSInfo(shiftedGPSInfo);
		
		vehicleStatus.setGpsInfo(gpsbldr.build());

		vehicleStatus.setPepsKeyActvDStat(1);
		vehicleStatus.setLifeCycMdeDActl(1);
		vehicleStatus.setVehKeyActvDStat(1);
		
		// HEV 2015/01/19 
		vehicleStatus.setBattTracWarnLampBRq(hevVehicleBean.getBattTracWarnLampBRq());
		vehicleStatus.setBattTracSrvcRqdBRq(hevVehicleBean.getBattTracSrvcRqdBRq());
		
		return vehicleStatus;
		
	}
	
	public HEVBatteryData.Builder buildHEVBatteryData4BatteryFault() {
		HEVBatteryData.Builder builder = HEVBatteryData.newBuilder();
		// HEV Data
		builder.setBattTracUActl(batteryFaultBean.getBattTracUActl());//voltage
		builder.setBattTracIActl(batteryFaultBean.getBattTracIActl());//current
		builder.setBattTracSoc2PcActl(batteryFaultBean.getBattTracSoc2PcActl());// SOC
		builder.setBattTracTeActl(batteryFaultBean.getBattTracTeActl());//temperature
		builder.setVehStrtInhbtBRqBatt(batteryFaultBean.getVehStrtInhbtBRqBatt());// inhibit
		builder.setBattTracOffBActl(batteryFaultBean.getBattTracOffBActl());//shutdown or about to shutdown
		builder.setBattTracPwLimChrg(batteryFaultBean.getBattTracPwLimChrg());
		builder.setBattTracPwLimDchrg(batteryFaultBean.getBattTracPwLimDchrg());
		builder.setBattTracOffFstDActl(batteryFaultBean.getBattTracOffFstDActl());
	
		return builder;
	}
	
	public HEVBatteryData.Builder buildHEVBatteryData() {
		HEVBatteryData.Builder builder = HEVBatteryData.newBuilder();
		// HEV Data
		builder.setBattTracUActl(hevVehicleBean.getBattTracUActl());//voltage
		builder.setBattTracIActl(hevVehicleBean.getBattTracIActl());//current
		builder.setBattTracSoc2PcActl(hevVehicleBean.getBattTracSoc2PcActl());// SOC
		builder.setBattTracTeActl(hevVehicleBean.getBattTracTeActl());//temperature
		builder.setVehStrtInhbtBRqBatt(hevVehicleBean.getVehStrtInhbtBRqBatt());// inhibit
		builder.setBattTracOffBActl(hevVehicleBean.getBattTracOffBActl());//shutdown or about to shutdown
		builder.setBattTracPwLimChrg(hevVehicleBean.getBattTracPwLimChrg());
		builder.setBattTracPwLimDchrg(hevVehicleBean.getBattTracPwLimDchrg());
		builder.setBattTracOffFstDActl(hevVehicleBean.getBattTracOffFstDActl());
	
		return builder;
	}
	
	private static Random random = new Random();
	private static int generateRandom(){
		int randomId = random.nextInt(999999999);
		return randomId;
	}

	private static UTCDateTime.Builder buildUTCDateTime(UTCDateTime.Builder utcDateTimeBuilder){
		
		GregorianCalendar date = new GregorianCalendar();
		utcDateTimeBuilder/*.setGpsUtcYrNoActl*/.setUTCYear(date.get(Calendar.YEAR));
		utcDateTimeBuilder/*.setGpsUtcMnthNoActl*/.setUTCMonth(date.get(Calendar.MONTH));
		utcDateTimeBuilder/*.setGpsUtcDayNoActl*/.setUTCDay(date.get(Calendar.DAY_OF_MONTH));
		utcDateTimeBuilder/*.setGPSUTCHours*/.setUTCHour(date.get(Calendar.HOUR));
		utcDateTimeBuilder/*.setGPSUTCMinutes*/.setUTCMin(date.get(Calendar.MINUTE));
		utcDateTimeBuilder/*.setGPSUTCSeconds*/.setUTCSecond(date.get(Calendar.SECOND));
		
		return utcDateTimeBuilder;
	}
	
	public byte[] buildAlert(int alert, int alertType)
			throws InvalidProtocolBufferException 
	{
		TCUAlert.Builder tcuAlertBuilder = TCUAlert.newBuilder();
		
		CommonFromVehicle.Builder commonFromVehicleBuilder = buildVehicleCommon(esn,vin, cloundMsgId);
		VehicleStatus.Builder vehicleStatus = buildVehicleStatus();
		
		if(alertType == FTCP3.TCUAlert.AlertType.GENERIC_VALUE)
		
		{
			tcuAlertBuilder.setAlertType(FTCP3.TCUAlert.AlertType.GENERIC);
			TCUGenericAlert.Builder tcuGenericAlertBuilder = TCUGenericAlert.newBuilder();
			if(alert == FTCP3.TCUGenericAlert.GenericAlertNameEnum.ALARM_TRIGGERED_VALUE)
			{
				tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.ALARM_TRIGGERED);
				AlarmTriggeredAlert.Builder alarmTriggeredAlertBuilder = AlarmTriggeredAlert.newBuilder();
				alarmTriggeredAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				tcuGenericAlertBuilder.setAlarmTriggeredAlert(alarmTriggeredAlertBuilder);
			}
			
			if(alert == FTCP3.TCUGenericAlert.GenericAlertNameEnum.MOTIVE_MODE_BEGIN_VALUE)
			{
				tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.MOTIVE_MODE_BEGIN);
				MotiveModeBeginAlert.Builder motiveModeBeginAlertBuilder = MotiveModeBeginAlert.newBuilder();
				motiveModeBeginAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				tcuGenericAlertBuilder.setMotiveModeBeginAlert(motiveModeBeginAlertBuilder);
			}
			
			if(alert == FTCP3.TCUGenericAlert.GenericAlertNameEnum.MOTIVE_MODE_END_VALUE)
			{
				tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.MOTIVE_MODE_END);
				MotiveModeEndAlert.Builder motiveModeEndAlertBuilder= MotiveModeEndAlert.newBuilder();
				motiveModeEndAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				tcuGenericAlertBuilder.setMotiveModeEndAlert(motiveModeEndAlertBuilder);
			}
			
			if(alert == FTCP3.TCUGenericAlert.GenericAlertNameEnum.REMOTE_START_BEGIN_VALUE)
			{
				tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.REMOTE_START_BEGIN);
				RemoteStartBeginAlert.Builder remoteStartBeginAlertBuilder = RemoteStartBeginAlert.newBuilder();
				remoteStartBeginAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				tcuGenericAlertBuilder.setRemoteStartBeginAlert(remoteStartBeginAlertBuilder);
			}
			
			if(alert == FTCP3.TCUGenericAlert.GenericAlertNameEnum.REMOTE_START_END_VALUE)
			{
				tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.REMOTE_START_END);
				RemoteStartEndAlert.Builder remoteStartEndAlertBuilder = RemoteStartEndAlert.newBuilder();
				remoteStartEndAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				tcuGenericAlertBuilder.setRemoteStartEndAlert(remoteStartEndAlertBuilder);
			}
			
			if(alert == FTCP3.TCUGenericAlert.GenericAlertNameEnum.LOW_12V_BATTERY_VALUE)
			{
				tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.LOW_12V_BATTERY);
				Low12VBatteryAlert.Builder low12VBatteryAlertBuilder = Low12VBatteryAlert.newBuilder();
				low12VBatteryAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				tcuGenericAlertBuilder.setLow12VBatteryAlert(low12VBatteryAlertBuilder);
			}
			
			if(alert == FTCP3.TCUGenericAlert.GenericAlertNameEnum.CLEAR_LOW_12V_BATTERY_VALUE)
			{
				tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.CLEAR_LOW_12V_BATTERY);
				ClearLow12VBatteryAlert.Builder clearLow12VBatteryAlertBuilder = ClearLow12VBatteryAlert.newBuilder();
				clearLow12VBatteryAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				tcuGenericAlertBuilder.setClrLow12VBatteryAlert(clearLow12VBatteryAlertBuilder);
			}
			if(alert == FTCP3.TCUGenericAlert.GenericAlertNameEnum.LOW_TIRE_PRESSURE_VALUE)
			{
				tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.LOW_TIRE_PRESSURE);
				LowTirePressureAlert.Builder lowTirePressureAlertBuilder = LowTirePressureAlert.newBuilder();
				lowTirePressureAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				tcuGenericAlertBuilder.setLowTirePressureAlert(lowTirePressureAlertBuilder);
			}
			if(alert == FTCP3.TCUGenericAlert.GenericAlertNameEnum.CLEAR_LOW_TIRE_PRESSURE_VALUE)
			{
				tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.CLEAR_LOW_TIRE_PRESSURE);
				ClearLowTirePressureAlert.Builder clearLowTirePressureAlertBuilder = ClearLowTirePressureAlert.newBuilder();
				clearLowTirePressureAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				tcuGenericAlertBuilder.setClrLowTirePressureAlert(clearLowTirePressureAlertBuilder);
			}
			
			if(alert == FTCP3.TCUGenericAlert.GenericAlertNameEnum.CLEAR_HEV_BATTERY_FAULT_VALUE)
			{
				HEVBatteryData.Builder hevBatteryData = buildHEVBatteryData4BatteryFault();
				tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.CLEAR_HEV_BATTERY_FAULT);
				ClearHEVBatteryFaultAlert.Builder clearHevBatteryFaultAlertBuilder = ClearHEVBatteryFaultAlert.newBuilder();
				clearHevBatteryFaultAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				clearHevBatteryFaultAlertBuilder.setHevBatteryData(hevBatteryData);
				clearHevBatteryFaultAlertBuilder.setHevVehicleStatus(vehicleStatus);
				
				ECUData.Builder ecuDataBuilder = ECUData.newBuilder();
				ecuDataBuilder.setECUId(batteryFaultBean.getEcuId());
				ecuDataBuilder.setECUStatus(batteryFaultBean.getEcuStatus());
				
				List<BFDTCInfo> dtcinfos = batteryFaultBean.getDtcinfos();

				for (BFDTCInfo info : dtcinfos) {
					DTCInfo.Builder dtcInfo = DTCInfo.newBuilder();
					dtcInfo.setDTCId(info.getDtcId());
					dtcInfo.setDTCAdditionalInfo(info.getDtcAdditionalInfo());
					dtcInfo.setDTCStatus(info.getDtcStatus());
					ecuDataBuilder.addDtcInfo(dtcInfo);
				}
				
				clearHevBatteryFaultAlertBuilder.setBECMDiagnosticsData(ecuDataBuilder);
				
				tcuGenericAlertBuilder.setClrHEVBatteryFaultAlert(clearHevBatteryFaultAlertBuilder);
				
			}
			
			if(alert == FTCP3.TCUGenericAlert.GenericAlertNameEnum.MASTER_RESET_VALUE)
			{
				tcuGenericAlertBuilder.setGenericAlertName(FTCP3.TCUGenericAlert.GenericAlertNameEnum.MASTER_RESET);
				MasterResetAlert.Builder masterResetAlertBuilder = MasterResetAlert.newBuilder();
				masterResetAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				tcuGenericAlertBuilder.setMasterResetAlert(masterResetAlertBuilder);
			}
			
			tcuAlertBuilder.setGenericAlert(tcuGenericAlertBuilder);
			
		}
		
		else if(alertType == FTCP3.TCUAlert.AlertType.NON_GENERIC_VALUE)
			
		{
			tcuAlertBuilder.setAlertType(FTCP3.TCUAlert.AlertType.NON_GENERIC);
			TCUNonGenericAlert.Builder tcuNonGenericAlertBuilder = TCUNonGenericAlert.newBuilder();
			
			
			if(alert == FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.USER_AUTHORIZATION_RESPONSE_VALUE)
			{
				tcuNonGenericAlertBuilder.setNonGenericAlertName(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.USER_AUTHORIZATION_RESPONSE);
				UserAuthorizationResponseAlert.Builder userAuthorizationResponseAlertAlert = UserAuthorizationResponseAlert.newBuilder();

				userAuthorizationResponseAlertAlert.setVehicleCommon(commonFromVehicleBuilder);
				userAuthorizationResponseAlertAlert.setVstat(vehicleStatus);
				userAuthorizationResponseAlertAlert.setAuthResponse(FTCP3.UserAuthorizationResponseAlert.AuthorizationResponse.ALLOWED);
				userAuthorizationResponseAlertAlert.setRequestType(AuthorizationRequestType.FINAL);

				tcuNonGenericAlertBuilder.setUserAuthorizationResponseAlert(userAuthorizationResponseAlertAlert);
			}
			if(alert == FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.PROVISIONING_VALUE)
			{
				tcuNonGenericAlertBuilder.setNonGenericAlertName(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.PROVISIONING);
				ProvisioningAlert.Builder provisioningAlertBuilder = ProvisioningAlert.newBuilder();

				provisioningAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				ProvisioningData.Builder provisioningDataBuilder = ProvisioningData.newBuilder();
				provisioningDataBuilder.setImei(this.imei);
				provisioningDataBuilder.setSimMsisdn(this.msisdn);
				provisioningDataBuilder.setSimImsi(this.simImsi);
				provisioningDataBuilder.setFirmwareVersionTeseo2("2.1.1");
				provisioningDataBuilder.setFirmwareVersionHe920("1.1.2");
				provisioningDataBuilder.setBusArchitecture(0x01);
				provisioningDataBuilder.setDestinationRegionCode("CN");
				provisioningAlertBuilder.setProvisioningData(provisioningDataBuilder);

				tcuNonGenericAlertBuilder.setProvisioningAlert(provisioningAlertBuilder);

			}
			if(alert == FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.SLEEP_STATE_CHANGE_VALUE)
			{
				tcuNonGenericAlertBuilder.setNonGenericAlertName(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.SLEEP_STATE_CHANGE);
				
				SleepStateChangeAlert.Builder sleepStateChangeAlertBuilder = SleepStateChangeAlert.newBuilder();

				sleepStateChangeAlertBuilder.setVehicleCommon(commonFromVehicleBuilder);
				sleepStateChangeAlertBuilder.setVstat(vehicleStatus);
				sleepStateChangeAlertBuilder.setSleepStatus(FTCP3.SleepStateChangeAlert.SleepStatus.AWAKE);
				sleepStateChangeAlertBuilder.setSleepInterval(20);

				tcuNonGenericAlertBuilder.setSleepStateChangeAlert(sleepStateChangeAlertBuilder);
				
			}
		
			if(alert == FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_DATA_MONITOR_VALUE)
			{
				tcuNonGenericAlertBuilder.setNonGenericAlertName(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_DATA_MONITOR);
				HEVDataMonitoringAlert.Builder hevDataMonitorAlert = HEVDataMonitoringAlert.newBuilder();
				
				hevDataMonitorAlert.setVehicleCommon(buildHEVVehicleCommon(esn, vin, alertType));
				
				hevDataMonitorAlert.setHevVehicleStatus(buildHEVVehicleStatus());
				
				hevDataMonitorAlert.setHevBatteryData(buildHEVBatteryData());
				
				tcuNonGenericAlertBuilder.setHevDataMonitoringAlert(hevDataMonitorAlert);
			}
			
			if(alert == FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_BATTERY_FAULT_VALUE)
			{
				HEVBatteryData.Builder hevBatteryData = buildHEVBatteryData4BatteryFault();
				tcuNonGenericAlertBuilder.setNonGenericAlertName(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_BATTERY_FAULT);
				HEVBatteryFaultAlert.Builder hevBatteryFaultAlert = HEVBatteryFaultAlert.newBuilder();
				hevBatteryFaultAlert.setVehicleCommon(commonFromVehicleBuilder);
				hevBatteryFaultAlert.setHevVehicleStatus(vehicleStatus);
				hevBatteryFaultAlert.setHevBatteryData(hevBatteryData);
				//
				
				/*DTCInfo.Builder dtcInfo = DTCInfo.newBuilder();
				dtcInfo.setDTCId(1);
				dtcInfo.setDTCAdditionalInfo(1);
				dtcInfo.setDTCStatus(1);
				DTCInfo.Builder dtcInfo1 = DTCInfo.newBuilder();
				dtcInfo1.setDTCId(2);
				dtcInfo1.setDTCAdditionalInfo(0);
				dtcInfo1.setDTCStatus(0);*/
				ECUData.Builder ecuDataBuilder = ECUData.newBuilder();
				ecuDataBuilder.setECUId(batteryFaultBean.getEcuId());
				ecuDataBuilder.setECUStatus(batteryFaultBean.getEcuStatus());
				
				List<BFDTCInfo> dtcinfos = batteryFaultBean.getDtcinfos();

				for (BFDTCInfo info : dtcinfos) {
					DTCInfo.Builder dtcInfo = DTCInfo.newBuilder();
					dtcInfo.setDTCId(info.getDtcId());
					dtcInfo.setDTCAdditionalInfo(info.getDtcAdditionalInfo());
					dtcInfo.setDTCStatus(info.getDtcStatus());
					ecuDataBuilder.addDtcInfo(dtcInfo);
				}
				
				/*ecuDataBuilder.addDtcInfo(dtcInfo);
				ecuDataBuilder.addDtcInfo(dtcInfo1);*/
				hevBatteryFaultAlert.setBECMDiagnosticsData(ecuDataBuilder);
				//
				hevBatteryFaultAlert.setHevBatteryFaultSeverityEnum(batteryFaultBean.getHevBatteryFaultSeverity());
				tcuNonGenericAlertBuilder.setHevBatteryFaultAlert(hevBatteryFaultAlert);
			}
			
			if(alert == FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.VEHICLE_DIAGNOSTIC_DATA_RESPONSE_VALUE)
			{
				tcuNonGenericAlertBuilder.setNonGenericAlertName(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.VEHICLE_DIAGNOSTIC_DATA_RESPONSE);
				VehicleDiagnosticDataResponseAlert.Builder vehicleDiagnosticDataResponseAlert = com.ford.ftcp.FTCP3.VehicleDiagnosticDataResponseAlert.newBuilder();
				vehicleDiagnosticDataResponseAlert.setVehicleCommon(commonFromVehicleBuilder);
				vehicleDiagnosticDataResponseAlert.setVstat(vehicleStatus);
				vehicleDiagnosticDataResponseAlert.setDiagnosticRequestStatusEnum(DiagnosticRequestStatusEnum.SUCCESSFUL);
				
				VehicleDiagnosticData.Builder vehicleDiagnosticData = VehicleDiagnosticData.newBuilder();
				vehicleDiagnosticData.setTargetECUId(1);
				
				byte[] bytes = {1,1};
				ByteString bs = ByteString.copyFrom(bytes);
				vehicleDiagnosticData.setDiagnosticRequestDataFromCloud(bs);
				
				UTCDateTime.Builder utcDateTimeBuilder = UTCDateTime.newBuilder();
				vehicleDiagnosticData.setDiagnosticRequestExpiration(buildUTCDateTime(utcDateTimeBuilder));
				vehicleDiagnosticDataResponseAlert.setDiagnosticData(vehicleDiagnosticData);
				
				VehicleDiagnosticResponseData.Builder vehicleDiagnosticResponseData = VehicleDiagnosticResponseData.newBuilder();
				vehicleDiagnosticResponseData.setResponseECUId(1);
				vehicleDiagnosticResponseData.setDiagnosticResponseDataFromVehicle(bs);
				vehicleDiagnosticDataResponseAlert.addDiagnosticResponseData(vehicleDiagnosticResponseData);
				
				tcuNonGenericAlertBuilder.setVehicleDiagnosticDataResponseAlert(vehicleDiagnosticDataResponseAlert);
			}
			tcuAlertBuilder.setNonGenericAlert(tcuNonGenericAlertBuilder);
		}
		
		TCUAlert tcuAlert = tcuAlertBuilder.build();
		
		System.out.println(tcuAlert);
		
		byte alertBytes[] = tcuAlert.toByteArray();
		StringBuilder sb = new StringBuilder();
		for (byte by : alertBytes) 
		{
	        sb.append(String.format("%02X ", by));
//	        logger.info(sb);
	    }
		return tcuAlert.toByteArray();
	} 
}
