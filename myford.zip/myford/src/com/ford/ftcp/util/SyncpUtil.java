package com.ford.ftcp.util;

import java.util.logging.Logger;

import org.apache.commons.codec.binary.Base64;

public class SyncpUtil {
//	private static Logger logger =Logger.getLogger(SyncpUtil.class.getName());
	
	public static String get_ESN_From_Syncp_Header(byte[] syncpBytes)
	{
		String esn = "";
		if (syncpBytes == null)
		{
//			logger.info("Unable to get header from empty SyncP packet");
			return esn;
		} 

		SyncpWrapper syncp = new SyncpWrapper();
		syncp.setDebug(true);
		if(syncpBytes != null)
		{
			int syncprc = syncp.decodeHeader(syncpBytes);
			switch (syncprc)
			{
				case 0:
					esn = syncp.getEsn();
					break;
				default:
					break;
			} 
		} 
		return esn;
	} 
	
	public static byte[] encodeSyncpPacket(byte[] msgBytes, String esn, byte[] psKey)
	{
		if (msgBytes == null)
		{
			msgBytes = new byte[0];
		} // end-if
		if (psKey == null || psKey.length == 0)
		{
			throw new NullPointerException("Invalid SyncP crypto key (null or zero length)");
		} // end-if

		SyncpWrapper syncp = new SyncpWrapper();
		// make sure key is 16 byte binary
		int cpuDestination = 1;
		int highBandwidth_true = 1;
		int responseRequired_false = 0;
		int cpuKey_0 = 0;
		int protocolVersion = 0;
		char serviceType = (char)0x20;
		char versionCmdType = (char)0x2;
		int moduleMsgID = 0;
		int serverMsgID = 0;
		char msgStatus = (char)0;

		syncp.setCpu(cpuDestination);
		syncp.setEsn_req(SyncpWrapper.FLAG_ESN_REQ);
		syncp.setHigh_bandwidth(highBandwidth_true);
		syncp.setResponse_req(responseRequired_false);
		syncp.setSecurity_mode(SyncpWrapper.FLAG_ENCRYPTION_INTEGRITY);
		syncp.setCpu_key(cpuKey_0);
		syncp.setService_type(serviceType);
		syncp.setCmd_ver_type(versionCmdType);
		syncp.setProtocol_version(protocolVersion);
		syncp.setPayload_size(msgBytes.length);
		syncp.setPayload_alloc_size(msgBytes.length);
		syncp.setEsn(esn);
		syncp.setIv(getRandomNumber());
		syncp.setPayload(msgBytes);
		syncp.setMsg_id_module(moduleMsgID);
		syncp.setMsg_id_server(serverMsgID);
		syncp.setMsg_status(msgStatus);
		syncp.setKey(psKey);
		syncp.setDebug(true);

		// encode
		byte[] syncpPacket = syncp.encode();
		if(syncpPacket != null)
		{
//			logger.info("Encode is successful ... ");
//			logger.info("Returned Crypto Packet Length: " + syncpPacket.length);
		}
		else
		{
//			logger.info("SyncP Encode failed");
		} // end-if
//		logger.info("Returning encoded " + (syncpPacket == null ? "<null>" : syncpPacket.length) + " byte SyncP packet");
		
		return syncpPacket;
	}
	
	public static byte[] decodeSyncpPacket(byte[] syncpBytes, String psKeyB64)
	{
		return decodeSyncpPacket(syncpBytes, convertBase64ToBinary(psKeyB64));
	}
	
	public static byte[] convertBase64ToBinary(String base64Str) 
	{
	    return Base64.decodeBase64(base64Str);
	} // end-method
	
	public static byte[] decodeSyncpPacket(byte[] syncpBytes, byte[] psKey)
	{
//		logger.info("Decoding " + (syncpBytes == null ? "<null>" : syncpBytes.length) + " byte SyncP packet using PSKey 0x" + bytesToHexString(psKey));
		if (syncpBytes == null)
		{
			throw new NullPointerException("Unable to decrypt empty SyncP packet");
		} // end-if
		if (psKey == null || psKey.length == 0)
		{
			throw new NullPointerException("Invalid SyncP crypto key (null or zero length)");
		} // end-if

		byte[] payloadBytes = null;

		SyncpWrapper syncp = new SyncpWrapper(psKey);
		syncp.setDebug(true);
		if(syncpBytes != null)
		{
			int syncprc = syncp.decode(syncpBytes);
			
			if(syncprc == 0)
			{
				payloadBytes = syncp.getPayload();
//				logger.info("Decode is successful: " + syncp);
//				logger.info("Decoded Packet Length: " + payloadBytes.length);
//				logger.info("Decoded Packet: " + new String(payloadBytes));
			}
			else
			{
//				logger.info("SyncP Decode failed, rc=" + syncprc);
			} // end-if
//			logger.info("SyncP.ESN=" + syncp.getEsn());
		} // end-if
//		logger.info("Returning decoded " + (payloadBytes == null ? "<null>" : payloadBytes.length) + " byte payload");

		return payloadBytes;
	}
	
	public static String getRandomNumber()
	{
		String rNumber = null;
		int length = 0;
		while(length != 8)
		{
			int number = new java.util.Random().nextInt(100000000);
			rNumber = String.valueOf(number);
			length = rNumber.length();
		}
		
		return rNumber;
	}
	public static byte[] hexStringToBytes(String hexString) {
		if (hexString == null || hexString.equals("")) {
			return null;
		}
		hexString = hexString.toUpperCase();
		int length = hexString.length() / 2;
		char[] hexChars = hexString.toCharArray();
		byte[] d = new byte[length];
		for (int i = 0; i < length; i++) {
			int pos = i * 2;
			d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
		}
		return d;
	}
	
	private static byte charToByte(char c) {
		return (byte) "0123456789ABCDEF".indexOf(c);
	}
	
	public static String bytesToHexString(byte[] bytes)
	{
		if (bytes == null || bytes.length == 0)
		{
			return "";
		} // end-if
        StringBuilder sb = new StringBuilder(); 
        for(byte b : bytes)
        {
        	sb.append(String.format("%02x", b&0xff));
        } // end-for
        return sb.toString();
	}
	
	public static byte[] encodeSyncpPacket(byte[] msgBytes, String esn, String psKeyB64)
	{
		return encodeSyncpPacket(msgBytes, esn, convertBase64ToBinary(psKeyB64));
	} // end-method
}
