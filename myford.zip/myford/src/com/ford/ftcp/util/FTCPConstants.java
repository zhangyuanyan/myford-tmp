package com.ford.ftcp.util;

import java.util.HashMap;
import java.util.Map;

public class FTCPConstants {

	public static final String MQTT_URL = "tcp://mqa1cnveh.cv.ford.com:1883";//"tcp://fcne0001vehqa.chinacloudapp.cn:1883";//"tcp://nellomqtt-PDCSC.cloudapp.net:1883";//"tcp://nellomqtt-PDCSC.cloudapp.net:1883";

	public static Map<String, String> ESN_PSKEY_MAP = new HashMap<String, String>();
	static {
		ESN_PSKEY_MAP.put("T4860034", "E6K58hHWL4WIFgARcVDIQQ==");
	}
	
	public static String[] vins = {"5LMCJ2A90FUJ00101", "5LMCJ2A90FUJ00102", "5LMCJ2A90FUJ00103", "5LMCJ2A90FUJ00104", "5LMCJ2A90FUJ00105", "5LMCJ2A90FUJ00106", "5LMCJ2A90FUJ00107", "5LMCJ2A90FUJ00108", "5LMCJ2A90FUJ00109", "5LMCJ2A90FUJ00110"};
	public static String region = "CN";
}
