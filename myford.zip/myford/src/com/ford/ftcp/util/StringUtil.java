package com.ford.ftcp.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;

import com.ford.ftcp.FTCP3.UTCDateTime;

public class StringUtil {
	public static String generateUniqueClientId() {
		long curtime = System.nanoTime();
		String strCurtime = String.valueOf(curtime);
		String clntIdSfx = strCurtime.substring(strCurtime.length() - 5,
				strCurtime.length());
		return clntIdSfx;
	}

	public static List<String> createTCUSubcribeTopics(String region, String vin) {
		List<String> topics = new ArrayList<String>();
		topics.add("/" + region + "/" + vin + "/TCU_COMMAND");
		return topics;
	}
	
	public static List<String> createSDNSubcribeTopics(String region, String vin) {
		List<String> topics = new ArrayList<String>();
		topics.add("/" + region + "/" + vin + "/TCU_ALERT");
		topics.add("/" + region + "/" + vin + "/COMMAND_RESPONSE");
		topics.add("/" + region + "/" + vin + "/TCU_CONNECTION_STATUS_ALERT");
		return topics;
	}

	public static String getPublishTopic(String region, String vin, String topicName) {
		return "/" + region + "/" + vin + "/" + topicName;
	}
	public static String bytesToHexString(byte[] src) {
		StringBuilder stringBuilder = new StringBuilder("");
		if (src == null || src.length <= 0) {
			return null;
		}
		for (int i = 0; i < src.length; i++) {
			int v = src[i] & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}
		return stringBuilder.toString();
	}

	/**
	 * Convert hex string to byte[]
	 * 
	 * @param hexString
	 *            the hex string
	 * @return byte[]
	 */
	public static byte[] hexStringToBytes(String hexString) {
		if (hexString == null || hexString.equals("")) {
			return null;
		}
		hexString = hexString.toUpperCase();
		int length = hexString.length() / 2;
		char[] hexChars = hexString.toCharArray();
		byte[] d = new byte[length];
		for (int i = 0; i < length; i++) {
			int pos = i * 2;
			d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
		}
		return d;
	}

	private static byte charToByte(char c) {
		return (byte) "0123456789ABCDEF".indexOf(c);
	}
	
	static Random random = new Random();
	public static int generateRandom(){
		int randomId = random.nextInt(999999999);
		//logger.info("Random Id " + randomId);
		return randomId;
		
	}

	public static UTCDateTime.Builder buildUTCDateTime(UTCDateTime.Builder utcDateTimeBuilder){
		
		GregorianCalendar date = new GregorianCalendar(); /*LR*/
		utcDateTimeBuilder/*.setGpsUtcYrNoActl*/.setUTCYear(date.get(Calendar.YEAR));
		utcDateTimeBuilder/*.setGpsUtcMnthNoActl*/.setUTCMonth(date.get(Calendar.MONTH));
		utcDateTimeBuilder/*.setGpsUtcDayNoActl*/.setUTCDay(date.get(Calendar.DAY_OF_MONTH));
		utcDateTimeBuilder/*.setGPSUTCHours*/.setUTCHour(date.get(Calendar.HOUR));
		utcDateTimeBuilder/*.setGPSUTCMinutes*/.setUTCMin(date.get(Calendar.MINUTE));
		utcDateTimeBuilder/*.setGPSUTCSeconds*/.setUTCSecond(date.get(Calendar.SECOND));
		
//		logger.info(date.get(Calendar.YEAR) + ":" + date.get(Calendar.MONTH) );
		return utcDateTimeBuilder;
	}
}
