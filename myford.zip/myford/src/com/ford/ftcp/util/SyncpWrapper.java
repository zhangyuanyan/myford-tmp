package com.ford.ftcp.util;

import java.util.Arrays;

import org.apache.commons.codec.binary.Base64;

public class SyncpWrapper {
	
	static 
	{
//		System.out.println(System.getProperty("java.library.path"));
		System.loadLibrary("SyncpWrapper");
	}
	
	public static int  FLAG_NO_SECURITY = 0x00;
	public static int  FLAG_ENCRYPTION_INTEGRITY =0x03;
	public static int  FLAG_ENCRYPTION_ONLY      =0x01;
	public static int  FLAG_INTEGRITY_ONLY       =0x02;
	public static int  FLAG_HIGH_BANDWIDTH       =0x01;
	public static int  FLAG_RESPONSE_REQ         =0x01;
	public static int  FLAG_ESN_REQ              =0x01;

	public static int  FLAG_NO_SECURITY_MASK          =0x00;
	public static int  FLAG_ENCRYPTION_INTEGRITY_MASK =0x06;
	public static int  FLAG_ENCRYPTION_ONLY_MASK      =0x02;
	public static int  FLAG_INTEGRITY_ONLY_MASK       =0x04;
	public static int  FLAG_HIGH_BANDWIDTH_MASK       =0x08;
	public static int  FLAG_RESPONSE_REQ_MASK         =0x10;
	public static int  FLAG_ESN_REQ_MASK              =0x01;

	public static int  VMCU =0x00; /* value for VMCU destination */
	public static int  CCPU =0x01; /* value for CCPU destination */

	/* General (legacy defines) */
	public static int  MESSAGE_TYPE_LEN =1;
	public static int  L_PAYLOAD_SIZE_LEN =2;
	public static int  H_PAYLOAD_SIZE_LEN =4;
	public static int  L_IV_LEN =8;
	public static int  H_IV_LEN =16;
	public static int  L_TAG_LEN =8;
	public static int  H_TAG_LEN =16;

	public static int  ESN_LEN =8  ;          /* size of ESN */
	public static int  MAX_HEADER_LENGTH =40; /* this is the biggest header length from below *_HEADER_LEN */
	public static int  MAX_IV_LENGTH     =16; /* this is the biggest IV length */
	public static int  MAX_TAG_LENGTH    =16; /* this is the biggest TAG length */
	public static int  AES_KEY_SIZE =16 ;     /* size of AES keys on CCPU/VMCU used (128-bit) */

	/* some internal error codes */
	public static int  SYNCP_ERR_OK                    =0x00; /* success */
	public static int  SYNCP_ERR_ENCRYPT		        =0x01; /* encryption operation failed */
	public static int  SYNCP_ERR_DECRYPT		        =0x02; /* decryption operation failed */
	public static int  SYNCP_ERR_INVALID_TAG	        =0x03; /* signature tag did not validate */
	public static int  SYNCP_ERR_PROTOCOL_VER_MISMATCH =0x04; /* protocol version unknown */
	public static int  SYNCP_ERR_NULL_VALUE            =0x05; /* input pointer provided was NULL */
	public static int  SYNCP_ERR_PACKET_TOO_SMALL      =0x06; /* reported packet size too small for header decode */
	public static int  SYNCP_ERR_PAYLOAD_TOO_SMALL     =0x07; /* payload size too small for packet data decode */
	public static int  SYNCP_ERR_PACKET_LENGTH         =0x08; /* packet header length larger than provided packet buffer length */
	public static int  SYNCP_ERR_EXCEED_LENGTH_SIZE    =0x09; /* buffer length exceeded size for low/high bandwidth */
	public static int  SYNCP_ERR_PAYLOAD_ALLOC         =0x0A; /* reported payload allocation size smaller than reported size */
	public static int  SYNCP_ERR_LOWBAND_RESP_REQ      =0x0B; /* responce required was set for encode on low bandwidth packet */
	
	int high_bandwidth;
	int response_req;
	int esn_req;
	int cpu;
	int cpu_key;
	int protocol_version;
	int payload_size;
	int payload_alloc_size;
	int msg_id_module;
	int msg_id_server;
	int security_mode;
	
	char service_type;
	char cmd_ver_type;
	char msg_status;
	
	String esn;
	String iv;
	String tag;
	
	byte[] payload;
	byte[] key;
	
	boolean debug = false;
	
		
	public boolean isDebug() {
		return debug;
	}

	public void setDebug(boolean debug) {
		this.debug = debug;
	}

	public int getSecurity_mode() {
		return security_mode;
	}

	public void setSecurity_mode(int security_mode) {
		this.security_mode = security_mode;
	}
	
	public int getHigh_bandwidth() {
		return high_bandwidth;
	}

	public void setHigh_bandwidth(int high_bandwidth) {
		this.high_bandwidth = high_bandwidth;
	}

	public int getResponse_req() {
		return response_req;
	}

	public void setResponse_req(int response_req) {
		this.response_req = response_req;
	}

	public int getEsn_req() {
		return esn_req;
	}

	public void setEsn_req(int esn_req) {
		this.esn_req = esn_req;
	}

	public int getCpu() {
		return cpu;
	}

	public void setCpu(int cpu) {
		this.cpu = cpu;
	}

	public int getCpu_key() {
		return cpu_key;
	}

	public void setCpu_key(int cpu_key) {
		this.cpu_key = cpu_key;
	}

	public int getProtocol_version() {
		return protocol_version;
	}

	public void setProtocol_version(int protocol_version) {
		this.protocol_version = protocol_version;
	}

	public int getPayload_size() {
		return payload_size;
	}

	public void setPayload_size(int payload_size) {
		this.payload_size = payload_size;
	}

	public int getPayload_alloc_size() {
		return payload_alloc_size;
	}

	public void setPayload_alloc_size(int payload_alloc_size) {
		this.payload_alloc_size = payload_alloc_size;
	}

	public int getMsg_id_module() {
		return msg_id_module;
	}

	public void setMsg_id_module(int msg_id_module) {
		this.msg_id_module = msg_id_module;
	}

	public int getMsg_id_server() {
		return msg_id_server;
	}

	public void setMsg_id_server(int msg_id_server) {
		this.msg_id_server = msg_id_server;
	}

	public char getService_type() {
		return service_type;
	}

	public void setService_type(char service_type) {
		this.service_type = service_type;
		//this.service_type = Character.toChars(service_type)[0];
		//System.out.println("setService_type value" + (int) this.service_type);
	}

	public char getCmd_ver_type() {
		return cmd_ver_type;
	}

	public void setCmd_ver_type(char cmd_ver_type) {
		this.cmd_ver_type = (char) cmd_ver_type;
		//this.cmd_ver_type = Character.toChars(cmd_ver_type)[0];
		//System.out.println("setCmd_ver_type value" + (int) this.cmd_ver_type);
	}

	public char getMsg_status() {
		return msg_status;
	}

	public void setMsg_status(char msg_status) {
		//this.msg_status = Character.toChars(msg_status)[0];
		this.msg_status = msg_status;
	}

	public String getEsn() {
		return esn;
	}

	public void setEsn(String esn) {
		this.esn = esn;
	}

	public String getIv() {
		return iv;
	}

	public void setIv(String iv) {
		this.iv = iv;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public byte[] getPayload() {
		return payload;
	}

	public void setPayload(byte[] payload) {
		this.payload = payload;
	}

	public byte[] getKey() {
		return key;
	}

	public void setKey(byte[] key) {
		this.key = key;
	}

	@Override
	public String toString() {
		return "SyncpWrapper [high_bandwidth=" + high_bandwidth
				+ ", response_req=" + response_req + ", esn_req=" + esn_req
				+ ", cpu=" + cpu + ", cpu_key=" + cpu_key
				+ ", protocol_version=" + protocol_version + ", payload_size="
				+ payload_size + ", payload_alloc_size=" + payload_alloc_size
				+ ", msg_id_module=" + msg_id_module + ", msg_id_server="
				+ msg_id_server + ", security_mode=" + security_mode
				+ ", service_type=" + (int) service_type + ", cmd_ver_type="
				+ (int) cmd_ver_type + ", msg_status=" + (int) msg_status + ", esn=" + esn
				+ ", iv=" + iv + ", tag=" + tag + ", payload="
				+ Arrays.toString(payload) + ", key=" + Arrays.toString(key)
				+ "]";
	}
	
	public SyncpWrapper() {
		// TODO Auto-generated constructor stub
	}
	
	public SyncpWrapper(byte[] key) {
		// TODO Auto-generated constructor stub
		this.key = key;
	}
	
	/*
	 * Encodes payload and returns encoded packet
	 */
	public native byte[] encode();
	
	/*
	 * Decodes packet and populates SyncpWrapper attributes including decoded payload
	 */
	public native int decode(byte[] packet);
	
	/*
	 * Decodes packet header only and populates attributes. Does not decode payload
	 */
	public native int decodeHeader(byte[] packet);
	
	public String getRandomNumber()
	{
		String rNumber = null;
		int length = 0;
		while(length != 8)
		{
			int number = new java.util.Random().nextInt(100000000);
			rNumber = String.valueOf(number);
			length = rNumber.length();
		}
		
		return rNumber;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SyncpWrapper.testEncode("SyncpWrapper_EncodedPacket.dat");
		SyncpWrapper.testDecodeHeader("SyncpWrapper_EncodedPacket.dat");
		SyncpWrapper.testDecode("SyncpWrapper_EncodedPacket.dat");
		//SyncpWrapper.testDecode("C:\\chary\\ibm-business\\engagements\\Ford\\syncp\\clarion-data\\dump data for protocol 1.4.4\\dump data for protocol 1.4.4\\Syncp_TcuAlert.bin");
		//SyncpWrapper.gpbDecode("C:\\chary\\ibm-business\\engagements\\Ford\\syncp\\clarion-data\\dump data for protocol 1.4.4\\dump data for protocol 1.4.4\\GPB_CmdResp.bin", Category.RESPONSE);
	}
	
	public static void testEncode(String fileName)
	{
		SyncpWrapper syncp = new SyncpWrapper();
		byte[] payload = "Hello!!!".getBytes();
		// make sure key is 16 byte binary
		byte[] key = "b2b16fe6f2e4df0b".getBytes();
		syncp.setCpu(0);
		syncp.setEsn_req(SyncpWrapper.FLAG_ESN_REQ);
		syncp.setHigh_bandwidth(1);
		syncp.setResponse_req(0);
		syncp.setSecurity_mode(SyncpWrapper.FLAG_ENCRYPTION_INTEGRITY);
		syncp.setCpu_key(0);		
		syncp.setService_type((char) 4);
		syncp.setCmd_ver_type((char) 1);		
		syncp.setProtocol_version(0);
		syncp.setPayload_size(payload.length);
		syncp.setPayload_alloc_size(payload.length);
		syncp.setEsn("XN3W2HRR");
		syncp.setIv(syncp.getRandomNumber());
		syncp.setPayload(payload);
		syncp.setMsg_id_module(0);
		syncp.setMsg_id_server(0);
		syncp.setMsg_status((char) 0);
		syncp.setKey(key);
		syncp.setDebug(true);
		
		// encode
		System.out.println("Encoding ... " + syncp);
		byte[] packet = syncp.encode();
		if(packet != null)
		{
			System.out.println("Encode is successful ... ");
			System.out.println("Returned Packet Length: " + packet.length);
			//System.out.println("Returned Packet: " + packet);
			// write encoded packet to a file
//			try
//			{
//				Utility.writeToFile(packet, fileName);
//			}
//			catch(IOException ioe)
//			{
//				ioe.printStackTrace();
//			}
		}
	}
	
	public static void testDecodeHeader(String fileName)
	{
		System.out.println("Decoding Header ...");
		byte[] packet = null;
//		try
//		{
//			packet = Utility.readFromFile(fileName);
//			//System.out.println("Encoded Packet Length: " + packet.length);
//		}
//		catch(IOException ioe)
//		{
//			ioe.printStackTrace();
//		}
				
		SyncpWrapper syncp = new SyncpWrapper();
		syncp.setDebug(true);
		if(packet != null)
		{
			int success = syncp.decodeHeader(packet);
			
			if(success == 0)
			{
				System.out.println("DecodeHeader is successful: " + syncp);					
			}	
		}
					
	}
	
	public static void testDecode(String fileName)
	{
		System.out.println("Decoding Packet ...");
		byte[] packet = null;
//		try
//		{
//			packet = Utility.readFromFile(fileName);
//			//System.out.println("Encoded Packet Length: " + packet.length);
//		}
//		catch(IOException ioe)
//		{
//			ioe.printStackTrace();
//		}
		
		//SyncpWrapper syncp = new SyncpWrapper("b2b16fe6f2e4df0b".getBytes());
		SyncpWrapper syncp = new SyncpWrapper(convertBase64ToBinary("cccccccccccccccc"));
		syncp.setDebug(true);
		if(packet != null)
		{
			int success = syncp.decode(packet);
			
			if(success == 0)
			{
				System.out.println("Decode is successful: " + syncp);	
				System.out.println("Decoded Packet Length: " + syncp.payload.length);
				System.out.println("Decoded Packet: " + new String(syncp.payload));
				
				// parse command 
				try
				{
//					FtcpMessage ftcpMessage = new FtcpMessage(Category.ALERT, syncp.payload);
//					ftcpMessage.parse();
//					System.out.println("Parsed Message:" + ftcpMessage);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}	
		}					
	}
	
//	public static void gpbDecode(String file, Category category)
//	{
//		System.out.println("Reading file: " + file);
//		byte[] payload = null;
//		try
//		{
//			payload = Utility.readFromFile(file);			
//			FtcpMessage ftcpMessage = new FtcpMessage(category, payload);
//			System.out.println("Parsing data ...");
//			ftcpMessage.parse();
//			System.out.println("Parsed Message:" + ftcpMessage);
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}
//	}
	
	public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len/2];

        for(int i = 0; i < len; i+=2){
            data[i/2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i+1), 16));
        }

        System.out.println("Converted Key: " + new String(data));
        return data;
    }
	
	public static byte[] convertBase64ToBinary(String base64Str) 
	{
	    return Base64.decodeBase64(base64Str.getBytes());	     
	}
};