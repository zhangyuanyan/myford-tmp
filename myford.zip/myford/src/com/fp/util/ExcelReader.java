package com.fp.util;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	 
    /**
     * ��������������
     * @param filePath
     * @return
     * @throws IOException
     * @date    2013-5-11
     */
    public static final Workbook createWb(String filePath) throws IOException {
        if(StringUtils.isBlank(filePath)) {
            throw new IllegalArgumentException("��������!!!") ;
        }
        if(filePath.trim().toLowerCase().endsWith("xls")) {
            return new HSSFWorkbook(new FileInputStream(filePath)) ;
        } else if(filePath.trim().toLowerCase().endsWith("xlsx")) {
            return new XSSFWorkbook(new FileInputStream(filePath)) ;
        } else {
            throw new IllegalArgumentException("��֧�ֳ���xls/xlsx������ļ���ʽ!!!") ;
        }
    }
    
    public static final Sheet getSheet(Workbook wb ,String sheetName) {
        return wb.getSheet(sheetName) ;
    }
     
    public static final Sheet getSheet(Workbook wb ,int index) {
        return wb.getSheetAt(index) ;
    }
     
    public static final List<Object[]> listFromSheet(Sheet sheet, int expectedTotalRow) {
        int rowTotal = sheet.getPhysicalNumberOfRows() ;
        System.out.println("rowTotal: " + rowTotal);
        List<Object[]> list = new ArrayList<Object[]>() ;
        for(int r = sheet.getFirstRowNum() ; r <= expectedTotalRow ; r ++) {
            Row row = sheet.getRow(r) ;
            if(row == null)continue ;
            // ������row.getPhysicalNumberOfCells()�����ܻ��п�cell�����������
            // ʹ��row.getLastCellNum()���ٿ��Ա�֤����������������кܶ�Nullֵ�����ʹ�ü��ϵĻ����Ͳ�˵��
            Object[] cells = new Object[row.getLastCellNum()] ;
            for(int c = row.getFirstCellNum() ; c <= row.getLastCellNum() ; c++) {
                Cell cell = row.getCell(c) ;
                if(cell == null)continue ;
                cells[c] = getValueFromCell(cell) ;
            }
            list.add(cells) ;
        }
         
        return list ;
    }
     
     
    /**
     * ��ȡ��Ԫ�����ı���Ϣ
     * @param cell
     * @return
     * @date    2013-5-8
     */
    public static final String getValueFromCell(Cell cell) {
        if(cell == null) {
            System.out.println("Cell is null !!!") ;
            return null ;
        }
        String value = null ;
        switch(cell.getCellType()) {
            case Cell.CELL_TYPE_NUMERIC :   // ����
                value = String.valueOf(cell.getNumericCellValue()) ;
                break ;
            case Cell.CELL_TYPE_STRING:     // �ַ���
                value = cell.getStringCellValue() ;
                break ;
            case Cell.CELL_TYPE_FORMULA:    // ��ʽ
                double numericValue = cell.getNumericCellValue() ;
                value = String.valueOf(numericValue) ;
                break ;
            case Cell.CELL_TYPE_BLANK:              // �հ�
                value = "" ;
                break ;
            case Cell.CELL_TYPE_BOOLEAN:            // Boolean
                value = String.valueOf(cell.getBooleanCellValue()) ;
                break ;
            case Cell.CELL_TYPE_ERROR:              // Error�����ش�����
                value = String.valueOf(cell.getErrorCellValue()) ;
                break ;
            default:value = StringUtils.EMPTY ;break ;
        }
        // ʹ��[]��¼����
        return value;
    }  
     
}