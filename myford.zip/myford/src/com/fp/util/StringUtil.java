package com.fp.util;

public class StringUtil {
	public static int hexStr2Int(String hexStr) {
		int tenCode = Integer.parseInt(hexStr.toLowerCase().replace("0x", ""),16);
		
		return tenCode;
	}
	
	public static void main(String[] args) {
		System.out.println(hexStr2Int("0x3FE"));
	}
	public static String getStackMsg(Throwable e) {

		StringBuffer sb = new StringBuffer();
		StackTraceElement[] stackArray = e.getStackTrace();
		for (int i = 0; i < stackArray.length; i++) {
		StackTraceElement element = stackArray[i];
		sb.append(element.toString() + "\n");
		}
		return sb.toString();
	} 
}
