package com.fp.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.RenderingHints;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.ui.TextAnchor;

public class JFreeChartUtil {
	public static void GenerateLine(String imgpath, String title,
			String XTitle, String YTitle, CategoryDataset data)
			throws IOException {
		// CategoryDataset dataset = getDataSet2();
		CategoryDataset dataset = data;

		JFreeChart chart = ChartFactory.createLineChart(title, // ����
				XTitle, // Ŀ¼�ᣨˮƽ��
				YTitle, // ��ֵ�ᣨ��ֱ��
				dataset, // ���ݼ�
				PlotOrientation.VERTICAL, // ͼ������ˮƽ/��ֱ��
				true, // �Ƿ���ʾͼ�������ڼ򵥵���״ͼ�Ǳ���ģ�
				false, // �Ƿ����ɹ���
				false // �Ƿ����� url ����
				);
		// ����Title������(��Щ�汾���������)
		chart.getTitle().setFont((new Font("����", Font.PLAIN, 16)));
		chart.getLegend().setItemFont(new Font("����", Font.BOLD, 14));
		chart.getRenderingHints().put(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		chart.setBackgroundPaint(Color.WHITE);
		CategoryPlot plot = chart.getCategoryPlot();// ��ȡͼ���������

		CategoryAxis domainAxis = plot.getDomainAxis();
		domainAxis.setTickLabelFont(new Font("����", Font.PLAIN, 12));
		domainAxis.setLabelFont(new Font("����", Font.PLAIN, 12));
		NumberAxis numberaxis = (NumberAxis) plot.getRangeAxis();
		numberaxis.setTickLabelFont(new Font("����", Font.PLAIN, 12));
		numberaxis.setLabelFont(new Font("����", Font.PLAIN, 12));
		CategoryItemRenderer renderer = plot.getRenderer();
//		XYLineAndShapeRenderer xylineandshaperenderer = (XYLineAndShapeRenderer) plot  
//                .getRenderer();  
		renderer.setBaseItemLabelsVisible(true);  
		renderer  
         .setBasePositiveItemLabelPosition(new ItemLabelPosition(  
                 ItemLabelAnchor.OUTSIDE12, TextAnchor.BASELINE_CENTER));  
//		renderer  
//         .setBaseItemLabelGenerator(new StandardXYItemLabelGenerator());  
		renderer.setBaseItemLabelPaint(new Color(102, 102, 102));
		File file = new File(new File(imgpath).getParent());
		if (!file.getParentFile().exists())
			file.getParentFile().mkdir();
		if (!file.exists())
			file.mkdir();
		FileOutputStream fos_jpg = null;
		try {
			fos_jpg = new FileOutputStream(imgpath); // ͼƬ�����Ŀ¼
			ChartUtilities.writeChartAsJPEG(fos_jpg, 1, chart, 900, 200, null);
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			try {
				fos_jpg.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
//		ChartFrame frame = new ChartFrame("", chart, true);
//		frame.pack();
//		frame.setVisible(true);
	}
}
