package com.fp.util;

public class DataDictionaryUtil {
	public static void main(String[] args) {
		System.out.println(0x0AEB00);
	}
	public static String toHexString(int iTen) {
		return "0x"+Integer.toHexString(iTen).toUpperCase();
	}
	
	public static String batteryFaultSeverity(int iTen) {
		String retStr = "";
		if(iTen == 0) {
			retStr = "WARNING";
		} else if (iTen == 1) {
			retStr = "SERVICE";
		} else {
			retStr = "unknown";
		}
		return retStr;
	}
	
	public static String ecuStatus(int iTen) {
		String retStr = "";
		if(iTen == 0) {
			retStr = "NO_COMMUNICATION";
		} else if (iTen == 1) {
			retStr = "CAN_GDS";
		} else if (iTen == 2) {
			retStr = "GGDS";
		} else if (iTen == 3) {
			retStr = "UNKNOWN";
		}
		return retStr;
	}
	
	public static String formatDtcDesc(int iTen) {
		String hexStr = toHexString(iTen);
		String retStr = "";
		if (hexStr.equals("0xAEB00")) {
			retStr = "HEV Battery Temp Sensor \"D\" Circuit High";
		} else if (hexStr.equals("0xAFB00")) {
			retStr = "HEV Battery System Voltage High";
		} else if (hexStr.equals("0x56200")) {
			retStr = "System Voltage Low";
		}else if (hexStr.equals("0xA7D00")) {
			retStr = "HEV Battery Pack State of Charge Low";
		}else if (hexStr.equals("0xAA100")) {
			retStr = "HEV Battery Positive Contactor Circuit Stuck Closed	";
		}else if (hexStr.equals("0xAA400")) {
			retStr = "HEV Battery Negative Contactor Circuit Stuck Closed	";
		}else if (hexStr.equals("0xAAF00")) {
			retStr = "HEV Battery Pack Air Temperature Sensor \"A\" Circuit High";
		}else if (hexStr.equals("0xABD00")) {
			retStr = "HEV Battery Pack Voltage Sense \"A\" Circuit High	";
		}else if (hexStr.equals("0xB5400")) {
			retStr = "HEV Battery Voltage Sense \"F\" Circuit";
		}else if (hexStr.equals("0xB5900")) {
			retStr = "HEV Battery Voltage Sense \"G\" Circuit	";
		}else if (hexStr.equals("0xC59400")) {
			retStr = "Invalid Data Received From Hybrid/EV Powertrain Control Module";
		}else if (hexStr.equals("0xD00349")) {
			retStr = "System Clock";
		}else if (hexStr.equals("0xC10000")) {
			retStr = "Lost Communication With ECM/PCM \"A\"	";
		}else if (hexStr.equals("0xC15100")) {
			retStr = "Lost Communication With Restraints Control Module";
		}else if (hexStr.equals("0xC40100")) {
			retStr = "Invalid Data Received from  ECM/PCM A	";
		}else if (hexStr.equals("0xC45200")) {
			retStr = "Invalid Data Received From Restraints Control Module";
		} else {
			retStr = "UNKNOWN";
		}
		return retStr;
	}
}
