package com.fp.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

public class RestfulMainHttpsUtil {
	private static Logger logger = Logger.getLogger(RestfulMainHttpsUtil.class
			.getName());

	public static String post(String url, Map<String, String> params) {
		DefaultHttpClient httpclient = new DefaultHttpClient();
		String body = null;

		HttpPost post = postForm(url, params);
		post.setHeader("Authorization", "Basic ZWFpLWNsaWVudDo=");
		body = invoke(httpclient, post);

		httpclient.getConnectionManager().shutdown();

		return body;
	}

	private static String invoke(DefaultHttpClient httpclient,
			HttpUriRequest httpost) {

		HttpResponse response = sendRequest(httpclient, httpost);
		String body = paseResponse(response);

		return body;
	}

	private static String paseResponse(HttpResponse response) {
		HttpEntity entity = response.getEntity();

		String charset = EntityUtils.getContentCharSet(entity);

		String body = null;
		try {
			body = EntityUtils.toString(entity);
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return body;
	}

	private static HttpResponse sendRequest(DefaultHttpClient httpclient,
			HttpUriRequest httpost) {
		HttpResponse response = null;

		try {
			response = httpclient.execute(httpost);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return response;
	}

	private static HttpPost postForm(String url, Map<String, String> params) {

		HttpPost httpost = new HttpPost(url);
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();

		Set<String> keySet = params.keySet();
		for (String key : keySet) {
			nvps.add(new BasicNameValuePair(key, params.get(key)));
		}

		try {
			httpost.setEntity(new UrlEncodedFormEntity(nvps));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		return httpost;
	}

	public static void main(String[] args) throws Exception {
		// trustEveryone();
		// System.out.println(loginLightHouse("zhang2@163.com", "123123"));
		Map<String, String> params = new HashMap<String, String>();
		params.put("grant_type", "password");
		params.put("username", "zhang2@163.com");
		params.put("password", "123123");
		// System.out.println(post("https://ssoqa.ford.com/EAI/oauth/token",
		// params));
//		System.out.println(loginLightHouse(Constants.LIGHT_HOUSE_URL,
//				"zhang3@163.com", "Bbpp1314"));
//	System.out.println(loginUser("6f79de64-729d-4413-b9c5-2c0e4dc8fd5a"));
//		System.out.println(getUserProfile(
//				"PAA/AHgAbQBsACAAdgBlAHIAcwBpAG8AbgA9ACIAMQAuADAAIgAgAGUAbgBjAG8AZABpAG4AZwA9ACIAdQB0AGYALQAxADYAIgA/AD4APABBAEMAPgA8AFQAbwBrAGUAbgBEAGEAdABhAD4APAAhAFsAQwBEAEEAVABBAFsAewAiAEQAaQBzAHAAbABhAHkATgBhAG0AZQAiADoAIgB6AGgAYQBuAGcAMwBAADEANgAzAC4AYwBvAG0AIgAsACIAVQBzAGUAcgBJAGQAIgA6ACIANQBkADYAYwBiADgAYQBkAC0AZAAzADkAMgAtADQAMwA3ADcALQBhADEAMwA1AC0AOQAxAGIAMgBjADQAYwA4AGIANwBlADAAIgAsACIARQB4AHQAZQByAG4AYQBsAFQAbwBrAGUAbgAiADoAIgA2AGYANwA5AGQAZQA2ADQALQA3ADIAOQBkAC0ANAA0ADEAMwAtAGIAOQBjADUALQAyAGMAMABlADQAZABjADgAZgBkADUAYQAiACwAIgBTAGUAcwBzAGkAbwBuAEkAZAAiADoAIgAxADMAYgA4ADMANgA3ADIALQA4ADUAOQBmAC0ANAAxADIAZAAtAGIAMAA2ADEALQBmADgAZQAxADgAYgAxAGEAMAA1ADIAOQAiACwAIgBEAGEAdABlAEkAcwBzAHUAZQBkACIAOgAtADgANQA4ADcANgAwADkANQAyADMANwA4ADEAOAAzADYANwA2ADMALAAiAEkAcwBzAHUAZQByACIAOgAiAGwAaQBnAGgAdABoAG8AdQBzAGUAIgAsACIAVgBhAGwAaQBkAGEAdABlAGQAIgA6ACIAMgAwADEANQAtADAAOAAtADIANwBUADAANQA6ADQAOAA6ADIANwAuADIAOQAzADkAMAA0ADUAKwAwADAAOgAwADAAIgAsACIAVgBlAHIAcwBpAG8AbgAiADoAIgAxAC4AMAAuADAAIgAsACIAVABUAEwAIgA6ADMAOAAwADAAMAAuADAAfQBdAF0APgA8AC8AVABvAGsAZQBuAEQAYQB0AGEAPgA8AFMAaQBnAG4AYQB0AHUAcgBlAD4APAAhAFsAQwBEAEEAVABBAFsAZABpADUAMgBkAE0AaQBrAEcAYQBUAE4AbwBUAHIAVQBCAHUAYgByAFoAdgAxAGoAVAA5AFoAYQBxAFgAeABHAGEAaABHAHQALwBDAFAAcQBBAC8AYwA9AF0AXQA+ADwALwBTAGkAZwBuAGEAdAB1AHIAZQA+ADwALwBBAEMAPgA=",
//				"zhang3@163.com", "12-21-2014%2010%3A01%3A50%20AM"));
		
		String json = getAllVehicles("PAA/AHgAbQBsACAAdgBlAHIAcwBpAG8AbgA9ACIAMQAuADAAIgAgAGUAbgBjAG8AZABpAG4AZwA9ACIAdQB0AGYALQAxADYAIgA/AD4APABBAEMAPgA8AFQAbwBrAGUAbgBEAGEAdABhAD4APAAhAFsAQwBEAEEAVABBAFsAewAiAEQAaQBzAHAAbABhAHkATgBhAG0AZQAiADoAIgB6AGgAYQBuAGcAMwBAADEANgAzAC4AYwBvAG0AIgAsACIAVQBzAGUAcgBJAGQAIgA6ACIANQBkADYAYwBiADgAYQBkAC0AZAAzADkAMgAtADQAMwA3ADcALQBhADEAMwA1AC0AOQAxAGIAMgBjADQAYwA4AGIANwBlADAAIgAsACIARQB4AHQAZQByAG4AYQBsAFQAbwBrAGUAbgAiADoAIgA2AGYANwA5AGQAZQA2ADQALQA3ADIAOQBkAC0ANAA0ADEAMwAtAGIAOQBjADUALQAyAGMAMABlADQAZABjADgAZgBkADUAYQAiACwAIgBTAGUAcwBzAGkAbwBuAEkAZAAiADoAIgAxADMAYgA4ADMANgA3ADIALQA4ADUAOQBmAC0ANAAxADIAZAAtAGIAMAA2ADEALQBmADgAZQAxADgAYgAxAGEAMAA1ADIAOQAiACwAIgBEAGEAdABlAEkAcwBzAHUAZQBkACIAOgAtADgANQA4ADcANgAwADkANQAyADMANwA4ADEAOAAzADYANwA2ADMALAAiAEkAcwBzAHUAZQByACIAOgAiAGwAaQBnAGgAdABoAG8AdQBzAGUAIgAsACIAVgBhAGwAaQBkAGEAdABlAGQAIgA6ACIAMgAwADEANQAtADAAOAAtADIANwBUADAANQA6ADQAOAA6ADIANwAuADIAOQAzADkAMAA0ADUAKwAwADAAOgAwADAAIgAsACIAVgBlAHIAcwBpAG8AbgAiADoAIgAxAC4AMAAuADAAIgAsACIAVABUAEwAIgA6ADMAOAAwADAAMAAuADAAfQBdAF0APgA8AC8AVABvAGsAZQBuAEQAYQB0AGEAPgA8AFMAaQBnAG4AYQB0AHUAcgBlAD4APAAhAFsAQwBEAEEAVABBAFsAZABpADUAMgBkAE0AaQBrAEcAYQBUAE4AbwBUAHIAVQBCAHUAYgByAFoAdgAxAGoAVAA5AFoAYQBxAFgAeABHAGEAaABHAHQALwBDAFAAcQBBAC8AYwA9AF0AXQA+ADwALwBTAGkAZwBuAGEAdAB1AHIAZQA+ADwALwBBAEMAPgA=", "", "12-21-2014%2011%3A50%3A12%20AM");
		System.out.println(json);
		
	}

	public static String getUserProfile(String authToken, String userId,
			String datetime) {
		logger.info("getUserProfile start.");
		String returnStr = "";

		try {
			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/users"
					 + "?lrdt=" + datetime);

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setRequestMethod("GET");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}
		logger.info("getUserProfile end.");
		return returnStr;
	}

	public static String getStartStatus(String authToken, String vin,
			String commandId) {
		logger.info("getStartStatus start.");
		String returnStr = "";

		try {
			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/vehicles/"
					+ vin + "/engine/start/" + commandId + "/");

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setRequestMethod("GET");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}
		logger.info("getStartStatus end.");
		return returnStr;
	}

	public static String loginLightHouse(String url, String uname,
			String password) throws Exception {
		logger.info("loginLightHouse start.");
		String returnStr = "";
		try {

			URL targetUrl = new URL(url
					+ "/EAI/oauth/token?grant_type=password&username=" + uname
					+ "&password=" + password);

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod("POST");
			httpConnection.setRequestProperty("Authorization",
					"Basic ZWFpLWNsaWVudDo=");
			httpConnection.setRequestProperty("User-Agent",
					"Apache-HttpClient/4.1.1 (java 1.5)");
			httpConnection.setRequestProperty("grant_type", "password");
			httpConnection.setRequestProperty("username", uname);
			httpConnection.setRequestProperty("password", password);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			if (httpConnection.getResponseCode() != 200) {
				System.out.println(httpConnection.getResponseMessage());
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();
		} catch (Exception e) {
			throw e;
		}
		logger.info("loginLightHouse end.");
		return returnStr;
	}

	public static String getLockStatus(String authToken, String vin,
			String commandId) {
		String returnStr = "";
		logger.info("getLockStatus start.");
		try {
			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/vehicles/"
					+ vin + "/doors/lock/" + commandId + "/");

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setRequestMethod("GET");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}
		logger.info("getLockStatus end.");
		return returnStr;
	}

	public static String loginUser(String lhToken) {
		String returnStr = "";
		logger.info("loginUser start.");
		try {
			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/sessions/");

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod("PUT");
			httpConnection.setRequestProperty("Content-Type",
					"application/json");
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			String input = "{\"lighthouseToken\": \"" + lhToken + "\"}";

			OutputStream outputStream = httpConnection.getOutputStream();
			outputStream.write(input.getBytes());
			outputStream.flush();

			if (httpConnection.getResponseCode() != 200) {
				// throw new RuntimeException("Failed : HTTP error code : "
				// + httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		logger.info("loginUser end.");
		return returnStr;
	}

	public static String auth(String userid, String authToken, String vin) {
		String returnStr = "";

		try {

			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/vehicles/"
					+ vin + "/drivers/");

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod("POST");
			httpConnection.setRequestProperty("Content-Type",
					"application/json");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			String input = "{\"userId\": \"" + userid + "\"}";

			OutputStream outputStream = httpConnection.getOutputStream();
			outputStream.write(input.getBytes());
			outputStream.flush();

			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}

		return returnStr;
	}

	public static String lock(String authToken, String vin) {
		String returnStr = "";
		logger.info("lock start.");
		try {

			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/vehicles/"
					+ vin + "/doors/lock/");

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod("PUT");
			httpConnection.setRequestProperty("Content-Type",
					"application/json");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			OutputStream outputStream = httpConnection.getOutputStream();
			outputStream.flush();

			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		logger.info("lock end.");
		return returnStr;
	}

	public static String unlock(String authToken, String vin) {
		String returnStr = "";
		logger.info("unlock start.");
		try {

			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/vehicles/"
					+ vin + "/doors/lock/");

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod("DELETE");
			httpConnection.setRequestProperty("Content-Type",
					"application/json");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			OutputStream outputStream = httpConnection.getOutputStream();
			outputStream.flush();

			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		logger.info("unlock end.");
		return returnStr;
	}

	public static String start(String authToken, String vin) {
		String returnStr = "";
		logger.info("remote start start.");
		try {

			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/vehicles/"
					+ vin + "/engine/start/");

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod("PUT");
			httpConnection.setRequestProperty("Content-Type",
					"application/json");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			OutputStream outputStream = httpConnection.getOutputStream();
			outputStream.flush();

			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		logger.info("remote start end.");
		return returnStr;
	}

	public static String cancelStart(String authToken, String vin) {
		String returnStr = "";
		logger.info("cancel start start.");
		try {

			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/vehicles/"
					+ vin + "/engine/start/");

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod("DELETE");
			httpConnection.setRequestProperty("Content-Type",
					"application/json");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			OutputStream outputStream = httpConnection.getOutputStream();
			outputStream.flush();

			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		logger.info("cancel start end.");
		return returnStr;
	}

	public static String getAllVehicles(String authToken, String userId,
			String lrdt) {
		String returnStr = "";
		logger.info("get all vehicles  start.");
		try {

			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/vehicles/statuses?lrdt=" + lrdt);

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
//			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod("GET");
//			httpConnection.setRequestProperty("Content-Type",
//					"application/json");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);

			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		logger.info("get all vehicle status end.");
		return returnStr;
	}

	public static String refreshVehicleStatus(String authToken, String vin) {
		String returnStr = "";
		logger.info("refresh vehicle start.");
		try {

			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/vehicles/"
					+ vin + "/status/");

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod("PUT");
			httpConnection.setRequestProperty("Content-Type",
					"application/json");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			OutputStream outputStream = httpConnection.getOutputStream();
			outputStream.flush();

			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		logger.info("refresh vehicle status end.");
		return returnStr;
	}

	public static String getVehiclesStatus(String authToken, String vin,
			String datetime) {
		String returnStr = "";
		logger.info("get vehicles status start.");
		try {

			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/vehicles/"
					+ vin + "/status?lrdt=" + datetime);

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setRequestMethod("GET");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			if (httpConnection.getResponseCode() != 200) {
				// throw new RuntimeException("Failed : HTTP error code : "
				// + httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}
		logger.info("get vehicle status end.");
		return returnStr;
	}

	public static void trustEveryone() {
		try {
			HttpsURLConnection
					.setDefaultHostnameVerifier(new HostnameVerifier() {
						public boolean verify(String hostname,
								SSLSession session) {
							return true;
						}
					});
			SSLContext context = SSLContext.getInstance("TLS");
			context.init(null, new X509TrustManager[] { new X509TrustManager() {
				public void checkClientTrusted(X509Certificate[] chain,
						String authType) throws CertificateException {
				}

				public void checkServerTrusted(X509Certificate[] chain,
						String authType) throws CertificateException {
				}

				public X509Certificate[] getAcceptedIssuers() {
					return new X509Certificate[0];
				}
			} }, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(context
					.getSocketFactory());
		} catch (Exception e) { // should never happen
			e.printStackTrace();
		}
	}

	public static String getRefreshVehicleStatus(String authToken, String vin,
			String commandId) {
		logger.info("get refresh vehicle status start.");
		String returnStr = "";

		try {
			URL targetUrl = new URL(Constants.TARGENT_URL + "/api/vehicles/"
					+ vin + "/statusrefresh/" + commandId + "/");

			HttpURLConnection httpConnection = (HttpURLConnection) targetUrl
					.openConnection();
			httpConnection.setRequestMethod("GET");
			httpConnection.setRequestProperty("auth-token", authToken);
			httpConnection.setConnectTimeout(200000);
			httpConnection.setReadTimeout(200000);
			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader((httpConnection.getInputStream())));

			String output;
			while ((output = responseBuffer.readLine()) != null) {
				// System.out.println(output);
				returnStr = returnStr + output;
			}
			httpConnection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}
		logger.info("getRefreshVehicleStatus end.");
		return returnStr;

	}
}
