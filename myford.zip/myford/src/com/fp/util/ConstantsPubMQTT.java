package com.fp.util;

public class ConstantsPubMQTT {
	public static final String TCU_USE_MQTT_URL = "tcp://nellomqtt-PDCSC.cloudapp.net:1883";  //"tcp://fcne0001vehqa.chinacloudapp.cn:1883";
	public static final String TCU_USE_MQTT_USERNAME = "T4860029";//"T4CF0052";
	public static final String TCU_USE_MQTT_PASSWORD = "XMd/kVB9SQaxG/MC8o6vSQ==";//"CPI5gJdy1T7KL394tK+bhg==";
	
	public static final String SDN_USE_MQTT_URL = "tcp://nellomqtt-PDCSC.cloudapp.net:1883";  //"tcp://fcne0001vehqa.chinacloudapp.cn:1883";
	public static final String SDN_USE_MQTT_USERNAME =  "T4860029";//"T4CF0052";
	public static final String SDN_USE_MQTT_PASSWORD = "XMd/kVB9SQaxG/MC8o6vSQ==";//"CPI5gJdy1T7KL394tK+bhg==";
	
	
	
	
	
	
	
	
	
	
	
	
	public static final String TARGENT_URL = "https://fqacnapi.cv.ford.com";
	public static final String LIGHT_HOUSE_URL = "https://ssoqa.ford.com";

	// Rest api performace
	public static final String VIN = "5LMCJ2ANXFUJ16493";//"2LMPJ9J91GBL20112";//"5LMCJ2AN3FUJ07036";//"5LMCJ2AN0FUJ10556";//"5LMCJ2A90FUJ00101";//
	public static final String UNAME = "pdtest4@pd.cn";//"zhang2@163.com";
	public static final String PASSWORD = "12Qwaszx";//"Bbpp1314";
	// Rest api performace (Login performance only)
	public static final String UNAME_REST = "pdtest8@pd.cn";//"zhang2@163.com";
	public static final String PASSWORD_REST = "12Qwaszx";//"Bbpp1314";
	
	
	public static final String ESN = "T4860029";
	public static final String ACCOUNTNAME = "fcnetlm1qa";
	public static final String ACCOUNTKEY = "LYHVkO2Qy+Qq3eUCnVlSdPSIK3p0iIeMgH9HkttSSqgblarvhEyx80gi7WVvV481CEGDUOXLwdxX3yUaPfT67g==";
	
	public static final String REST_LOGIN_USER_API = "LOGIN_USER_API";
	public static final String REST_LOCK_API = "LOCK_API";
	public static final String REST_UNLOCK_API = "UNLOCK_API";
	public static final String REST_REMOTE_START_API = "REMOTE_STAET_API";
	public static final String REST_CANCEL_REMOTE_API = "CANCEL_REMOTE_API";
	public static final String REST_REFRESH_STATUS_API = "REFRESH_STATUS_API";
	public static final int REST_API_TIMEOUT = 200;
	public static final String IS_TEST_AWAKE_ONLY = "yes";
}
