package com.fp.dto;

public class CommonResult {
	private boolean success;
	private int cloundMessageId;
	public int getCloundMessageId() {
		return cloundMessageId;
	}
	public void setCloundMessageId(int cloundMessageId) {
		this.cloundMessageId = cloundMessageId;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	private String msg;
}
