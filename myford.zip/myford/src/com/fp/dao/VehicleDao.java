package com.fp.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.fp.domain.BatteryFault;
import com.fp.domain.RestLoginUserBean;
import com.fp.domain.TcuFtcpRecord;
import com.fp.domain.TcuVehicle;
import com.fp.domain.VehicleBean;

public interface VehicleDao {
	public abstract List<VehicleBean> findVehicleByVin(String vin);

	public abstract List<VehicleBean> findAllVehicles();
	
	public abstract List<BatteryFault> findAllBatteryFault();
	
	public abstract void insertVehicleRecord(VehicleBean bean);
	
	public abstract void insertBatteryFault(BatteryFault bean);
	
	public abstract List<TcuFtcpRecord> selectTcuRecordByCorid(int correlateMsgId);
	
	public abstract void insertTcuFtcpRecord(TcuFtcpRecord bean);
	
	public abstract TcuVehicle findTcuVehicleByEsn(String esn);
	
	public abstract List<TcuVehicle> findTcuVehicleByNamePassword(String name, String password);
	
	public abstract List<TcuVehicle> getAllEsns(String username);
	
	public List<VehicleBean> findAllProCityNullVehicles();
	
	public List<VehicleBean> findCityVehicleCnt();
	
	public List<VehicleBean> findCityVehicles(String city);
	
	public int updateVehicle(VehicleBean bean);
	
	public void insertRestAPI(RestLoginUserBean bean);
	
	public List<RestLoginUserBean> selectPerformanceByType(String typeName, String fromDate, String toDate);
	
	public RestLoginUserBean selectSuccessEtcInfo(String typeName, String fromDate, String toDate);
	
	public List<RestLoginUserBean> selectPerformanceByPager(String typeName, String fromDate, String toDate, @Param("pageNo")int pageNo,@Param("pageSize") int pageSize);
	
	public int getTotalCount(String typeName, String fromDate, String toDate);

	public abstract RestLoginUserBean selectPerformanceById(int id); 
	
}
