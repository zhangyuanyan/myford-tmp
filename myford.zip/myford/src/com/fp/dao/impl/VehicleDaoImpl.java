package com.fp.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fp.dao.VehicleDao;
import com.fp.domain.BatteryFault;
import com.fp.domain.RestLoginUserBean;
import com.fp.domain.TcuFtcpRecord;
import com.fp.domain.TcuVehicle;
import com.fp.domain.VehicleBean;

@Repository
public class VehicleDaoImpl implements VehicleDao {
	public static final String FIND_BY_VIN = "findByVin";
	public static final String SELECT_ALL = "selectAllVehicles";
	public static final String SELECT_ALL_ESN = "selectAllEsns";
	public static final String SELECT_ALL_ESN_NO_USERNAME = "selectAllEsnsNoUsername";
	public static final String SELECT_ALL_BATTERY_FAULT = "selectAllBatteryFault";
	public static final String INSERT_ONE = "insertVehicle";
	public static final String INSERT_BATTERY_FAULT = "insertBatteryFault";
	public static final String SELECT_TCU_RECORD_BY_CORID = "selectAllTcuRecordByCorId";
	public static final String INSERT_TCU_FTCP_RECORD = "insertTCUFTCPRecord";
	public static final String SELECT_TCUVEHICLE_BY_ESN = "selectTcuVehicleByEsn";

	public static final String SELECT_ALL_PRO_CITY_NULL_VEHICLES = "selectAllPCNullVehicles";
	public static final String SELECT_CITY_VEHICLE_CNT = "selectCityVehicleCnt";
	public static final String SELECT_CITY_VEHICLES = "selectCityVehicles";
	public static final String UPDATE_VEHICLE = "updateVehicle";

	public static final String INSERT_REST_LOGIN_USER = "insertRestLoginUser";
	public static final String SELECT_PERFORMANCE_BY_TYPE = "selectPerformanceByType";

	public static final String SELECT_SUCCESS_CNT = "findSuccessCnt";
	public static final String SELECT_FAIL_CNT = "findFailCnt";
	public static final String SELECT_MAX_TIME = "findMaxTime";
	public static final String SELECT_MIN_TIME = "findMinTime";
	public static final String SELECT_AVG_TIME = "findAverageTime";
	
	public static final String SELECT_NAME_PASSWORD = "findNamePassword";
	
	public static final String SELECT_PERFORMANCE_BY_PAGER = "selectPerformanceByPager";
	public static final String SELECT_PERFORMANCE_COUNT = "selectPerformanceCount";
	
	public static final String SELECT_PERFORMANCE_BY_ID = "selectPerformanceByID";

	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public List<VehicleBean> findAllProCityNullVehicles() {
		return sqlSessionTemplate.selectList(SELECT_ALL_PRO_CITY_NULL_VEHICLES);
	}

	@Override
	public List<VehicleBean> findCityVehicleCnt() {
		return sqlSessionTemplate.selectList(SELECT_CITY_VEHICLE_CNT);
	}

	@Override
	public List<VehicleBean> findCityVehicles(String city) {
		return sqlSessionTemplate.selectList(SELECT_CITY_VEHICLES, city);
	}

	@Override
	public int updateVehicle(VehicleBean bean) {
		return sqlSessionTemplate.update(UPDATE_VEHICLE, bean);
	}

	@Override
	public List<VehicleBean> findVehicleByVin(String vin) {

		return sqlSessionTemplate.selectList(FIND_BY_VIN, vin);
	}

	@Override
	public List<TcuFtcpRecord> selectTcuRecordByCorid(int correlateMsgId) {

		return sqlSessionTemplate.selectList(SELECT_TCU_RECORD_BY_CORID,
				correlateMsgId);
	}

	@Override
	public List<VehicleBean> findAllVehicles() {

		return sqlSessionTemplate.selectList(SELECT_ALL);
	}

	@Override
	public void insertVehicleRecord(VehicleBean bean) {
		sqlSessionTemplate.insert(INSERT_ONE, bean);
	}

	@Override
	public void insertRestAPI(RestLoginUserBean bean) {
		sqlSessionTemplate.insert(INSERT_REST_LOGIN_USER, bean);
	}

	@Override
	public void insertBatteryFault(BatteryFault bean) {
		sqlSessionTemplate.insert(INSERT_BATTERY_FAULT, bean);
	}

	@Override
	public List<BatteryFault> findAllBatteryFault() {
		return sqlSessionTemplate.selectList(SELECT_ALL_BATTERY_FAULT);
	}

	@Override
	public void insertTcuFtcpRecord(TcuFtcpRecord bean) {
		sqlSessionTemplate.insert(INSERT_TCU_FTCP_RECORD, bean);
	}

	@Override
	public TcuVehicle findTcuVehicleByEsn(String esn) {
		return sqlSessionTemplate.selectOne(SELECT_TCUVEHICLE_BY_ESN, esn);
	}

	@Override
	public List<TcuVehicle> getAllEsns(String username) {
		if ("".equals(username)) {
			return sqlSessionTemplate.selectList(SELECT_ALL_ESN_NO_USERNAME);
		}
		return sqlSessionTemplate.selectList(SELECT_ALL_ESN, username);
	}

	@Override
	public List<RestLoginUserBean> selectPerformanceByType(String typeName, String fromDate, String toDate) {
		RestLoginUserBean bean = new RestLoginUserBean();
		bean.setTypeName(typeName);
		bean.setFromDate(fromDate);
		bean.setToDate(toDate);
		return sqlSessionTemplate.selectList(SELECT_PERFORMANCE_BY_TYPE,
				bean);
	}

	@Override
	public RestLoginUserBean selectSuccessEtcInfo(String typeName, String fromDate, String toDate) {
		RestLoginUserBean bean = new RestLoginUserBean();
		bean.setTypeName(typeName);
		bean.setFromDate(fromDate);
		bean.setToDate(toDate);
		int successCnt = sqlSessionTemplate.selectOne(SELECT_SUCCESS_CNT,
				bean);
		int failCnt = sqlSessionTemplate.selectOne(SELECT_FAIL_CNT,
				bean);
		double maxTime = 0;
		if (null!=sqlSessionTemplate.selectOne(SELECT_MAX_TIME,
				bean)) {
			maxTime = sqlSessionTemplate.selectOne(SELECT_MAX_TIME,
					bean);
		}
		
		double minTime = 0;
		if (null!=sqlSessionTemplate.selectOne(SELECT_MIN_TIME,
				bean)) {
			minTime = sqlSessionTemplate.selectOne(SELECT_MIN_TIME,
					bean);
		}
		
		double avgTime = 0;
		if (null!=sqlSessionTemplate.selectOne(SELECT_AVG_TIME,
				bean)) {
			avgTime = sqlSessionTemplate.selectOne(SELECT_AVG_TIME,
					bean);
		}

		RestLoginUserBean beanRet = new RestLoginUserBean();
		beanRet.setSuccessCnt(successCnt);
		beanRet.setFailCnt(failCnt);
		beanRet.setMaxTime(maxTime);
		beanRet.setMinTime(minTime);
		beanRet.setAverageTime(avgTime);

		return beanRet;
	}

	@Override
	public List<TcuVehicle> findTcuVehicleByNamePassword(String name, String password) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("name", name);
		params.put("passwrod", password);
		return sqlSessionTemplate.selectList(SELECT_NAME_PASSWORD, params);
	}

	@Override
	public List<RestLoginUserBean> selectPerformanceByPager(String typeName,
			String fromDate, String toDate, int pageNo, int pageSize) {
		
		RestLoginUserBean bean = new RestLoginUserBean();
		bean.setTypeName(typeName);
		bean.setFromDate(fromDate);
		bean.setToDate(toDate);
		bean.setPageNo(pageNo);
		bean.setPageSize(pageSize);
		
		return sqlSessionTemplate.selectList(SELECT_PERFORMANCE_BY_PAGER, bean);
		
	}

	@Override
	public int getTotalCount(String typeName, String fromDate, String toDate) {
		RestLoginUserBean bean = new RestLoginUserBean();
		bean.setTypeName(typeName);
		bean.setFromDate(fromDate);
		bean.setToDate(toDate);
		return sqlSessionTemplate.selectOne(SELECT_PERFORMANCE_COUNT, bean);
	}

	@Override
	public RestLoginUserBean selectPerformanceById(int id) {
		return sqlSessionTemplate.selectOne(SELECT_PERFORMANCE_BY_ID, id);
	}

}
