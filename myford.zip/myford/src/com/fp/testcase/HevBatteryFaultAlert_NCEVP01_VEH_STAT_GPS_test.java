package com.fp.testcase;

import java.util.Calendar;
import java.util.GregorianCalendar;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;

import com.ford.ftcp.util.StringUtil;
import com.ford.ftcp.util.SyncpUtil;
import com.ford.ftcp.v304.FTCP3.AuthStatusEnum;
import com.ford.ftcp.v304.FTCP3.CommonFromVehicle;
import com.ford.ftcp.v304.FTCP3.GPSInfo;
import com.ford.ftcp.v304.FTCP3.HECDateTime;
import com.ford.ftcp.v304.FTCP3.HEVBatteryData;
import com.ford.ftcp.v304.FTCP3.HEVBatteryFaultAlert;
import com.ford.ftcp.v304.FTCP3.HEVBatteryFaultAlert.HEVBatteryFaultSeverityEnum;
import com.ford.ftcp.v304.FTCP3.ShiftedGPSInfo;
import com.ford.ftcp.v304.FTCP3.TCUAlert;
import com.ford.ftcp.v304.FTCP3.TCUNonGenericAlert;
import com.ford.ftcp.v304.FTCP3.UTCDateTime;
import com.ford.ftcp.v304.FTCP3.UTCDateTimeFromCAN;
import com.ford.ftcp.v304.FTCP3.UnshiftedGPSInfo;
import com.ford.ftcp.v304.FTCP3.UnshiftedGPSInfo.IncludeLatLongENUM;
import com.ford.ftcp.v304.FTCP3.VehicleStatus;
import com.ford.ftcp.v304.FTCP3.VehicleStatus.BpedDrvApplENUM;

public class HevBatteryFaultAlert_NCEVP01_VEH_STAT_GPS_test  {
	public static void main(String[] args) throws Exception {
/*		String esn = "T4860034";
		String psKey = "E6K58hHWL4WIFgARcVDIQQ==";
		String mqttPsw = "PvX72hsnYtCPmvLbHonC6w==";*/
		
		/*String esn = "H1000005";
		String psKey = "kZ8MQD1d8Iqm2biTUhFprN==";
		String mqttPsw = "81g5fgGunBi1kWiLjkqdyQ==";*/
		
		String esn = "T4CF0052";
		String psKey = "ofpKs1sE0Ye172EKLNkEcw==";
		String mqttPsw = "CPI5gJdy1T7KL394tK+bhg==";
		
		/*String esn = "T4860029";
		String psKey = "h7Qx9UVgF2jPJJPSLKIpKg==";
		String mqttPsw = "XMd/kVB9SQaxG/MC8o6vSQ==";*/
		
		/*String esn = "T4860025";
		String psKey = "Riduc1Mc4U9vJhZaev36ew==";
		String mqttPsw = "QMM2VareTyJQxKr+RjuyYQ==";*/
		
		/*String esn = "T4CF0028";
		String psKey = "SVyGr0ba1e6Zof7hNF7iQg==";
		String mqttPsw = "XOKK+cZPoWAJoMPjcDJCSw==";*/
		
		//String vin = "5LMCJ2AN0FUJ10556";
		String vin = "5LMCJ2ANXFUJ16493";
		String region = "CN";
		String MQTT_URL = "tcp://fcne0001vehqa.chinacloudapp.cn:1883";//"tcp://Mqa1cnveh.cv.ford.com:1883";//"tcp://mqa1cnveh.cv.ford.com:1883";//
		
		MqttConnectOptions _mqttConnOpt = new MqttConnectOptions();
		_mqttConnOpt.setCleanSession(false);
		_mqttConnOpt.setConnectionTimeout(30);
		_mqttConnOpt.setKeepAliveInterval(30);
		_mqttConnOpt.setUserName(esn);
		_mqttConnOpt.setPassword(mqttPsw.toCharArray());
        
		MqttDefaultFilePersistence dataStore = new MqttDefaultFilePersistence("C:\\temp");
		MqttAsyncClient mqttclient = new MqttAsyncClient(MQTT_URL, vin, dataStore);
		
		IMqttToken mqttConnToken = mqttclient.connect(_mqttConnOpt);
		
		try
		{
			mqttConnToken.waitForCompletion();
			System.out.println("--------------- TCU Simulator connect to MQTT successfully.");
		} // end-try
		catch (MqttException mqttex)
		{
			if (mqttclient != null)
			{
				mqttclient.close();
				mqttclient = null;
			} // end-if
			throw mqttex;
		} // end-catch
		
		mqttclient.setCallback(new MqttCallback() {
			
			@Override
			public void messageArrived(String topicName, MqttMessage msg) throws Exception {
				System.out.println("+++++: " + topicName);
				
				/*byte[] syncpBytes = msg.getPayload();
				
				System.out.println("+++++Payload(HexString): " + StringUtil.bytesToHexString(syncpBytes));
				String esn = SyncpUtil.get_ESN_From_Syncp_Header(syncpBytes);
				String psKeyB64 = FTCPConstants.ESN_PSKEY_MAP.get(esn);
				byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(syncpBytes, psKeyB64);
				System.out.println("+++++Syncpayload(HexString): " + StringUtil.bytesToHexString(decodedBytes));
				
				if (topicName.contains("TCU_COMMAND")) {
					TCUCommand tucCommand = TCUCommand.parseFrom(decodedBytes);
					System.out.println(tucCommand);
				} */
			}
			
			@Override
			public void deliveryComplete(IMqttDeliveryToken arg0) {
				System.out.println("deliveryComplete");
			}
			
			@Override
			public void connectionLost(Throwable arg0) {
				
			}
		});

		String topicAlert = StringUtil.getPublishTopic(region, vin, "TCU_ALERT");
		
		byte[] cmdBytes1 = getHevBatteryFalutAlertByte(esn, vin);//getProvisioningAlert(esn, vin, "", "");//getClearLowTirePressure(esn, vin);//getClearLowTirePressure(esn, vin);//buildTCUConnectionStatusAlert();//buildAlert(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_DATA_MONITOR_VALUE, FTCP3.TCUAlert.AlertType.NON_GENERIC_VALUE);
		byte[] bytesToPublish1 = SyncpUtil.encodeSyncpPacket(cmdBytes1, esn, psKey);
		System.out.println(StringUtil.bytesToHexString(bytesToPublish1));
		mqttclient.publish(topicAlert, new MqttMessage(bytesToPublish1));
		System.out.println(topicAlert);
		
	}
	
	public static byte[] getHevBatteryFalutAlertByte(String esn, String vin) {
		TCUAlert.Builder tcuAlertBuilder = TCUAlert.newBuilder();
		tcuAlertBuilder.setAlertType(TCUAlert.AlertType.NON_GENERIC);
		TCUNonGenericAlert.Builder tcuNonGenericAlertBuilder = TCUNonGenericAlert.newBuilder();
		tcuNonGenericAlertBuilder.setNonGenericAlertName(TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_BATTERY_FAULT);
		HEVBatteryFaultAlert.Builder hevBatteryFaultAlert = HEVBatteryFaultAlert.newBuilder();
		
		hevBatteryFaultAlert.setVehicleCommon(buildVehicleCommon(esn, vin));
		
		hevBatteryFaultAlert.setHevVehicleStatus(buildHEVVehicleStatus());
		
		hevBatteryFaultAlert.setHevBatteryData(buildHEVBatteryData());
// HEVBatteryFaultSeverityEnum.SERVICE 		HEVBatteryFaultSeverityEnum.WARNING
hevBatteryFaultAlert.setHevBatteryFaultSeverityEnum(HEVBatteryFaultSeverityEnum.SERVICE);
		tcuNonGenericAlertBuilder.setHevBatteryFaultAlert(hevBatteryFaultAlert);
		
		tcuAlertBuilder.setNonGenericAlert(tcuNonGenericAlertBuilder);
		TCUAlert tcuAlert = tcuAlertBuilder.build();
		System.out.println(tcuAlert);
		byte alertBytes[] = tcuAlert.toByteArray();
		StringBuilder sb = new StringBuilder();
		for (byte by : alertBytes) 
		{
	        sb.append(String.format("%02X ", by));
	    }
		return tcuAlert.toByteArray();
	}
	
	private static UTCDateTime.Builder buildUTCDateTime(UTCDateTime.Builder utcDateTimeBuilder){
		
		GregorianCalendar date = new GregorianCalendar();
		utcDateTimeBuilder/*.setGpsUtcYrNoActl*/.setUTCYear(date.get(Calendar.YEAR));
		utcDateTimeBuilder/*.setGpsUtcMnthNoActl*/.setUTCMonth(date.get(Calendar.MONTH));
		utcDateTimeBuilder/*.setGpsUtcDayNoActl*/.setUTCDay(date.get(Calendar.DAY_OF_MONTH));
		utcDateTimeBuilder/*.setGPSUTCHours*/.setUTCHour(date.get(Calendar.HOUR));
		utcDateTimeBuilder/*.setGPSUTCMinutes*/.setUTCMin(date.get(Calendar.MINUTE));
		utcDateTimeBuilder/*.setGPSUTCSeconds*/.setUTCSecond(date.get(Calendar.SECOND));
		
		return utcDateTimeBuilder;
	}
	
	public static CommonFromVehicle.Builder buildVehicleCommon(String esn, String vin)
	{
		UTCDateTime.Builder utcDateTimeBuilder = UTCDateTime.newBuilder();
		CommonFromVehicle.Builder commonFromVehicleBuilder = CommonFromVehicle.newBuilder();
		
		commonFromVehicleBuilder.setModemUTCDateTime(buildUTCDateTime(utcDateTimeBuilder));
		commonFromVehicleBuilder.setVin(vin);
		commonFromVehicleBuilder.setEsn(esn);
		commonFromVehicleBuilder.setIccid("89860114623100287757");
		/*commonFromVehicleBuilder.setHardwarePartNumber("FA1T-14G145-AA");
		commonFromVehicleBuilder.setFirmwareVersion("1.2.4");
		commonFromVehicleBuilder.setAssemblyPartNumber("FA1T-14G087-AC");
		commonFromVehicleBuilder.setStrategyPartNumber("FA1T-14G139-BA");
		commonFromVehicleBuilder.setGlobalConfigVersion("2.1.9.m");
		commonFromVehicleBuilder.setConfigPartNumber("FA1T-14G144-BA");*/
		commonFromVehicleBuilder.setTcuMessageId(1431656473);
		commonFromVehicleBuilder.setCorrelationId(0);
		commonFromVehicleBuilder.setAuthStatus(AuthStatusEnum.AUTHORIZED);
		commonFromVehicleBuilder.setProtofileVersion("3.0.4");
		
		commonFromVehicleBuilder.setInCarHecTime(HECDateTime.getDefaultInstance());
		
		return commonFromVehicleBuilder;
	}

	public static HEVBatteryData.Builder buildHEVBatteryData() {
		HEVBatteryData.Builder builder = HEVBatteryData.newBuilder();
		// HEV Data
		//CEVT04_BATTTRAC_U_ACTL_R
		builder.setBattTracUActl(0);//voltage
		//CEVT04_BATTTRAC_I_ACTL_R
		builder.setBattTracIActl(0);//current
		//CEVT04_BATTTRACSOC2_PC_ACTL_R
		builder.setBattTracSoc2PcActl(1000);// SOC
		//CEVT04_BATTTRAC_TE_ACTL_R
		builder.setBattTracTeActl(1022);//temperature
		//CEVT04_VEHSTRTINHBT_B_RQBATT_R
		builder.setVehStrtInhbtBRqBatt(str2Int("0x0"));// inhibit
		//CEVT04_BATTTRACOFF_B_ACTL_R
		builder.setBattTracOffBActl(str2Int("0x3"));//shutdown or about to shutdown
		//CEVT04_BATTTRAC_PW_LIMCHRG_R
		builder.setBattTracPwLimChrg(0);
		//CEVT04_BATTTRAC_PW_LIMDCHRG_R
		builder.setBattTracPwLimDchrg(1500);
		//CEVT04_BATTTRACOFFFST_D_ACTL_R
		builder.setBattTracOffFstDActl(str2Int("0x5"));
	
		return builder;
	}
	
	public static int str2Int(String str) {
		int tenCode = 0;
		
		if (str.toLowerCase().contains("0x")) {
			tenCode = Integer.parseInt(str.toLowerCase().replace("0x", ""),16);
		} else {
			tenCode = Integer.parseInt(str);
		}
		
		return tenCode;
	}
	
	public static VehicleStatus.Builder buildHEVVehicleStatus()
	{
		VehicleStatus.Builder vehicleStatus = VehicleStatus.newBuilder();
		//VehicleStatus.Veh_LockStatus
		vehicleStatus.setVehLockStatus(str2Int("0x3"));
		//VehicleStatus.PwPckTqDStat
		vehicleStatus.setPwPckTqDStat(str2Int("0x0"));
		//VehicleStatus.BattULoUActl
		vehicleStatus.setBattULoUActl(1);
		//VehicleStatus.TirepresssystemStat
		vehicleStatus.setTirePressSystemStat(0);
		//VehicleStatus.GearLvrPosDActl
		vehicleStatus.setGearLvrPosDActl(str2Int("0x0"));
		//VehicleStatus.IgnitionStatus
		vehicleStatus.setIgnitionStatus(str2Int("0x8"));
		//VehicleStatus.PerimeterAlarmStatus
		vehicleStatus.setPerimeterAlarmStatus(0);
		//VehicleStatus.PrmtrAlrmEvntDStat
		vehicleStatus.setPrmtrAlrmEvntDStat(0);
		//VehicleStatus.FuelLvlPcDsply
		vehicleStatus.setFuelLvlPcDsply(10000);// x*0.1-5.217
		//VehicleStatus.EngOilLifePcActl
		vehicleStatus.setEngOilLifePcActl(0);
		//VehicleStatus.VehVActlEng
		vehicleStatus.setVehVActlEng(100000);
		//VehicleStatus.FuelRangeLDsply
		vehicleStatus.setFuelRangeLDsply(0);
		//VehicleStatus.OdometerMasterValue
		vehicleStatus.setOdometerMasterValue(167772151);
		//VehicleStatus.BattTracSocPcDsply
		vehicleStatus.setBattTracSocPcDsply(0);
		//VehicleStatus.PtRmtRprtDRq
		vehicleStatus.setPtRmtRprtDRq(0);
		//VehicleStatus.PlgActvArbBActl
		vehicleStatus.setPlgActvArbBActl(0);
		//VehicleStatus.BattElecPerfDActl
		vehicleStatus.setBattElecPerfDActl(0);
		//VehicleStatus.TripSumEDsply
		vehicleStatus.setTripSumEDsply(0);
		//VehicleStatus.TripSumVlDsply
		vehicleStatus.setTripSumVlDsply(0);
		//VehicleStatus.TripSumLDsply
		vehicleStatus.setTripSumLDsply(0);
		//VehicleStatus.ActChrgStrtYrNoActl
		vehicleStatus.setActChrgStrtYrNoActl(0);
		//VehicleStatus.ActChrgStrMnthNoActl
		vehicleStatus.setActChrgStrMnthNoActl(0);
		//VehicleStatus.ActChrgStrtDayNoActl
		vehicleStatus.setActChrgStrtDayNoActl(0);
		//VehicleStatus.ActChrgStrtHrNoActl
		vehicleStatus.setActChrgStrtHrNoActl(0);
		//VehicleStatus.ActChrgStrtMinNoActl
		vehicleStatus.setActChrgStrtMinNoActl(0);
		//VehicleStatus.ActChrgEndYrNoActl
		vehicleStatus.setActChrgEndYrNoActl(0);
		//VehicleStatus.ActChrgEndMnthNoActl
		vehicleStatus.setActChrgEndMnthNoActl(0);
		//VehicleStatus.ActChrgEndDayNoActl
		vehicleStatus.setActChrgEndDayNoActl(0);
		//VehicleStatus.ActChrgEndHrNoActl
		vehicleStatus.setActChrgEndHrNoActl(0);
		//ActChrgEndMinNoActl
		vehicleStatus.setActChrgEndMinNoActl(0);
		//VehicleStatus.ChrgLocIDNoRq
		vehicleStatus.setChrgLocIDNoRq(0);
		//VehicleStatus.ChargeNowDurationSt
		vehicleStatus.setChargeNowDurationSt(0);
		//VehicleStatus.receivedSignalQuality
		vehicleStatus.setReceivedSignalQuality(0);
		//VehicleStatus.GSMDRXLevel
		vehicleStatus.setGSMDRXLevel(0);
		//VehicleStatus.GSMRoamingFlag
		vehicleStatus.setGSMRoamingFlag(0);
		//VehicleStatus.GSMNumberOfNeighbors
		vehicleStatus.setGSMNumberOfNeighbors(0);
		//VehicleStatus.RgenLongTermPcDsply
		vehicleStatus.setRgenLongTermPcDsply(0);
		//VehicleStatus.RgenTripPcDsply
		vehicleStatus.setRgenTripPcDsply(0);
		//VehicleStatus.RgenTripLDsply
		vehicleStatus.setRgenTripLDsply(0);
		//VehicleStatus.RgenLongTermLDsply
		vehicleStatus.setRgenLongTermLDsply(0);
		//VehicleStatus.ConsTipANoDsply
		vehicleStatus.setConsTipANoDsply(0);
		//VehicleStatus.ConsTipVNoDsply
		vehicleStatus.setConsTipVNoDsply(0);
		//VehicleStatus.ConsTipDecelNoDsply
		vehicleStatus.setConsTipDecelNoDsply(0);
		//VehicleStatus.ConsTipUnitPtDDsply
		vehicleStatus.setConsTipUnitPtDDsply(0);
		//VehicleStatus.ConsTipTotPcDsply
		vehicleStatus.setConsTipTotPcDsply(0);
		//VehicleStatus.ConsAvgTripNoDsply
		vehicleStatus.setConsAvgTripNoDsply(0);
		//VehicleStatus.ConsUnitIPCDDsply
		vehicleStatus.setConsUnitIPCDDsply(0);
		//VehicleStatus.ConsLongTermNoDsply
		vehicleStatus.setConsLongTermNoDsply(0);
		//VehicleStatus.EngSrvcRqdBRq
		vehicleStatus.setEngSrvcRqdBRq(str2Int("0x5"));
		//VehicleStatus.HtrnSrvcRqdBDsply
		vehicleStatus.setHtrnSrvcRqdBDsply(0);
		//VehicleStatus.HtrnWarnLampBDsply
		vehicleStatus.setHtrnWarnLampBDsply(0);
		//VehicleStatus.PtSrvcLampBRqHtrn
		vehicleStatus.setPtSrvcLampBRqHtrn(0);
		//VehicleStatus.PtWarnLampBRqHtrn
		vehicleStatus.setPtWarnLampBRqHtrn(0);
		//VehicleStatus.BattTracSrvcRqdBRq
		vehicleStatus.setBattTracSrvcRqdBRq(0);
		//VehicleStatus.BattTracWarnLampBRq
		vehicleStatus.setBattTracWarnLampBRq(3);
		//VehicleStatus.ChrgrSrvcRqdBRq
		vehicleStatus.setChrgrSrvcRqdBRq(0);
		//VehicleStatus.TrnSrvcRqdBRq
		vehicleStatus.setTrnSrvcRqdBRq(0);
		//VehicleStatus.TrnWarnLampBDsply
		vehicleStatus.setTrnWarnLampBDsply(0);
		//VehicleStatus.ElTripLDsply
		vehicleStatus.setElTripLDsply(0);
		//VehicleStatus.ElLongTermLDsply
		vehicleStatus.setElLongTermLDsply(0);
		//VehicleStatus.ConsAvgTripFeDsply
		vehicleStatus.setConsAvgTripFeDsply(0);
		//VehicleStatus.receivedSignalStrength
		vehicleStatus.setReceivedSignalStrength(0);
		//VehicleStatus.HybMdeStatDDsply
		vehicleStatus.setHybMdeStatDDsply(0);
		//VehicleStatus.VehElRngeLDsply
		vehicleStatus.setVehElRngeLDsply(0);
		//VehicleStatus.PreCondStatDDsply
		vehicleStatus.setPreCondStatDDsply(0);
		//VehicleStatus.CabnAmbTeActl
		vehicleStatus.setCabnAmbTeActl(0);
		//VehicleStatus.ChrgrInPwTypeDActl
		vehicleStatus.setChrgrInPwTypeDActl(0);
		//VehicleStatus.ChrgStatDDsply
		vehicleStatus.setChrgStatDDsply(0);
		//VehicleStatus.BattChrgTrgSocPtTEst
		vehicleStatus.setBattChrgTrgSocPtTEst(0);
		//VehicleStatus.BattChrgCmpltPtTEst
		vehicleStatus.setBattChrgCmpltPtTEst(0);
		//VehicleStatus.PlgActvDActlChrgr
		vehicleStatus.setPlgActvDActlChrgr(0);
		//VehicleStatus.ChrgrInPwMx
		vehicleStatus.setChrgrInPwMx(0);
		//VehicleStatus.AirAmbTeActlFilt
		vehicleStatus.setAirAmbTeActlFilt(1000);
		//VehicleStatus.LifeCycMdeDActl
		vehicleStatus.setLifeCycMdeDActl(0);
		//VehicleStatus.Prkbrkstatus
		vehicleStatus.setPrkbrkstatus(0);
		//VehicleStatus.PrkBrkActvBActl
		vehicleStatus.setPrkBrkActvBActl(0);
		//VehicleStatus.parkrbrakehard
		vehicleStatus.setParkrbrakeHard(0);
		//VehicleStatus.parkbrakesoft
		vehicleStatus.setParkbrakeSoft(0);
		//VehicleStatus.ApedPosPcActlArb
		vehicleStatus.setApedPosPcActlArb(0);
		//VehicleStatus.EngAoutNActl
		vehicleStatus.setEngAoutNActl(0);
		//VehicleStatus.EngClntTeActl
		vehicleStatus.setEngClntTeActl(0);
		//VehicleStatus.PrplWhlTot2TqActl
		vehicleStatus.setPrplWhlTot2TqActl(str2Int("0XFFFF"));
		//VehicleStatus.BSBattSOC
		vehicleStatus.setBSBattSOC(0);
		//VehicleStatus.BpedDrvApplDActl
		vehicleStatus.setBpedDrvApplDActl(BpedDrvApplENUM.DRIVER_BRAKING);

//******************GPS********************

		GPSInfo.Builder gpsbldr = GPSInfo.newBuilder();
		ShiftedGPSInfo.Builder shiftedGPSInfo = ShiftedGPSInfo.newBuilder();
//度-整数
shiftedGPSInfo.setLatitidueDegreesInteger(29);
shiftedGPSInfo.setLatitudeSign(0);
//度-小数
shiftedGPSInfo.setLatitudeDegreesFractional(881999);

//度-整数
shiftedGPSInfo.setLongitudeDegreesInteger(119);
shiftedGPSInfo.setLongitudeSign(0);
//度-小数
shiftedGPSInfo.setLongitudeDegreesFractional(781239);

//	CEVP01_GPSUTCYR_NO_ACTL_R - ShiftedGPSInfo.utcYear
shiftedGPSInfo.setUtcYear(2015);
//	CEVP01_GPSUTCMNTH_NO_ACTL_R - ShiftedGPSInfo.utcMonth
shiftedGPSInfo.setUtcMonth(2);
//	CEVP01_GPSUTCDAY_NO_ACTL_R - ShiftedGPSInfo.utcTimeDay
shiftedGPSInfo.setUtcTimeDay(2);
//	CEVP01_GPS_UTC_HOURS_R - ShiftedGPSInfo.utcTimeHours
shiftedGPSInfo.setUtcTimeHours(1);
//	CEVP01_GPS_UTC_MINUTES_R - ShiftedGPSInfo.utcTimeMinutes
shiftedGPSInfo.setUtcTimeMinutes(1);
//	CEVP01_GPS_UTC_SECONDS_R - ShiftedGPSInfo.utcTimeSeconds
shiftedGPSInfo.setUtcTimeSeconds(1);

//	CEVP01_GPS_COMPASS_DIRECTION_X - ShiftedGPSInfo.compassDirection
//shiftedGPSInfo.setCompassDirection(str2Int("0x0"));
//	CEVP01_GPS_MSL_ALTITUDE_R - ShiftedGPSInfo.meanSeaLevelAltitude
//shiftedGPSInfo.setMeanSeaLevelAltitude(1);
//	CEVP01_GPSHSPHLONGEST_D_ACTL_X - 
//	CEVP01_GPSHSPHLATTSTH_D_ACTL_X -

//	CEVP01_GPS_B_FALT_F - ShiftedGPSInfo.faultBitMask
shiftedGPSInfo.setFaultBitMask(0);
//	CEVP01_GPS_HEADING_R - ShiftedGPSInfo.heading
shiftedGPSInfo.setHeading(0);
//	CEVP01_GPS_VELOCITY_R - ShiftedGPSInfo.velocity
shiftedGPSInfo.setVelocity(2650);
//	CEVP01_GPS_ACT_VS_INFER_POS_X - 
//	CEVP01_GPS_DIMENSION_X - 
//	CEVP01_INCLUDELATLONGENUM_X - 



		gpsbldr.setShiftedGPSInfo(shiftedGPSInfo);
		
		/*UnshiftedGPSInfo.Builder unshiftedGPSInfo = UnshiftedGPSInfo.newBuilder();
		//CEVP01_GPS_COMPASS_DIRECTION_X - unshiftedGPSInfo.compassDirection
		unshiftedGPSInfo.setGPSCompassDirection(str2Int("0x2"));
		//CEVP01_GPS_MSL_ALTITUDE_R - unshiftedGPSInfo.meanSeaLevelAltitude
		unshiftedGPSInfo.setGPSMSLAltitude(10);
		
		//CEVP01_GPSHSPHLONGEST_D_ACTL_X - unshiftedGPSInfo.setGpsHsphLongEastDActl(0);
		//CEVP01_GPSHSPHLATTSTH_D_ACTL_X - unshiftedGPSInfo.setGpsHsphLattSthDActl(0);
		unshiftedGPSInfo.setGpsHsphLongEastDActl(0);
		unshiftedGPSInfo.setGpsHsphLattSthDActl(0);
		//CEVP01_GPS_B_FALT_F - ShiftedGPSInfo.faultBitMask
		unshiftedGPSInfo.setGpsBFalt(0);
		//CEVP01_GPS_HEADING_R - ShiftedGPSInfo.heading
		unshiftedGPSInfo.setGPSHeading(65534);
		//no in unshifted GPS -----CEVP01_GPS_VELOCITY_R - ShiftedGPSInfo.velocity
		
		//CEVP01_GPS_ACT_VS_INFER_POS_X - 
		unshiftedGPSInfo.setGPSActualVsInferPos(str2Int("0x3"));
		//CEVP01_GPS_DIMENSION_X - 
		unshiftedGPSInfo.setGPSDimension(4);
		//CEVP01_INCLUDELATLONGENUM_X - 
		unshiftedGPSInfo.setIncludeLatLongEnum(IncludeLatLongENUM.NO);
		
		//UTCDateTimeFromCAN.GPSUTCYR_NO_ACTL_FIELD_NUMBER = 2015;
		UTCDateTimeFromCAN.Builder utcCanDataTime = UTCDateTimeFromCAN.newBuilder();
		utcCanDataTime.setGpsUtcYrNoActl(1);
		utcCanDataTime.setGpsUtcMnthNoActl(1);
		utcCanDataTime.setGpsUtcDayNoActl(1);
		utcCanDataTime.setGPSUTCHours(1);
		utcCanDataTime.setGPSUTCMinutes(1);
		utcCanDataTime.setGPSUTCSeconds(1);
		unshiftedGPSInfo.setCANUTCDateTime(utcCanDataTime);

		gpsbldr.setUnshiftdGPSInfo(unshiftedGPSInfo);*/
		
		vehicleStatus.setGpsInfo(gpsbldr.build());
		return vehicleStatus;
	}
}
