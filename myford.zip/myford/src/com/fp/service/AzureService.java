package com.fp.service;

import java.util.List;

import com.fp.action.tools.AlertEntity;
import com.fp.action.tools.CommandEntity;
import com.fp.action.tools.ResponseEntity;
import com.fp.domain.TcuVehicle;

public interface AzureService {
	public abstract List<AlertEntity> getAzureAlerts(String esn, String accountName, String accountKey);
	public abstract List<ResponseEntity> getAzureResponses(String esn, String accountName, String accountKey);
	public abstract List<CommandEntity> getAzureCommands(String esn, String dbaddress, String dbname, String account, String psw);
	public abstract List<TcuVehicle> getAllEsns(String username);
}
