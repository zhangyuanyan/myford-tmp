package com.fp.service.impl;

import java.util.List;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ford.ftcp.FTCP3;
import com.ford.ftcp.FTCP3.AuthStatusEnum;
import com.ford.ftcp.FTCP3.TCUCommand;
import com.ford.ftcp.util.FTCPConstants;
import com.ford.ftcp.util.StringUtil;
import com.ford.ftcp.util.SyncpUtil;
import com.ford.ftcp.util.creative.AlertCreativeMock;
import com.ford.ftcp.util.creative.CommandResponseCreativeMock;
import com.fp.dao.VehicleDao;
import com.fp.domain.BatteryFault;
import com.fp.domain.TcuVehicle;
import com.fp.domain.VehicleBean;
import com.fp.service.TCUMqttService;
import com.fp.util.Constants;
import com.google.protobuf.InvalidProtocolBufferException;

@Service
@Transactional
public class TCUMqttServiceImpl implements TCUMqttService {

	public MqttAsyncClient getMQTTClient(String mqttUname, String mqttPsw, String vin) throws MqttException, InvalidProtocolBufferException {
		MqttConnectOptions _mqttConnOpt = new MqttConnectOptions();
		_mqttConnOpt.setCleanSession(false);
		_mqttConnOpt.setConnectionTimeout(30);
		_mqttConnOpt.setKeepAliveInterval(30);
		_mqttConnOpt.setUserName(mqttUname);//(Constants.TCU_USE_MQTT_USERNAME);
		_mqttConnOpt.setPassword(mqttPsw.toCharArray());//(Constants.TCU_USE_MQTT_PASSWORD.toCharArray());
		
		MqttDefaultFilePersistence dataStore = new MqttDefaultFilePersistence("C:\\temp");
		MqttAsyncClient mqttclient = new MqttAsyncClient(Constants.TCU_USE_MQTT_URL, vin, dataStore);
		//mqttclient.getClientId()
		IMqttToken mqttConnToken = mqttclient.connect(_mqttConnOpt);
		
		try
		{
			mqttConnToken.waitForCompletion();
			System.out.println("Connect to MQTT successfully. " + Constants.TCU_USE_MQTT_URL);
		} // end-try
		catch (MqttException mqttex)
		{
			if (mqttclient != null)
			{
				mqttclient.close();
				mqttclient = null;
			} // end-if
			throw mqttex;
		} // end-catch
		return mqttclient;
	}
	
	private MqttAsyncClient mqttclient;
	
	@Override
	public void initMQTT() {
//		connectMQTT();
//		subcribeTopics();
	}
	
	private void connectMQTT(String mqttUname, String mqttPsw, String vin) {
		try {
			
			mqttclient = getMQTTClient(mqttUname, mqttPsw, vin);
			mqttclient.setCallback(new MqttCallback() {
				
				@Override
				public void messageArrived(String topicName, MqttMessage msg) throws Exception {
					System.out.println("+++++ȡ��������: " + topicName);
					
					byte[] syncpBytes = msg.getPayload();
					
					System.out.println("+++++ȡ����Payload(HexString): " + StringUtil.bytesToHexString(syncpBytes));
					String esn = SyncpUtil.get_ESN_From_Syncp_Header(syncpBytes);
					String psKeyB64 = dao.findTcuVehicleByEsn(esn).getPsKey();//Constants.ESN_PSKEY_MAP.get(esn);
					byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(syncpBytes, psKeyB64);
					System.out.println("+++++Syncp�������Payload(HexString): " + StringUtil.bytesToHexString(decodedBytes));
					
					if (topicName.contains("TCU_COMMAND")) {
						String vin = topicName.split("/")[2];
						TCUCommand tucCommand = TCUCommand.parseFrom(decodedBytes);
						System.out.println(tucCommand);
						
						System.out.println("Start publish command response(TCU).");
						publishCommandResponse(tucCommand, vin, esn);
						
					} 
				}
				
				@Override
				public void deliveryComplete(IMqttDeliveryToken arg0) {
					System.out.println("TCU deliveryComplete");
					
					/*new Thread(new Runnable() {
						@Override
						public void run() {
							try {
								mqttclient.disconnect();
								
							} catch (MqttException e) {
								e.printStackTrace();
							}
						}
					}).start();*/
				}
				
				@Override
				public void connectionLost(Throwable arg0) {
					System.out.println("TCU connectionLost");
					/*while(!mqttclient.isConnected()) {
						initMQTT();
					}
					
					System.out.println("isConnected: " + mqttclient.isConnected());*/
				}
			});
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void publishCommandResponse(TCUCommand tucCommand, String vin, String esn) throws Exception {
		
		if (tucCommand.getNonTimeSensitiveCommand().getNonTimeSensitiveCommandName() == FTCP3.NonTimeSensitiveCommandNameEnum.VEHICLE_DIAGNOSTIC_DATA_REQUEST)  {
			int cloundMsgId = tucCommand.getNonTimeSensitiveCommand().getVehicleDiagnosticDataRequestCommand().getCloudCommon().getCloudMessageId();
			CommandResponseCreativeMock mock = new CommandResponseCreativeMock(esn, vin, cloundMsgId);
			byte[] cmdRespBytes = mock.buildCommandResponse();
			
			byte[] bytesToPublish = SyncpUtil.encodeSyncpPacket(cmdRespBytes, esn, FTCPConstants.ESN_PSKEY_MAP.get(esn));
			System.out.println(StringUtil.bytesToHexString(bytesToPublish));
			System.out.println("mqttclient.isConnected()=" + mqttclient.isConnected());
			
			String topic = StringUtil.getPublishTopic(FTCPConstants.region, vin, "COMMAND_RESPONSE");
			mqttclient.publish(topic, new MqttMessage(bytesToPublish));
			
			System.out.println("Start publish Diagnostic Response Alert after command response(TCU).");
			publishDiagnosticResponsedAlert(vin, esn, cloundMsgId);
		}
	}
	
	private void subcribeTopics() {
		try {
			for(String vin : FTCPConstants.vins) {
				List<String> needToSubList = StringUtil.createTCUSubcribeTopics(FTCPConstants.region, vin);
				
				for(String topic : needToSubList) {
					mqttclient.subscribe(topic, 2);
					System.out.println("Subcribe to topic: " + topic);
				} 
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void publishDiagnosticResponsedAlert(String vin, String esn, int cloundMsgId) throws Exception {
		/*String topic = StringUtil.getPublishTopic(FTCPConstants.region, vin, "TCU_ALERT");
		System.out.println(topic);
		AlertCreativeMock creative = new AlertCreativeMock(esn, vin, cloundMsgId);
		byte[] cmdBytes = creative.buildAlert(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.VEHICLE_DIAGNOSTIC_DATA_RESPONSE_VALUE, FTCP3.TCUAlert.AlertType.NON_GENERIC_VALUE);
		
		byte[] bytesToPublish = SyncpUtil.encodeSyncpPacket(cmdBytes, esn, FTCPConstants.ESN_PSKEY_MAP.get(esn));
		System.out.println(StringUtil.bytesToHexString(bytesToPublish));
		mqttclient.publish(topic, new MqttMessage(bytesToPublish));*/
	}
	
	@Autowired
	private VehicleDao dao;
	public VehicleDao getDao() {
		return dao;
	}

	public void setDao(VehicleDao dao) {
		this.dao = dao;
	}

	@Override
	public void publishTcuDataMonitorAlert(String vin, String esn, VehicleBean vehicleBean) throws Exception {
		TcuVehicle tv = dao.findTcuVehicleByEsn(esn);
		tv.setVin(vin);
		tv.setAuthStatus(AuthStatusEnum.WAITING_FOR_AUTH);
		connectMQTT(esn, tv.getMqttpsw(), vin);
		String topic = StringUtil.getPublishTopic(FTCPConstants.region, vin, "TCU_ALERT");
		System.out.println(topic);
		AlertCreativeMock creative = new AlertCreativeMock(tv);
		creative.setHevVehicleBean(vehicleBean);
		
		byte[] cmdBytes = creative.buildAlert(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_DATA_MONITOR_VALUE, FTCP3.TCUAlert.AlertType.NON_GENERIC_VALUE);
		System.out.println("*************cmdBytes: " + cmdBytes.length);
		
		byte[] bytesToPublish = SyncpUtil.encodeSyncpPacket(cmdBytes, esn, tv.getPsKey());
		System.out.println("*************bytesToPublish: " + bytesToPublish.length);
		System.out.println(StringUtil.bytesToHexString(bytesToPublish));
		IMqttDeliveryToken token = mqttclient.publish(topic, new MqttMessage(bytesToPublish));
		
		token.waitForCompletion();
		mqttclient.disconnect();
	}
	
	public static void main(String[] args) throws InvalidProtocolBufferException {
		new TCUMqttServiceImpl().initMQTT();
//		String vin = "5LMCJ2A90FUJ00101";
//		String esn = "T4860034";
//		String topic = StringUtil.getPublishTopic(FTCPConstants.region, vin, "TCU_ALERT");
//		System.out.println(topic);
//		AlertCreativeMock creative = new AlertCreativeMock(esn, vin, 0);
//		
//		byte[] cmdBytes = creative.buildAlert(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_DATA_MONITOR_VALUE, FTCP3.TCUAlert.AlertType.NON_GENERIC_VALUE);
//		System.out.println("*************cmdBytes: " + cmdBytes.length);
//		System.out.println(StringUtil.bytesToHexString(cmdBytes));
//		byte[] bytesToPublish = SyncpUtil.encodeSyncpPacket(cmdBytes, esn, FTCPConstants.ESN_PSKEY_MAP.get(esn));
//		System.out.println("*************bytesToPublish: " + bytesToPublish.length);
//		System.out.println(StringUtil.bytesToHexString(bytesToPublish));
	}
	@Override
	public String publishTcuBatteryFaultAlert(String vin, String esn, BatteryFault batteryFaultBean) throws Exception {
		String topic = StringUtil.getPublishTopic(FTCPConstants.region, vin, "TCU_ALERT");
		System.out.println(topic);
		TcuVehicle tv = dao.findTcuVehicleByEsn(esn);
		tv.setVin(vin);
		tv.setAuthStatus(AuthStatusEnum.WAITING_FOR_AUTH);
		connectMQTT(esn, tv.getMqttpsw(), vin);
		AlertCreativeMock creative = new AlertCreativeMock(tv);
		creative.setBatteryFaultBean(batteryFaultBean);
		byte[] cmdBytes = creative.buildAlert(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.HEV_BATTERY_FAULT_VALUE, FTCP3.TCUAlert.AlertType.NON_GENERIC_VALUE);
		
		byte[] bytesToPublish = SyncpUtil.encodeSyncpPacket(cmdBytes, esn, tv.getPsKey());
		System.out.println(StringUtil.bytesToHexString(bytesToPublish));
		IMqttDeliveryToken token = mqttclient.publish(topic, new MqttMessage(bytesToPublish));
		token.waitForCompletion();
		if (token.isComplete()) {
			mqttclient.disconnect();
			return "delivery to MQTT success, payload: " +  StringUtil.bytesToHexString(bytesToPublish);
		}
		return "";
	}
	
	@Override
	public String publishClearBatteryFaultAlert(String vin, String esn, BatteryFault batteryFaultBean) throws Exception {
		String topic = StringUtil.getPublishTopic(FTCPConstants.region, vin, "TCU_ALERT");
		System.out.println(topic);
		TcuVehicle tv = dao.findTcuVehicleByEsn(esn);
		tv.setVin(vin);
		tv.setAuthStatus(AuthStatusEnum.WAITING_FOR_AUTH);
		connectMQTT(esn, tv.getMqttpsw(), vin);
		AlertCreativeMock creative = new AlertCreativeMock(tv);
		creative.setBatteryFaultBean(batteryFaultBean);
		byte[] cmdBytes = creative.buildAlert(FTCP3.TCUGenericAlert.GenericAlertNameEnum.CLEAR_HEV_BATTERY_FAULT_VALUE, FTCP3.TCUAlert.AlertType.GENERIC_VALUE);
		
		byte[] bytesToPublish = SyncpUtil.encodeSyncpPacket(cmdBytes, esn, tv.getPsKey());
		System.out.println(StringUtil.bytesToHexString(bytesToPublish));
		IMqttDeliveryToken token = mqttclient.publish(topic, new MqttMessage(bytesToPublish));
		token.waitForCompletion();
		if (token.isComplete()) {
			return "delivery to MQTT success, payload: " +  StringUtil.bytesToHexString(bytesToPublish);
		}
		return "";
	}
	
	public void publishConnectionAlert(String vin, String esn) throws Exception {
		String topic = StringUtil.getPublishTopic(FTCPConstants.region, vin, "TCU_CONNECTION_STATUS_ALERT");
		System.out.println(topic);
		
		TcuVehicle tv = dao.findTcuVehicleByEsn(esn);
		tv.setVin(vin);
		tv.setAuthStatus(AuthStatusEnum.WAITING_FOR_AUTH);
		connectMQTT(esn, tv.getMqttpsw(), vin);
		
		AlertCreativeMock creative = new AlertCreativeMock(tv);
		byte[] cmdBytes = creative.buildTCUConnectionStatusAlert();
		byte[] bytesToPublish = SyncpUtil.encodeSyncpPacket(cmdBytes, esn, tv.getPsKey());
		System.out.println(StringUtil.bytesToHexString(bytesToPublish));
		IMqttDeliveryToken token = mqttclient.publish(topic, new MqttMessage(bytesToPublish));
		
		token.waitForCompletion();
		mqttclient.disconnect();
	}
	
	@Override
	public String publishProvisioningALert(String vin, String esn) throws Exception {
		String topic = StringUtil.getPublishTopic(FTCPConstants.region, vin, "TCU_ALERT");
		System.out.println(topic);
		TcuVehicle tv = dao.findTcuVehicleByEsn(esn);
		tv.setVin(vin);
		tv.setAuthStatus(AuthStatusEnum.WAITING_FOR_PROVISIONING_ACK);
		connectMQTT(esn, tv.getMqttpsw(), vin);
		AlertCreativeMock creative = new AlertCreativeMock(tv);
		byte[] cmdBytes = creative.buildAlert(FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum.PROVISIONING_VALUE, FTCP3.TCUAlert.AlertType.NON_GENERIC_VALUE);
		
		byte[] bytesToPublish = SyncpUtil.encodeSyncpPacket(cmdBytes, esn, tv.getPsKey());
		System.out.println(StringUtil.bytesToHexString(bytesToPublish));
		IMqttDeliveryToken token = mqttclient.publish(topic, new MqttMessage(bytesToPublish));
		
		token.waitForCompletion();
		if (token.isComplete()) {
			mqttclient.disconnect();
			return "delivery to MQTT success, payload: " + StringUtil.bytesToHexString(bytesToPublish);
		}
		return "";
	}
	
	public boolean isExistsUser(String name, String password) {
		boolean retFlg = false;
		List<TcuVehicle> tvs = dao.findTcuVehicleByNamePassword(name, password);
		if (null != tvs && tvs.size()>0) {
			retFlg = true;
		}
		
		return retFlg;
	}
}
