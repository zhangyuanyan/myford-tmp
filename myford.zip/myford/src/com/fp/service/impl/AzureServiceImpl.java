package com.fp.service.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ford.ftcp.FTCP3.TCUAlert;
import com.ford.ftcp.FTCP3.TCUCommand;
import com.ford.ftcp.FTCP3.TCUCommandResponse;
import com.ford.ftcp.FTCP3.TCUConnectionStatusAlert;
import com.ford.ftcp.util.SyncpUtil;
import com.fp.action.tools.AlertEntity;
import com.fp.action.tools.CommandEntity;
import com.fp.action.tools.ResponseEntity;
import com.fp.dao.VehicleDao;
import com.fp.domain.TcuVehicle;
import com.fp.service.AzureService;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.table.CloudTable;
import com.microsoft.azure.storage.table.CloudTableClient;
import com.microsoft.azure.storage.table.TableQuery;
import com.microsoft.azure.storage.table.TableQuery.Operators;
import com.microsoft.azure.storage.table.TableQuery.QueryComparisons;

@Service
@Transactional
public class AzureServiceImpl implements AzureService {
	Logger logger = Logger.getLogger(AzureServiceImpl.class.getName());
	public final static String PARTITION_KEY = "PartitionKey";
	public final static String ROW_KEY = "RowKey";
	public final static String RECEIVED = "Received";
	public final static String FROM = "From";

	@Autowired
	private VehicleDao dao;

	public VehicleDao getDao() {
		return dao;
	}

	public void setDao(VehicleDao dao) {
		this.dao = dao;
	}

	@Override
	public List<AlertEntity> getAzureAlerts(String esn, String accountName,
			String accountKey) {
		List<AlertEntity> retList = new ArrayList<AlertEntity>();
		try {
			// String storageConnectionString =
			// "DefaultEndpointsProtocol=http;" +
			// "TableEndpoint=http://fcnetlm1qa.table.core.chinacloudapi.cn;" +
			// "AccountName=fcnetlm1qa;" +
			// "AccountKey=LYHVkO2Qy+Qq3eUCnVlSdPSIK3p0iIeMgH9HkttSSqgblarvhEyx80gi7WVvV481CEGDUOXLwdxX3yUaPfT67g==";
			
			String storageConnectionString = "DefaultEndpointsProtocol=http;"
					+ "TableEndpoint=http://" + accountName
					+ ".table.core.chinacloudapi.cn;" + "AccountName="
					+ accountName + ";" + "AccountKey=" + accountKey;
			// Retrieve storage account from connection-string.
			CloudStorageAccount storageAccount = CloudStorageAccount
					.parse(storageConnectionString);

			// Create the table client.
			CloudTableClient tableClient = storageAccount
					.createCloudTableClient();

			// // Loop through the collection of table names.
			// for (String table : tableClient.listTables())
			// {
			// // Output each table name.
			// System.out.println(table);
			// }

			// Create a cloud table object for the table.
			CloudTable cloudTable = tableClient.getTableReference("alert");

			// Create a filter condition where the partition key is "Smith".
			String partitionFilter = TableQuery.generateFilterCondition(FROM,
					QueryComparisons.EQUAL, esn);
//			String receiveDateCondition = TableQuery.generateFilterCondition(RECEIVED, QueryComparisons.GREATER_THAN_OR_EQUAL, new Date(2015 - 1900, 7-1, 28, 0, 0, 0));
			// Specify a partition query, using "Smith" as the partition key
			// filter.
			String combinedFilter = TableQuery.combineFilters(partitionFilter, 
			        Operators.AND, "Received ge datetime'2015-07-27T16:00:00.000Z'");
			
			TableQuery<AlertEntity> partitionQuery = TableQuery.from(
					AlertEntity.class).where(combinedFilter);
			TcuVehicle tv = dao.findTcuVehicleByEsn(esn);
			if (null != tv) {
				// Loop through the results, displaying information about the
				// entity.
				int i = 0;
				for (AlertEntity entity : cloudTable.execute(partitionQuery)) {
					i = i + 1;
					// System.out.println(entity.getPartitionKey() +
					// " " + entity.getRowKey() + " " + entity.getFrom() + " "
					// +entity.getOpcode());
					
					System.out.println(entity.getRowKey());
					
					String hexStr = SyncpUtil
							.bytesToHexString(Base64.decodeBase64(entity
									.getPayload()));
					
					byte[] syncpBytes = SyncpUtil.hexStringToBytes(hexStr);
					String jsonMessage = new String(syncpBytes, "utf-8");
					String messageVal = new JSONObject(jsonMessage).getString("message");
					System.out.println(entity.getEnqueuedTimeUtc() + jsonMessage);
					/*byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(
							SyncpUtil.hexStringToBytes(SyncpUtil.bytesToHexString(Base64.decodeBase64(messageVal))), tv.getPsKey());*/
					byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(Base64.decodeBase64(messageVal), tv.getPsKey());
					if (entity.getOpcode().contains("TCU_ALERT")) {
						if (null != decodedBytes) {
							TCUAlert alert = TCUAlert.parseFrom(decodedBytes);
							
//							com.ford.ftcp.v147.FTCP.TCUAlert alert147 = com.ford.ftcp.v147.FTCP.TCUAlert.parseFrom(decodedBytes);
							// System.out.println(alert);
							entity.setDecodedPayLoad("\n FTCP 3.0.4: " + alert.toString());
						} else {
							entity.setDecodedPayLoad("decode error.");
						}
					} else if (entity.getOpcode().contains(
							"TCU_CONNECTION_STATUS_ALERT")) {
						if (null != decodedBytes) {
							TCUConnectionStatusAlert alert = TCUConnectionStatusAlert
									.parseFrom(decodedBytes);
//							com.ford.ftcp.v147.FTCP.TCUConnectionStatusAlert alert147 
//								= com.ford.ftcp.v147.FTCP.TCUConnectionStatusAlert.parseFrom(decodedBytes);
							// System.out.println(alert);
							entity.setDecodedPayLoad("FTCP 3.0.4:\n"+alert.toString());
						} else {
							entity.setDecodedPayLoad("decode error.");
						}
					}
					retList.add(entity);
				}
			}
		} catch (Exception e) {
			// Output the stack trace.
			e.printStackTrace();
		}
		return retList;
	}

	@Override
	public List<TcuVehicle> getAllEsns(String username) {
		return dao.getAllEsns(username);
	}

	@Override
	public List<ResponseEntity> getAzureResponses(String esn,
			String accountName, String accountKey) {
		List<ResponseEntity> retList = new ArrayList<ResponseEntity>();
		try {
			// String storageConnectionString =
			// "DefaultEndpointsProtocol=http;" +
			// "TableEndpoint=http://fcnetlm1qa.table.core.chinacloudapi.cn;" +
			// "AccountName=fcnetlm1qa;" +
			// "AccountKey=LYHVkO2Qy+Qq3eUCnVlSdPSIK3p0iIeMgH9HkttSSqgblarvhEyx80gi7WVvV481CEGDUOXLwdxX3yUaPfT67g==";
			String storageConnectionString = "DefaultEndpointsProtocol=http;"
					+ "TableEndpoint=http://" + accountName
					+ ".table.core.chinacloudapi.cn;" + "AccountName="
					+ accountName + ";" + "AccountKey=" + accountKey;
			// Retrieve storage account from connection-string.
			CloudStorageAccount storageAccount = CloudStorageAccount
					.parse(storageConnectionString);

			// Create the table client.
			CloudTableClient tableClient = storageAccount
					.createCloudTableClient();

			// // Loop through the collection of table names.
			// for (String table : tableClient.listTables())
			// {
			// // Output each table name.
			// System.out.println(table);
			// }

			// Create a cloud table object for the table.
			CloudTable cloudTable = tableClient.getTableReference("response");

			// Create a filter condition where the partition key is "Smith".
			String partitionFilter = TableQuery.generateFilterCondition(FROM,
					QueryComparisons.EQUAL, esn);

			// Specify a partition query, using "Smith" as the partition key
			// filter.
			TableQuery<ResponseEntity> partitionQuery = TableQuery.from(
					ResponseEntity.class).where(partitionFilter);

			TcuVehicle tv = dao.findTcuVehicleByEsn(esn);
			if (null != tv) {
				// Loop through the results, displaying information about the
				// entity.
				for (ResponseEntity entity : cloudTable.execute(partitionQuery)) {

					// System.out.println(entity.getPartitionKey() +
					// " " + entity.getRowKey() + " " + entity.getFrom() + " "
					// +entity.getOpcode());
					byte[] syncpBytes = SyncpUtil.hexStringToBytes(SyncpUtil
							.bytesToHexString(Base64.decodeBase64(entity
									.getPayload())));

					String jsonMessage = new String(syncpBytes, "utf-8");
					String messageVal = new JSONObject(jsonMessage).getString("message");
					byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(
							SyncpUtil.hexStringToBytes(SyncpUtil.bytesToHexString(Base64.decodeBase64(messageVal))), tv.getPsKey());
					
//					byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(
//							syncpBytes, tv.getPsKey());
					if (entity.getOpcode().contains("COMMAND_RESPONSE")) {
						TCUCommandResponse alert = TCUCommandResponse
								.parseFrom(decodedBytes);
						// System.out.println(alert);
						entity.setDecodedPayLoad(alert.toString());
					}
					retList.add(entity);
				}
			}
		} catch (Exception e) {
			// Output the stack trace.
			e.printStackTrace();
		}
		return retList;
	}

	@Override
	public List<CommandEntity> getAzureCommands(String esn, String dbaddress,
			String dbname, String account, String psw) {

		List<CommandEntity> commands = new ArrayList<CommandEntity>();
		TcuVehicle tv = dao.findTcuVehicleByEsn(esn);
		String connectionString = "jdbc:sqlserver://pjydjzealg.database.chinacloudapi.cn:1433"
				+ ";"
				+ "database=sdn"
				+ ";"
				+ "user=sdnGuest"
				+ ";"
				+ "password=password~1";
		Connection connection = null; // For making the connection
		PreparedStatement pstatement = null; // For the SQL statement
		ResultSet resultSet = null; // For the result set, if applicable

		try {
			// Ensure the SQL Server driver class is available.
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			// Establish the connection.
			connection = DriverManager.getConnection(connectionString);

			// Define the SQL string.
			StringBuffer sb = new StringBuffer();

			sb.append(" select A.CreatedDate, A.LastModifiedDate,DATEDIFF(ss,A.CreatedDate, A.LastModifiedDate) as commandDiff, A.CommandId,A.CloudUtcDateTime,F.ModemUtcDateTime,D.Esn, ");
			sb.append(" G.CommandResponseName,A.CloudMessageId,A.CorrelationId,A.AppCorrelationId,A.Payload, ");
			sb.append(" B.CommandName, ");
			sb.append(" C.CommandStatusName, ");
			sb.append(" D.Vin, D.ActiveFrom, D.ActiveTo, ");
			sb.append(" E.Email, E.LoginName, ");
			sb.append(" F.TcuMessageId,F.CorrelationId, F.InCarHecTime ");
			sb.append(" from Command as A ");
			sb.append(" left join CommandType as B on A.CommandTypeId = B.CommandTypeId ");
			sb.append(" left join CommandStatus as C on A.CommandStatusId = C.CommandStatusId ");
			sb.append(" left join TcuVehicle as D on A.TcuVehicleId = D.TcuVehicleId ");
			sb.append(" left join [User] as E on A.UserId = E.UserID ");
			sb.append(" left join [CommandResponse] as F on A.CommandId = F.CommandId ");
			sb.append(" left join CommandResponseType as G on F.CommandResponseTypeId = G.CommandResponseTypeId ");
			sb.append(" where esn = ? ");
			sb.append(" order by A.CommandId desc ");

			pstatement = connection.prepareStatement(sb.toString());
			pstatement.setString(1, esn);

			resultSet = pstatement.executeQuery();

			while (resultSet.next()) {

				CommandEntity entity = new CommandEntity();
				entity.setCommandId(resultSet.getString("CommandId"));
				entity.setCloudUtcDateTime(resultSet
						.getDate("CloudUtcDateTime"));
				entity.setModemUtcDateTime(resultSet
						.getTimestamp("ModemUtcDateTime"));
				entity.setEsn(resultSet.getString("Esn"));
				entity.setCommandResponseName(resultSet
						.getString("CommandResponseName"));
				entity.setCommandStatusName(resultSet
						.getString("CommandStatusName"));
				entity.setVin(resultSet.getString("Vin"));
				entity.setActiveFrom(resultSet.getDate("ActiveFrom"));
				entity.setActiveTo(resultSet.getDate("ActiveTo"));
				entity.setEmail(resultSet.getString("Email"));
				entity.setLoginName(resultSet.getString("LoginName"));
				entity.setTcuMessageId(resultSet.getString("TcuMessageId"));
				entity.setCorrelationId(resultSet.getString("CorrelationId"));
				entity.setInCarHecTime(resultSet.getDate("InCarHecTime"));
				entity.setPayload(resultSet.getString("Payload"));
				entity.setCommandDiff(resultSet.getInt("commandDiff"));
				entity.setCreatedDate(resultSet.getDate("CreatedDate"));
				entity.setLastModifiedDate(resultSet.getDate("LastModifiedDate"));
				
				byte[] syncpBytes = SyncpUtil.hexStringToBytes(entity
						.getPayload());

				byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(
						syncpBytes, tv.getPsKey());
				TCUCommand tcucommand = TCUCommand.parseFrom(decodedBytes);
				entity.setDecodedPayload(tcucommand.toString());
				commands.add(entity);
			}

		}
		// Exception handling
		catch (ClassNotFoundException cnfe) {

			System.out.println("ClassNotFoundException " + cnfe.getMessage());
		} catch (Exception e) {
			System.out.println("Exception " + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				// Close resources.
				if (null != connection)
					connection.close();
				if (null != pstatement)
					pstatement.close();
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException sqlException) {
				// No additional action if close() statements fail.
			}
		}

		return commands;
	}
}
