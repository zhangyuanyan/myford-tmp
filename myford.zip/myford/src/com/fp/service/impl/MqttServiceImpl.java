package com.fp.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ford.ftcp.FTCP3;
import com.ford.ftcp.FTCP3.CommonFromVehicle;
import com.ford.ftcp.FTCP3.ECUData.DTCInfo;
import com.ford.ftcp.FTCP3.GPSInfo;
import com.ford.ftcp.FTCP3.HEVBatteryData;
import com.ford.ftcp.FTCP3.NonTimeSensitiveCommandNameEnum;
import com.ford.ftcp.FTCP3.TCUAlert;
import com.ford.ftcp.FTCP3.TCUCommandResponse;
import com.ford.ftcp.FTCP3.TCUConnectionStatusAlert;
import com.ford.ftcp.FTCP3.TCUNonGenericAlert.NonGenericAlertNameEnum;
import com.ford.ftcp.FTCP3.UTCDateTime;
import com.ford.ftcp.FTCP3.VehicleStatus;
import com.ford.ftcp.util.FTCPConstants;
import com.ford.ftcp.util.StringUtil;
import com.ford.ftcp.util.SyncpUtil;
import com.ford.ftcp.util.creative.TCUCommandCreativeMock;
import com.fp.dao.VehicleDao;
import com.fp.domain.BFDTCInfo;
import com.fp.domain.BatteryFault;
import com.fp.domain.TcuFtcpRecord;
import com.fp.domain.VehicleBean;
import com.fp.service.MqttService;
import com.fp.util.Constants;
import com.google.protobuf.InvalidProtocolBufferException;

@Service
@Transactional
public class MqttServiceImpl implements MqttService {
	
	@Autowired
	private VehicleDao dao;
	
	public VehicleDao getDao() {
		return dao;
	}
	public void setDao(VehicleDao dao) {
		this.dao = dao;
	}

	private MqttAsyncClient mqttclient;
	
	private void connectMQTT() {
		try {
			mqttclient = getMQTTClient();
			mqttclient.setCallback(new MqttCallback() {

				@Override
				public void connectionLost(Throwable arg0) {
					System.out.println("SDN connectionLost");
					while(!mqttclient.isConnected()) {
						initMQTT();
					}
					
					System.out.println("isConnected: " + mqttclient.isConnected());
				}

				@Override
				public void deliveryComplete(IMqttDeliveryToken arg0) {
					System.out.println("SDN deliveryComplete");
				}
				
				@Override
				public void messageArrived(String topicName, MqttMessage msg)
						throws Exception {
					System.out.println("+++++ȡ��������: " + topicName);

					byte[] syncpBytes = msg.getPayload();

					System.out.println("+++++ȡ����Payload(HexString): "
							+ StringUtil.bytesToHexString(syncpBytes));
					String esn = SyncpUtil
							.get_ESN_From_Syncp_Header(syncpBytes);
					String psKeyB64 = dao.findTcuVehicleByEsn(esn).getPsKey();//Constants.ESN_PSKEY_MAP.get(esn);
					byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(
							syncpBytes, psKeyB64);
					System.out.println("+++++Syncp�������Payload(HexString): "
							+ StringUtil.bytesToHexString(decodedBytes));

					if (topicName.contains("TCU_ALERT")) {
						System.out.println(topicName);
						TCUAlert alert = TCUAlert.parseFrom(decodedBytes);
						System.out.println(alert);
						
						if (alert.getNonGenericAlert().getNonGenericAlertName() == NonGenericAlertNameEnum.HEV_BATTERY_FAULT) {
							BatteryFault bf = new BatteryFault();
							
							// VIN
							String vin = alert.getNonGenericAlert().getHevBatteryFaultAlert().getVehicleCommon().getVin();
							bf.setVin(vin);
							bf.setEsn(esn);
							
							HEVBatteryData hevBatteryData = alert.getNonGenericAlert().getHevBatteryFaultAlert().getHevBatteryData();
							int BattTrac_U_Actl = hevBatteryData.getBattTracUActl();
							bf.setBattTracUActl(BattTrac_U_Actl);
							int BattTrac_I_Actl = hevBatteryData.getBattTracIActl();
							bf.setBattTracIActl(BattTrac_I_Actl);
							int BattTracSoc2_Pc_Actl = hevBatteryData.getBattTracSoc2PcActl();
							bf.setBattTracSoc2PcActl(BattTracSoc2_Pc_Actl);
							int BattTrac_Te_Actl = hevBatteryData.getBattTracTeActl();
							bf.setBattTracTeActl(BattTrac_Te_Actl);
							int VehStrtInhbt_B_RqBatt = hevBatteryData.getVehStrtInhbtBRqBatt();
							bf.setVehStrtInhbtBRqBatt(VehStrtInhbt_B_RqBatt);
							int BattTracOff_B_Actl = hevBatteryData.getBattTracOffBActl();
							bf.setBattTracOffBActl(BattTracOff_B_Actl);
							int BattTrac_Pw_LimChrg = hevBatteryData.getBattTracPwLimChrg();
							bf.setBattTracPwLimChrg(BattTrac_Pw_LimChrg);
							int BattTrac_Pw_LimDchrg = hevBatteryData.getBattTracPwLimDchrg();
							bf.setBattTracOffFstDActl(BattTrac_Pw_LimDchrg);
							int BattTracOffFst_D_Actl = hevBatteryData.getBattTracOffFstDActl();
							bf.setBattTracOffFstDActl(BattTracOffFst_D_Actl);
							bf.setInsertDate(new Date());
							//time
							bf.setTime(parseUTCDate(alert.getNonGenericAlert().getHevBatteryFaultAlert().getVehicleCommon().getModemUTCDateTime()));
							//HEVBatteryFaultSeverityEnum
							//bf.setHevBatteryFaultSeverity(alert.getNonGenericAlert().getHevBatteryFaultAlert().getHevBatteryFaultSeverityEnum().getNumber());
							//ECUId
							bf.setEcuId(alert.getNonGenericAlert().getHevBatteryFaultAlert().getBECMDiagnosticsData().getECUId());
							//ECUStatus
							//bf.setEcuStatus(alert.getNonGenericAlert().getHevBatteryFaultAlert().getBECMDiagnosticsData().getECUStatus().getNumber());
							
							List<DTCInfo> dtcInfos = alert.getNonGenericAlert().getHevBatteryFaultAlert().getBECMDiagnosticsData().getDtcInfoList();
							
							List<BFDTCInfo> bfinfos = new ArrayList<BFDTCInfo>();
							for(DTCInfo info : dtcInfos) {
								BFDTCInfo bfinfo = new BFDTCInfo();
								bfinfo.setDtcId(info.getDTCId());
								bfinfo.setDtcAdditionalInfo(info.getDTCAdditionalInfo());
								bfinfo.setDtcStatus(info.getDTCStatus());
								
								bfinfos.add(bfinfo);
							}
							//net.sf.json.JSONObject obj = net.sf.json.JSONObject.fromObject(dtcInfos);
							net.sf.json.JSONArray bfinfoDTCs = net.sf.json.JSONArray.fromObject(bfinfos);
							
							bf.setBecmDiagnosticsData(bfinfoDTCs.toString());
							
							dao.insertBatteryFault(bf);
							
						} else if (alert.getNonGenericAlert().getNonGenericAlertName() == NonGenericAlertNameEnum.HEV_DATA_MONITOR) {/*
							GPSInfo gpsInfo = alert.getNonGenericAlert().getHevDataMonitoringAlert().getHevVehicleStatus().getGpsInfo();
							int GPS_Latitude_Degrees = gpsInfo.getLatitude().getGPSLatitudeDegrees();
							int GPS_Latitude_Min_dec = gpsInfo.getLatitude().getGPSLatitudeMinDec();
							int GPS_Latitude_Minutes = gpsInfo.getLatitude().getGPSLatitudeMinutes();
							int GPS_Longitude_Degrees = gpsInfo.getLongitude().getGPSLongitudeDegrees();
							int GPS_Longitude_Min_dec = gpsInfo.getLongitude().getGPSLongitudeMinDec();
							int GPS_Longitude_Minutes = gpsInfo.getLongitude().getGPSLongitudeMinutes();
							VehicleStatus hevVehicleStatus = alert.getNonGenericAlert().getHevDataMonitoringAlert().getHevVehicleStatus();
							HEVBatteryData hevBatteryData = alert.getNonGenericAlert().getHevDataMonitoringAlert().getHevBatteryData();
							CommonFromVehicle commonFromVehicle = alert.getNonGenericAlert().getHevDataMonitoringAlert().getVehicleCommon();
							VehicleBean vehicleBean = new VehicleBean();
							
							String vin = alert.getNonGenericAlert().getHevDataMonitoringAlert().getVehicleCommon().getVin();
							vehicleBean.setVin(vin);
							vehicleBean.setEsn(esn);
							double lat = GPS_Latitude_Degrees + (double)GPS_Latitude_Minutes/60 + (double)GPS_Latitude_Min_dec/3600;
							vehicleBean.setLat(lat);
							double lng = GPS_Longitude_Degrees + (double)GPS_Longitude_Minutes/60 + (double)GPS_Longitude_Min_dec/3600;
							vehicleBean.setLng(lng);
							int GPS_Speed = gpsInfo.getGPSSpeed();
							vehicleBean.setGPSSpeed(GPS_Speed);
							int GPS_Compass_direction = gpsInfo.getGPSCompassDirection();
							vehicleBean.setGPSCompassDirection(GPS_Compass_direction);
							int GPS_Heading = gpsInfo.getGPSHeading();
							vehicleBean.setGPSHeading(GPS_Heading);
							
							int Ignition_status = hevVehicleStatus.getIgnitionStatus();
							vehicleBean.setIgnitionStatus(Ignition_status);
							int Veh_V_ActlEng = hevVehicleStatus.getVehVActlEng();
							vehicleBean.setVehVActlEng(Veh_V_ActlEng);
							int OdometerMasterValue = hevVehicleStatus.getOdometerMasterValue();
							vehicleBean.setOdometerMasterValue(OdometerMasterValue);
							int FuelRange_L_Dsply = hevVehicleStatus.getFuelRangeLDsply();
							vehicleBean.setFuelRangeLDsply(FuelRange_L_Dsply);
							int GearLvrPos_D_Actl = hevVehicleStatus.getGearLvrPosDActl();
							vehicleBean.setGearLvrPosDActl(GearLvrPos_D_Actl);
							int BpedDrvAppl_D_Actl = hevVehicleStatus.getBpedDrvApplDActl().getNumber();// TODO
							vehicleBean.setBpedDrvApplDActl(BpedDrvAppl_D_Actl);
							int ApedPos_Pc_ActlArb = hevVehicleStatus.getApedPosPcActlArb();
							vehicleBean.setApedPosPcActlArb(ApedPos_Pc_ActlArb);
							int EngAout_N_Actl = hevVehicleStatus.getEngAoutNActl();
							vehicleBean.setEngAoutNActl(EngAout_N_Actl);
							int EngClnt_Te_Actl = hevVehicleStatus.getEngClntTeActl();
							vehicleBean.setEngClntTeActl(EngClnt_Te_Actl);
							int EngSrvcRqd_B_Rq = hevVehicleStatus.getEngSrvcRqdBRq();
							vehicleBean.setEngSrvcRqdBRq(EngSrvcRqd_B_Rq);
							int FuelLvl_Pc_Dsply = hevVehicleStatus.getFuelLvlPcDsply();
							vehicleBean.setFuelLvlPcDsply(FuelLvl_Pc_Dsply);
							int AirAmb_Te_ActlFilt = hevVehicleStatus.getAirAmbTeActlFilt();
							vehicleBean.setAirAmbTeActlFilt(AirAmb_Te_ActlFilt);
							int PrplWhlTot2_Tq_Actl = hevVehicleStatus.getPrplWhlTot2TqActl();
							vehicleBean.setPrplWhlTot2TqActl(PrplWhlTot2_Tq_Actl);
							int PwPckTq_D_Stat = hevVehicleStatus.getPwPckTqDStat();
							vehicleBean.setPwPckTqDStat(PwPckTq_D_Stat);
							int BSBattSOC = hevVehicleStatus.getBSBattSOC();
							vehicleBean.setbSBattSOC(BSBattSOC);
							
							int BattTrac_U_Actl = hevBatteryData.getBattTracUActl();
							vehicleBean.setBattTracUActl(BattTrac_U_Actl);
							int BattTrac_I_Actl = hevBatteryData.getBattTracIActl();
							vehicleBean.setBattTracIActl(BattTrac_I_Actl);
							int BattTracSoc2_Pc_Actl = hevBatteryData.getBattTracSoc2PcActl();
							vehicleBean.setBattTracSoc2PcActl(BattTracSoc2_Pc_Actl);
							int BattTrac_Te_Actl = hevBatteryData.getBattTracTeActl();
							vehicleBean.setBattTracTeActl(BattTrac_Te_Actl);
							int VehStrtInhbt_B_RqBatt = hevBatteryData.getVehStrtInhbtBRqBatt();
							vehicleBean.setVehStrtInhbtBRqBatt(VehStrtInhbt_B_RqBatt);
							int BattTracOff_B_Actl = hevBatteryData.getBattTracOffBActl();
							vehicleBean.setBattTracOffBActl(BattTracOff_B_Actl);
							int BattTrac_Pw_LimChrg = hevBatteryData.getBattTracPwLimChrg();
							vehicleBean.setBattTracPwLimChrg(BattTrac_Pw_LimChrg);
							int BattTrac_Pw_LimDchrg = hevBatteryData.getBattTracPwLimDchrg();
							vehicleBean.setBattTracOffFstDActl(BattTrac_Pw_LimDchrg);
							int BattTracOffFst_D_Actl = hevBatteryData.getBattTracOffFstDActl();
							vehicleBean.setBattTracOffFstDActl(BattTracOffFst_D_Actl);
							int BattTracWarnLamp_B_Rq = hevVehicleStatus.getBattTracWarnLampBRq();
							vehicleBean.setBattTracWarnLampBRq(BattTracWarnLamp_B_Rq);
							int BattTracSrvcRqd_B_Rq = hevVehicleStatus.getBattTracSrvcRqdBRq();
							vehicleBean.setBattTracSrvcRqdBRq(BattTracSrvcRqd_B_Rq);
							vehicleBean.setInsertDate(parseUTCDate2Date(commonFromVehicle.getModemUTCDateTime()));
							dao.insertVehicleRecord(vehicleBean);
						*/} else if (alert.getNonGenericAlert().getNonGenericAlertName() == NonGenericAlertNameEnum.VEHICLE_DIAGNOSTIC_DATA_RESPONSE) {
							TcuFtcpRecord tcurecord = new TcuFtcpRecord();
							tcurecord.setRecord(alert.toString().replaceAll("\n", "<br/>").replaceAll("\r", "<br/>"));
							int corId = alert.getNonGenericAlert().getVehicleDiagnosticDataResponseAlert().getVehicleCommon().getCorrelationId();
							tcurecord.setCorrelateMsgId(corId);
							String vin = alert.getNonGenericAlert().getVehicleDiagnosticDataResponseAlert().getVehicleCommon().getVin();
							tcurecord.setVin(vin);
							tcurecord.setInsertDate(new Date());
							
							dao.insertTcuFtcpRecord(tcurecord);
						}
						
					} else if (topicName.contains("COMMAND_RESPONSE")) {
						TCUCommandResponse commandResponse = TCUCommandResponse
								.parseFrom(decodedBytes);
						System.out.println(commandResponse);
						if (commandResponse.getNonTimeSensitiveCommandResponse().getNonTimeSensitiveCommandResponseNameEnum() 
								== NonTimeSensitiveCommandNameEnum.VEHICLE_DIAGNOSTIC_DATA_REQUEST) {
							
							TcuFtcpRecord tcurecord = new TcuFtcpRecord();
							tcurecord.setRecord(commandResponse.toString().replaceAll("\n", "<br/>").replaceAll("\r", "<br/>"));
							int corId = commandResponse.getNonTimeSensitiveCommandResponse().getVehicleDiagnosticDataRequestCommandResponse().getVehicleCommon().getCorrelationId();
							tcurecord.setCorrelateMsgId(corId);
							String vin = commandResponse.getNonTimeSensitiveCommandResponse().getVehicleDiagnosticDataRequestCommandResponse().getVehicleCommon().getVin();
							tcurecord.setVin(vin);
							tcurecord.setInsertDate(new Date());
							
							dao.insertTcuFtcpRecord(tcurecord);
						}
					} else if (topicName
							.contains("TCU_CONNECTION_STATUS_ALERT")) {
						TCUConnectionStatusAlert connectAlert = TCUConnectionStatusAlert
								.parseFrom(decodedBytes);
						System.out.println(connectAlert);
					}
				}
			});
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static Date parseUTCDate2Date(UTCDateTime utcTimeStamp) {
		Calendar cal=Calendar.getInstance();

		cal.set(Calendar.YEAR, utcTimeStamp.getUTCYear());

		cal.set(Calendar.MONTH, utcTimeStamp.getUTCMonth());

		cal.set(Calendar.DAY_OF_MONTH, utcTimeStamp.getUTCDay());

		cal.set(Calendar.HOUR, utcTimeStamp.getUTCHour());
		
		cal.set(Calendar.MINUTE, utcTimeStamp.getUTCMin());
		
		cal.set(Calendar.SECOND, utcTimeStamp.getUTCSecond());
		
		Date date=cal.getTime();
		
		return date;
	}
	private static String parseUTCDate(UTCDateTime utcTimeStamp)
	{
		// dboll
		String parsedDate = utcTimeStamp.getUTCYear()/*.getGpsUtcYrNoActl()*/+"/" + (utcTimeStamp.getUTCMonth() + 1)/*.getGpsUtcMnthNoActl()*/+"/"+ utcTimeStamp.getUTCDay()/*.getGpsUtcDayNoActl()*/ +
		" "+utcTimeStamp.getUTCHour()/*.getGPSUTCHours()*/+":" + utcTimeStamp.getUTCMin()/*.getGPSUTCMinutes()*/+":"+ utcTimeStamp.getUTCSecond()/*.getGPSUTCSeconds()*/;
		//logger.info("Date as String :" + parsedDate);
		
		return parsedDate;
	}
	
	public MqttAsyncClient getMQTTClient() throws MqttException, InvalidProtocolBufferException {
		MqttConnectOptions _mqttConnOpt = new MqttConnectOptions();
		_mqttConnOpt.setCleanSession(false);
		_mqttConnOpt.setUserName(Constants.SDN_USE_MQTT_USERNAME);
		_mqttConnOpt.setPassword(Constants.SDN_USE_MQTT_PASSWORD.toCharArray());
		
		MqttDefaultFilePersistence dataStore = new MqttDefaultFilePersistence("C:\\temp");
		MqttAsyncClient mqttclient = new MqttAsyncClient(Constants.SDN_USE_MQTT_URL, StringUtil.generateUniqueClientId(), dataStore);
		
		IMqttToken mqttConnToken = mqttclient.connect(_mqttConnOpt);
		
		try
		{
			mqttConnToken.waitForCompletion();
		} // end-try
		catch (MqttException mqttex)
		{
			if (mqttclient != null)
			{
				mqttclient.close();
				mqttclient = null;
			} // end-if
			throw mqttex;
		} // end-catch
		return mqttclient;
	}
	
	@Override
	public void initMQTT() {
		connectMQTT();
		subcribeTopics();
	}

	private void subcribeTopics() {
		try {
			
			for(String vin : FTCPConstants.vins) {
				List<String> needToSubList = StringUtil.createSDNSubcribeTopics(FTCPConstants.region, vin);
				
				for(String topic : needToSubList) {
					mqttclient.subscribe(topic, 2);
					System.out.println("Subcribe to topic: " + topic);
				} 
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int publishTcuCommand(String vin, String esn, String psKey) throws Exception {
		String topic = StringUtil.getPublishTopic(FTCPConstants.region, vin, "TCU_COMMAND");
		System.out.println(topic);
		TCUCommandCreativeMock creative = new TCUCommandCreativeMock(esn, vin);
		byte[] cmdBytes = creative.createTCUCommandByteArray(FTCP3.NonTimeSensitiveCommandNameEnum.VEHICLE_DIAGNOSTIC_DATA_REQUEST_VALUE, FTCP3.TCUCommand.TCUCommandType.NON_TIME_SENSITIVE_VALUE);
		
		byte[] bytesToPublish = SyncpUtil.encodeSyncpPacket(cmdBytes, esn, psKey);
		System.out.println(StringUtil.bytesToHexString(bytesToPublish));
		System.out.println("mqttclient.isConnected()=" + mqttclient.isConnected());
		mqttclient.publish(topic, new MqttMessage(bytesToPublish));

		return creative.getCloundMessageId();
	}
}
