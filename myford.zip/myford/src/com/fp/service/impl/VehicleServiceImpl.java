package com.fp.service.impl;

import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fp.dao.VehicleDao;
import com.fp.domain.BFDTCInfo;
import com.fp.domain.BatteryFault;
import com.fp.domain.TcuFtcpRecord;
import com.fp.domain.VehicleBean;
import com.fp.service.VehicleService;

@Service
@Transactional
public class VehicleServiceImpl implements VehicleService {
	
	@Autowired
	private VehicleDao dao;
	
	@Override
	public List<VehicleBean> findVehicleByVin(String vin) {
		
		return dao.findVehicleByVin(vin);
	}

	@Override
	public List<VehicleBean> findAllVehicles() {
		return dao.findAllVehicles();
	}

	@Override
	public List<BatteryFault> findAllBatteryFault() {
		List<BatteryFault> bfInfos = dao.findAllBatteryFault();
		for(BatteryFault bf : bfInfos) {
			JSONArray dtcJsonArr = JSONArray.fromObject(bf.getBecmDiagnosticsData());
			List<BFDTCInfo> oneBFinfoList = bf.getDtcinfos();
			for(int i=0; i<dtcJsonArr.size(); i++) {
				BFDTCInfo bfinfo = new BFDTCInfo();
				JSONObject jo = (JSONObject)dtcJsonArr.get(i);
				int dtcId = Integer.parseInt(jo.get("dtcId").toString());
				int dtcAdditionalInfo = Integer.parseInt(jo.get("dtcAdditionalInfo").toString());
				int dtcStatus = Integer.parseInt(jo.get("dtcStatus").toString());
				bfinfo.setDtcId(dtcId);
				bfinfo.setDtcAdditionalInfo(dtcAdditionalInfo);
				bfinfo.setDtcStatus(dtcStatus);
				oneBFinfoList.add(bfinfo);
			}
		}
		return bfInfos;
	}
	
	@Override
	public void insertVehicleRecord(VehicleBean bean) {
		dao.insertVehicleRecord(bean);
	}

	@Override
	public List<TcuFtcpRecord> selectTcuRecordByCorid(int correlateMsgId) {
		return dao.selectTcuRecordByCorid(correlateMsgId);
	}

	@Override
	public void insertTcuFtcpRecord(TcuFtcpRecord bean) {
		dao.insertTcuFtcpRecord(bean);
	}

	@Override
	public List<VehicleBean> findAllProCityNullVehicles() {
		return dao.findAllProCityNullVehicles();
	}

	@Override
	public List<VehicleBean> findCityVehicleCnt() {
		return dao.findCityVehicleCnt();
	}

	@Override
	public List<VehicleBean> findCityVehicles(String city) {
		return dao.findCityVehicles(city);
	}

	@Override
	public int updateVehicle(VehicleBean bean) {
		if (null != bean.getProvince() && !bean.getProvince().equals("") && null != bean.getCity() && bean.getCity().equals("")) {
			bean.setCity(bean.getProvince());
		}
		return dao.updateVehicle(bean);
	}

}
