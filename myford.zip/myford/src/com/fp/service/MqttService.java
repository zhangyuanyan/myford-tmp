package com.fp.service;


public interface MqttService {

	public abstract void initMQTT();
	
	public int publishTcuCommand(String vin, String esn, String psKey) throws Exception;
}