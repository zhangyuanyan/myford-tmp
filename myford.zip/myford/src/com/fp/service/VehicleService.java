package com.fp.service;

import java.util.List;

import com.fp.domain.BatteryFault;
import com.fp.domain.TcuFtcpRecord;
import com.fp.domain.VehicleBean;

public interface VehicleService {

	public abstract List<VehicleBean> findVehicleByVin(String vin);

	public abstract List<VehicleBean> findAllVehicles();

	public abstract List<BatteryFault> findAllBatteryFault();
	
	public abstract void insertVehicleRecord(VehicleBean bean);
	
	public abstract List<TcuFtcpRecord> selectTcuRecordByCorid(int correlateMsgId);
	
	public abstract void insertTcuFtcpRecord(TcuFtcpRecord bean);
	
	public List<VehicleBean> findAllProCityNullVehicles();
	
	public List<VehicleBean> findCityVehicleCnt();
	
	public List<VehicleBean> findCityVehicles(String city);
	
	public int updateVehicle(VehicleBean bean);
	
}