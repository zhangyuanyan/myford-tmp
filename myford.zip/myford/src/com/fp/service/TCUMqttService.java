package com.fp.service;

import com.fp.domain.BatteryFault;
import com.fp.domain.VehicleBean;

public interface TCUMqttService {
	public abstract void initMQTT();
	
	public abstract void publishTcuDataMonitorAlert(String vin, String esn, VehicleBean vehicleBean) throws Exception;
	
	public abstract String publishTcuBatteryFaultAlert(String vin, String esn, BatteryFault batteryFaultBean) throws Exception;
	
	public abstract String publishProvisioningALert(String vin, String esn) throws Exception;
	
	public abstract String publishClearBatteryFaultAlert(String vin, String esn, BatteryFault batteryFaultBean) throws Exception;
	
	public abstract boolean isExistsUser(String name, String password);
}
