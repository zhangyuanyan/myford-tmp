package com.fp.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.fp.domain.RestApiParamBean;
import com.fp.domain.RestLoginUserBean;

public interface RestAPIService {
	public abstract void testAllInOne();
	public abstract void lock();
	public abstract void unlock();
	public abstract void remoteStart();
	public abstract void cancelRemoteStart();
	public abstract void refreshVehicle();
	public List<RestLoginUserBean> selectPerformanceByType(String typeName, String fromDate, String toDate);
	public RestLoginUserBean selectFailSuccessPercent(String typeName, String fromDate, String toDate);
	
	
	public List<RestLoginUserBean> selectPerformanceByPager(String typeName, String fromDate, String toDate,int pageNo, int pageSize);
	public int getTotalCount(String typeName, String fromDate, String toDate); 
	/*
	http://blog.csdn.net/communicate_/article/details/8462497
*/
	public abstract RestLoginUserBean selectPerformanceById(int id);
}
