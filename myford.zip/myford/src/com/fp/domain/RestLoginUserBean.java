package com.fp.domain;

import java.util.Date;

public class RestLoginUserBean {
	private int id;
	private double lightHouseCost;
	private double sdnLoginUserCost;
	private double sdnGetUserProfileCost;
	private double totalCost;
	private double allVehTime;
	public double getAllVehTime() {
		return allVehTime;
	}
	public void setAllVehTime(double allVehTime) {
		this.allVehTime = allVehTime;
	}
	public double getOneVehStatusTime() {
		return oneVehStatusTime;
	}
	public void setOneVehStatusTime(double oneVehStatusTime) {
		this.oneVehStatusTime = oneVehStatusTime;
	}
	private double oneVehStatusTime;
	private String restApiName;
	private String statusDesc;
	private int operationStatus;
	private String exeParam;
	private int pageNo;
	private int pageSize;
	
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public String getExeParam() {
		return exeParam;
	}
	public void setExeParam(String exeParam) {
		this.exeParam = exeParam;
	}
	private String typeName;
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	private String fromDate;
	private String toDate;
	private int successCnt;
	public int getSuccessCnt() {
		return successCnt;
	}
	public void setSuccessCnt(int successCnt) {
		this.successCnt = successCnt;
	}
	public int getFailCnt() {
		return failCnt;
	}
	public void setFailCnt(int failCnt) {
		this.failCnt = failCnt;
	}
	public double getMaxTime() {
		return maxTime;
	}
	public void setMaxTime(double maxTime) {
		this.maxTime = maxTime;
	}
	public double getMinTime() {
		return minTime;
	}
	public void setMinTime(double minTime) {
		this.minTime = minTime;
	}
	public double getAverageTime() {
		return averageTime;
	}
	public void setAverageTime(double averageTime) {
		this.averageTime = averageTime;
	}
	private int failCnt;
	private double maxTime;
	private double minTime;
	private double averageTime;
	
	public int getOperationStatus() {
		return operationStatus;
	}
	public void setOperationStatus(int operationStatus) {
		this.operationStatus = operationStatus;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public String getRestApiName() {
		return restApiName;
	}
	public void setRestApiName(String restApiName) {
		this.restApiName = restApiName;
	}
	public double getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}
	private Date insertDate;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getLightHouseCost() {
		return lightHouseCost;
	}
	public void setLightHouseCost(double lightHouseCost) {
		this.lightHouseCost = lightHouseCost;
	}
	public double getSdnLoginUserCost() {
		return sdnLoginUserCost;
	}
	public void setSdnLoginUserCost(double sdnLoginUserCost) {
		this.sdnLoginUserCost = sdnLoginUserCost;
	}
	public double getSdnGetUserProfileCost() {
		return sdnGetUserProfileCost;
	}
	public void setSdnGetUserProfileCost(double sdnGetUserProfileCost) {
		this.sdnGetUserProfileCost = sdnGetUserProfileCost;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
}
