package com.fp.domain;

public class RestApiParamBean {
	@Override
	public String toString() {
		return "RestApiParamBean [esn=" + esn + ", passwordForTestLogin="
				+ passwordForTestLogin + ", passwordNotForTestLogin="
				+ passwordNotForTestLogin + ", unameForTestLogin="
				+ unameForTestLogin + ", unameNotForTestLogin="
				+ unameNotForTestLogin + ", vin=" + vin + "]";
	}
	private String esn;
	private String passwordForTestLogin;
	private String passwordNotForTestLogin;
	private String unameForTestLogin;
	private String unameNotForTestLogin;
	private String vin;
	
	public String getEsn() {
		return esn;
	}
	public String getPasswordForTestLogin() {
		return passwordForTestLogin;
	}
	public String getPasswordNotForTestLogin() {
		return passwordNotForTestLogin;
	}
	public String getUnameForTestLogin() {
		return unameForTestLogin;
	}
	public String getUnameNotForTestLogin() {
		return unameNotForTestLogin;
	}
	public String getVin() {
		return vin;
	}
	public void setEsn(String esn) {
		this.esn = esn;
	}
	public void setPasswordForTestLogin(String passwordForTestLogin) {
		this.passwordForTestLogin = passwordForTestLogin;
	}
	public void setPasswordNotForTestLogin(String passwordNotForTestLogin) {
		this.passwordNotForTestLogin = passwordNotForTestLogin;
	}
	public void setUnameForTestLogin(String unameForTestLogin) {
		this.unameForTestLogin = unameForTestLogin;
	}
	public void setUnameNotForTestLogin(String unameNotForTestLogin) {
		this.unameNotForTestLogin = unameNotForTestLogin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
}
