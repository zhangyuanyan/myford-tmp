package com.fp.domain;

import java.math.BigDecimal;
import java.util.Date;

public class VehicleBean {
	private int correlationId;
	public int getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(int correlationId) {
		this.correlationId = correlationId;
	}

	// GPS_Speed
	private int GPSSpeed;
	// GPS_Compass_direction
	private int GPSCompassDirection;
	// GPS_Heading
	private int GPSHeading;
	
	// GPS_actual_vs_infer_pos
	private int GPSActualVsInferPos;
	public int getGPSActualVsInferPos() {
		return GPSActualVsInferPos;
	}

	public void setGPSActualVsInferPos(int gPSActualVsInferPos) {
		GPSActualVsInferPos = gPSActualVsInferPos;
	}

	// ----VehicleGGCCData
	// Ignition_status
	private int ignitionStatus;
	// Veh_V_ActlEng
	private int vehVActlEng;
	// OdometerMasterValue
	private int odometerMasterValue;
	// FuelRange_L_Dsply
	private int fuelRangeLDsply;
	// GearLvrPos_D_Actl
	private int gearLvrPosDActl;
	// BpedDrvAppl_D_Actl
	private int bpedDrvApplDActl;
	// ApedPos_Pc_ActlArb
	private int apedPosPcActlArb;
	// EngAout_N_Actl
	private int engAoutNActl;
	// EngClnt_Te_Actl
	private int engClntTeActl;
	// EngSrvcRqd_B_Rq
	private int engSrvcRqdBRq;
	// FuelLvl_Pc_Dsply
	private int fuelLvlPcDsply;
	// AirAmb_Te_ActlFilt
	private int airAmbTeActlFilt;
	// PrplWhlTot2_Tq_Actl
	private int prplWhlTot2TqActl;
	// PwPckTq_D_Stat
	private int pwPckTqDStat;
	// BSBattSOC
	private int bSBattSOC;
	// BattTrac_U_Actl
	private int battTracUActl;
	// BattTrac_I_Actl
	private int battTracIActl;
	// BattTracSoc2_Pc_Actl
	private int battTracSoc2PcActl;
	// BattTrac_Te_Actl
	private int battTracTeActl;
	// VehStrtInhbt_B_RqBatt
	private int vehStrtInhbtBRqBatt;
	// BattTracOff_B_Actl
	private int battTracOffBActl;
	// BattTrac_Pw_LimChrg
	private int battTracPwLimChrg;
	// BattTrac_Pw_LimDchrg
	private int battTracPwLimDchrg;
	// BattTracOffFst_D_Actl
	private int battTracOffFstDActl;
	// BattTracWarnLamp_B_Rq
	private int battTracWarnLampBRq;
	// BattTracSrvcRqd_B_Rq
	private int battTracSrvcRqdBRq;
	private Date insertDate;
	private Integer id;
	private String vin;
	private String esn;
	private String province;
	private int cityCnt;
	public int getCityCnt() {
		return cityCnt;
	}

	public void setCityCnt(int cityCnt) {
		this.cityCnt = cityCnt;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	private String city;
	int GPS_Latitude_Degrees;
	public int getGPS_Latitude_Degrees() {
		return GPS_Latitude_Degrees;
	}

	public void setGPS_Latitude_Degrees(int gPS_Latitude_Degrees) {
		GPS_Latitude_Degrees = gPS_Latitude_Degrees;
	}

	public int getGPS_Latitude_Min_dec() {
		return GPS_Latitude_Min_dec;
	}

	public void setGPS_Latitude_Min_dec(int gPS_Latitude_Min_dec) {
		GPS_Latitude_Min_dec = gPS_Latitude_Min_dec;
	}

	public int getGPS_Latitude_Minutes() {
		return GPS_Latitude_Minutes;
	}

	public void setGPS_Latitude_Minutes(int gPS_Latitude_Minutes) {
		GPS_Latitude_Minutes = gPS_Latitude_Minutes;
	}

	public int getGPS_Longitude_Degrees() {
		return GPS_Longitude_Degrees;
	}

	public void setGPS_Longitude_Degrees(int gPS_Longitude_Degrees) {
		GPS_Longitude_Degrees = gPS_Longitude_Degrees;
	}

	public int getGPS_Longitude_Min_dec() {
		return GPS_Longitude_Min_dec;
	}

	public void setGPS_Longitude_Min_dec(int gPS_Longitude_Min_dec) {
		GPS_Longitude_Min_dec = gPS_Longitude_Min_dec;
	}

	public int getGPS_Longitude_Minutes() {
		return GPS_Longitude_Minutes;
	}

	public void setGPS_Longitude_Minutes(int gPS_Longitude_Minutes) {
		GPS_Longitude_Minutes = gPS_Longitude_Minutes;
	}

	int GPS_Latitude_Min_dec;
	int GPS_Latitude_Minutes;
	int GPS_Longitude_Degrees;
	int GPS_Longitude_Min_dec;
	int GPS_Longitude_Minutes;
	
	private int errorFlg;

	public int getErrorFlg() {
		return errorFlg;
	}

	public void setErrorFlg(int errorFlg) {
		this.errorFlg = errorFlg;
	}

	public String getEsn() {
		return esn;
	}

	public void setEsn(String esn) {
		this.esn = esn;
	}

	private double lng;
	private double lat;

	public int getAirAmbTeActlFilt() {
		return airAmbTeActlFilt;
	}

	public int getApedPosPcActlArb() {
		return apedPosPcActlArb;
	}

	public int getBattTracIActl() {
		return battTracIActl;
	}

	public int getBattTracOffBActl() {
		return battTracOffBActl;
	}

	public int getBattTracOffFstDActl() {
		return battTracOffFstDActl;
	}

	public int getBattTracPwLimChrg() {
		return battTracPwLimChrg;
	}

	public int getBattTracPwLimDchrg() {
		return battTracPwLimDchrg;
	}

	public int getBattTracSoc2PcActl() {
		return battTracSoc2PcActl;
	}

	public int getBattTracSrvcRqdBRq() {
		return battTracSrvcRqdBRq;
	}

	public int getBattTracTeActl() {
		return battTracTeActl;
	}

	public int getBattTracUActl() {
		return battTracUActl;
	}

	public int getBattTracWarnLampBRq() {
		return battTracWarnLampBRq;
	}

	public int getBpedDrvApplDActl() {
		return bpedDrvApplDActl;
	}

	public int getbSBattSOC() {
		return bSBattSOC;
	}

	public int getEngAoutNActl() {
		return engAoutNActl;
	}

	public int getEngClntTeActl() {
		return engClntTeActl;
	}

	public int getEngSrvcRqdBRq() {
		return engSrvcRqdBRq;
	}

	public int getFuelLvlPcDsply() {
		return fuelLvlPcDsply;
	}

	public int getFuelRangeLDsply() {
		return fuelRangeLDsply;
	}

	public int getGearLvrPosDActl() {
		return gearLvrPosDActl;
	}

	public int getGPSCompassDirection() {
		return GPSCompassDirection;
	}

	public int getGPSHeading() {
		return GPSHeading;
	}

	public int getGPSSpeed() {
		return GPSSpeed;
	}

	public Integer getId() {
		return id;
	}

	public int getIgnitionStatus() {
		return ignitionStatus;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public double getLat() {
		return lat;
	}

	public double getLng() {
		return lng;
	}

	public int getOdometerMasterValue() {
		return odometerMasterValue;
	}

	public int getPrplWhlTot2TqActl() {
		return prplWhlTot2TqActl;
	}

	public int getPwPckTqDStat() {
		return pwPckTqDStat;
	}

	public int getVehStrtInhbtBRqBatt() {
		return vehStrtInhbtBRqBatt;
	}

	public int getVehVActlEng() {
		return vehVActlEng;
	}

	public String getVin() {
		return vin;
	}

	public void setAirAmbTeActlFilt(int airAmbTeActlFilt) {
		this.airAmbTeActlFilt = airAmbTeActlFilt;
	}

	public void setApedPosPcActlArb(int apedPosPcActlArb) {
		this.apedPosPcActlArb = apedPosPcActlArb;
	}

	public void setBattTracIActl(int battTracIActl) {
		this.battTracIActl = battTracIActl;
	}

	public void setBattTracOffBActl(int battTracOffBActl) {
		this.battTracOffBActl = battTracOffBActl;
	}

	public void setBattTracOffFstDActl(int battTracOffFstDActl) {
		this.battTracOffFstDActl = battTracOffFstDActl;
	}

	public void setBattTracPwLimChrg(int battTracPwLimChrg) {
		this.battTracPwLimChrg = battTracPwLimChrg;
	}

	public void setBattTracPwLimDchrg(int battTracPwLimDchrg) {
		this.battTracPwLimDchrg = battTracPwLimDchrg;
	}

	public void setBattTracSoc2PcActl(int battTracSoc2PcActl) {
		this.battTracSoc2PcActl = battTracSoc2PcActl;
	}

	public void setBattTracSrvcRqdBRq(int battTracSrvcRqdBRq) {
		this.battTracSrvcRqdBRq = battTracSrvcRqdBRq;
	}

	public void setBattTracTeActl(int battTracTeActl) {
		this.battTracTeActl = battTracTeActl;
	}

	public void setBattTracUActl(int battTracUActl) {
		this.battTracUActl = battTracUActl;
	}

	public void setBattTracWarnLampBRq(int battTracWarnLampBRq) {
		this.battTracWarnLampBRq = battTracWarnLampBRq;
	}

	public void setBpedDrvApplDActl(int bpedDrvApplDActl) {
		this.bpedDrvApplDActl = bpedDrvApplDActl;
	}

	public void setbSBattSOC(int bSBattSOC) {
		this.bSBattSOC = bSBattSOC;
	}

	public void setEngAoutNActl(int engAoutNActl) {
		this.engAoutNActl = engAoutNActl;
	}

	public void setEngClntTeActl(int engClntTeActl) {
		this.engClntTeActl = engClntTeActl;
	}

	public void setEngSrvcRqdBRq(int engSrvcRqdBRq) {
		this.engSrvcRqdBRq = engSrvcRqdBRq;
	}

	public void setFuelLvlPcDsply(int fuelLvlPcDsply) {
		this.fuelLvlPcDsply = fuelLvlPcDsply;
	}

	public void setFuelRangeLDsply(int fuelRangeLDsply) {
		this.fuelRangeLDsply = fuelRangeLDsply;
	}

	public void setGearLvrPosDActl(int gearLvrPosDActl) {
		this.gearLvrPosDActl = gearLvrPosDActl;
	}

	public void setGPSCompassDirection(int gPSCompassDirection) {
		GPSCompassDirection = gPSCompassDirection;
	}

	public void setGPSHeading(int gPSHeading) {
		GPSHeading = gPSHeading;
	}

	public void setGPSSpeed(int gPSSpeed) {
		GPSSpeed = gPSSpeed;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setIgnitionStatus(int ignitionStatus) {
		this.ignitionStatus = ignitionStatus;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public void setLat(double lat) {
		BigDecimal b = new BigDecimal(lat);
		double f1 = b.setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
		this.lat = f1;
	}

	public void setLng(double lng) {
		BigDecimal b = new BigDecimal(lng);
		double f1 = b.setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
		this.lng = f1;
	}

	public void setOdometerMasterValue(int odometerMasterValue) {
		this.odometerMasterValue = odometerMasterValue;
	}

	public void setPrplWhlTot2TqActl(int prplWhlTot2TqActl) {
		this.prplWhlTot2TqActl = prplWhlTot2TqActl;
	}

	public void setPwPckTqDStat(int pwPckTqDStat) {
		this.pwPckTqDStat = pwPckTqDStat;
	}

	public void setVehStrtInhbtBRqBatt(int vehStrtInhbtBRqBatt) {
		this.vehStrtInhbtBRqBatt = vehStrtInhbtBRqBatt;
	}

	public void setVehVActlEng(int vehVActlEng) {
		this.vehVActlEng = vehVActlEng;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}
}
