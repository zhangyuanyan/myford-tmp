package com.fp.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ford.ftcp.FTCP3.ECUData.ECUStatusEnum;
import com.ford.ftcp.FTCP3.HEVBatteryFaultAlert.HEVBatteryFaultSeverityEnum;

public class BatteryFault {

	private int id;
	public int getId() {
		return id;
	}
	
	private String time;
	private HEVBatteryFaultSeverityEnum hevBatteryFaultSeverity;//WARNING = 0; SERVICE = 1;
	public HEVBatteryFaultSeverityEnum getHevBatteryFaultSeverity() {
		return hevBatteryFaultSeverity;
	}
	public void setHevBatteryFaultSeverity(
			HEVBatteryFaultSeverityEnum hevBatteryFaultSeverity) {
		this.hevBatteryFaultSeverity = hevBatteryFaultSeverity;
	}

	private int ecuId;
	private ECUStatusEnum ecuStatus;// NO_COMMUNICATION = 0; CAN_GDS = 1; GGDS = 2; UNKNOWN = 3;
	
	public ECUStatusEnum getEcuStatus() {
		return ecuStatus;
	}
	public void setEcuStatus(ECUStatusEnum ecuStatus) {
		this.ecuStatus = ecuStatus;
	}

	private List<BFDTCInfo> dtcinfos = new ArrayList<BFDTCInfo>();
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getEcuId() {
		return ecuId;
	}
	public void setEcuId(int ecuId) {
		this.ecuId = ecuId;
	}
	public List<BFDTCInfo> getDtcinfos() {
		return dtcinfos;
	}
	public void setDtcinfos(List<BFDTCInfo> dtcinfos) {
		this.dtcinfos = dtcinfos;
	}
	public void setId(int id) {
		this.id = id;
	}
	private String vin;
	
	private String esn;
	
	// BattTrac_I_Actl
	private int battTracIActl;
	
	// BattTracOff_B_Actl
	private int battTracOffBActl;
	// BattTracOffFst_D_Actl
	private int battTracOffFstDActl;
	// BattTrac_Pw_LimChrg
	private int battTracPwLimChrg;
	// BattTrac_Pw_LimDchrg
	private int battTracPwLimDchrg;
	// BattTracSoc2_Pc_Actl
	private int battTracSoc2PcActl;
	// BattTrac_Te_Actl
	private int battTracTeActl;
	// BattTrac_U_Actl
	private int battTracUActl;
	// dtc
	private String becmDiagnosticsData;
	
	private Date insertDate;
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	// VehStrtInhbt_B_RqBatt
	private int vehStrtInhbtBRqBatt;

	public int getBattTracIActl() {
		return battTracIActl;
	}
	public int getBattTracOffBActl() {
		return battTracOffBActl;
	}
	public int getBattTracOffFstDActl() {
		return battTracOffFstDActl;
	}
	public int getBattTracPwLimChrg() {
		return battTracPwLimChrg;
	}
	public int getBattTracPwLimDchrg() {
		return battTracPwLimDchrg;
	}
	public int getBattTracSoc2PcActl() {
		return battTracSoc2PcActl;
	}
	public int getBattTracTeActl() {
		return battTracTeActl;
	}
	public int getBattTracUActl() {
		return battTracUActl;
	}
	public String getBecmDiagnosticsData() {
		return becmDiagnosticsData;
	}
	public String getEsn() {
		return esn;
	}
	public int getVehStrtInhbtBRqBatt() {
		return vehStrtInhbtBRqBatt;
	}
	public String getVin() {
		return vin;
	}
	public void setBattTracIActl(int battTracIActl) {
		this.battTracIActl = battTracIActl;
	}
	public void setBattTracOffBActl(int battTracOffBActl) {
		this.battTracOffBActl = battTracOffBActl;
	}
	
	public void setBattTracOffFstDActl(int battTracOffFstDActl) {
		this.battTracOffFstDActl = battTracOffFstDActl;
	}
	
	public void setBattTracPwLimChrg(int battTracPwLimChrg) {
		this.battTracPwLimChrg = battTracPwLimChrg;
	}
	public void setBattTracPwLimDchrg(int battTracPwLimDchrg) {
		this.battTracPwLimDchrg = battTracPwLimDchrg;
	}
	public void setBattTracSoc2PcActl(int battTracSoc2PcActl) {
		this.battTracSoc2PcActl = battTracSoc2PcActl;
	}
	public void setBattTracTeActl(int battTracTeActl) {
		this.battTracTeActl = battTracTeActl;
	}
	public void setBattTracUActl(int battTracUActl) {
		this.battTracUActl = battTracUActl;
	}
	public void setBecmDiagnosticsData(String becmDiagnosticsData) {
		this.becmDiagnosticsData = becmDiagnosticsData;
	}
	public void setEsn(String esn) {
		this.esn = esn;
	}
	public void setVehStrtInhbtBRqBatt(int vehStrtInhbtBRqBatt) {
		this.vehStrtInhbtBRqBatt = vehStrtInhbtBRqBatt;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
}
