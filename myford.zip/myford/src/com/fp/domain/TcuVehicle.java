package com.fp.domain;

import com.ford.ftcp.FTCP3;

public class TcuVehicle {
	private String esn;
	private int id;
	private String mqttpsw;
	private String psKey;
	private String vin;
	
	private String imei;
	
	private FTCP3.AuthStatusEnum authStatus;
	public FTCP3.AuthStatusEnum getAuthStatus() {
		return authStatus;
	}
	public void setAuthStatus(FTCP3.AuthStatusEnum authStatus) {
		this.authStatus = authStatus;
	}
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	public String getIccid() {
		return iccid;
	}
	public void setIccid(String iccid) {
		this.iccid = iccid;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getSimImsi() {
		return simImsi;
	}
	public void setSimImsi(String simImsi) {
		this.simImsi = simImsi;
	}
	private String iccid;
	private String msisdn;
	private String simImsi;
	
	public String getEsn() {
		return esn;
	}
	public int getId() {
		return id;
	}
	public String getMqttpsw() {
		return mqttpsw;
	}
	public String getPsKey() {
		return psKey;
	}
	public String getVin() {
		return vin;
	}
	public void setEsn(String esn) {
		this.esn = esn;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setMqttpsw(String mqttpsw) {
		this.mqttpsw = mqttpsw;
	}
	public void setPsKey(String psKey) {
		this.psKey = psKey;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
}
