package com.fp.domain;

public class BFDTCInfo {
	private int dtcId;
	public int getDtcId() {
		return dtcId;
	}
	public void setDtcId(int dtcId) {
		this.dtcId = dtcId;
	}
	public int getDtcAdditionalInfo() {
		return dtcAdditionalInfo;
	}
	public void setDtcAdditionalInfo(int dtcAdditionalInfo) {
		this.dtcAdditionalInfo = dtcAdditionalInfo;
	}
	public int getDtcStatus() {
		return dtcStatus;
	}
	public void setDtcStatus(int dtcStatus) {
		this.dtcStatus = dtcStatus;
	}
	private int dtcAdditionalInfo;
	private int dtcStatus;
	
}
