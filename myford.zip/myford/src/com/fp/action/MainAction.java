package com.fp.action;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.struts2.ServletActionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.ford.ftcp.FTCP3.ECUData.ECUStatusEnum;
import com.ford.ftcp.FTCP3.HEVBatteryFaultAlert.HEVBatteryFaultSeverityEnum;
import com.fp.domain.BFDTCInfo;
import com.fp.domain.BatteryFault;
import com.fp.domain.RestLoginUserBean;
import com.fp.domain.TcuFtcpRecord;
import com.fp.domain.TcuVehicle;
import com.fp.domain.VehicleBean;
import com.fp.dto.CommonResult;
import com.fp.service.AzureService;
import com.fp.service.MqttService;
import com.fp.service.RestAPIService;
import com.fp.service.TCUMqttService;
import com.fp.service.VehicleService;
import com.fp.util.ExcelReader;
import com.fp.util.StringUtil;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@Controller
@Scope("prototype")
public class MainAction extends ActionSupport {
	private String errMsgs;

	public String getErrMsgs() {
		return errMsgs;
	}

	public void setErrMsgs(String errMsgs) {
		this.errMsgs = errMsgs;
	}

	class TimerTaskBatteryFault extends TimerTask {

		private String esn;
		private List<Object[]> list;
		private TCUMqttService service;
		private String vin;

		public TimerTaskBatteryFault(List<Object[]> list, String esn,
				String vin, TCUMqttService service) {
			this.list = list;
			this.esn = esn;
			this.vin = vin;
			this.service = service;
		}

		@Override
		public void run() {
			if (list.size() >= 3) {
				Object[] oneRow = list.get(2);
				String HEVBatteryFaultSeverity = oneRow[0].toString();
				String ECUID = oneRow[1].toString();
				String ECUStatus = oneRow[2].toString();
				String DTID1 = oneRow[3].toString();
				String DTCAdditionalInfo1 = oneRow[4].toString();
				String DTCStatus1 = oneRow[5].toString();
				String DTID2 = oneRow[6].toString();
				String DTCAdditionalInfo2 = oneRow[7].toString();
				String DTCStatus2 = oneRow[8].toString();

				BatteryFault batteryFaultBean = new BatteryFault();
				if ("WARNING".equalsIgnoreCase(HEVBatteryFaultSeverity)) {
					batteryFaultBean
							.setHevBatteryFaultSeverity(HEVBatteryFaultSeverityEnum.WARNING);
				} else {
					batteryFaultBean
							.setHevBatteryFaultSeverity(HEVBatteryFaultSeverityEnum.SERVICE);
				}
				batteryFaultBean.setEcuId(StringUtil.hexStr2Int(ECUID));

				// NO_COMMUNICATION = 0; CAN_GDS = 1; GGDS = 2; UNKNOWN = 3;
				if ("NO_COMMUNICATION".equalsIgnoreCase(ECUStatus)) {
					batteryFaultBean
							.setEcuStatus(ECUStatusEnum.NO_COMMUNICATION);
				} else if ("CAN_GDS".equalsIgnoreCase(ECUStatus)) {
					batteryFaultBean.setEcuStatus(ECUStatusEnum.CAN_GDS);
				} else if ("GGDS".equalsIgnoreCase(ECUStatus)) {
					batteryFaultBean.setEcuStatus(ECUStatusEnum.GGDS);
				} else if ("UNKNOWN".equalsIgnoreCase(ECUStatus)) {
					batteryFaultBean.setEcuStatus(ECUStatusEnum.UNKNOWN);
				}

				BFDTCInfo dtcInfo1 = new BFDTCInfo();
				if (null != DTID1 && null != DTCAdditionalInfo1
						&& null != DTCStatus1) {
					dtcInfo1.setDtcId(StringUtil.hexStr2Int(DTID1));
					dtcInfo1.setDtcAdditionalInfo((int) Double
							.parseDouble(DTCAdditionalInfo1));
					dtcInfo1.setDtcStatus((int) Double.parseDouble(DTCStatus1));
				}
				batteryFaultBean.getDtcinfos().add(dtcInfo1);

				BFDTCInfo dtcInfo2 = new BFDTCInfo();
				if (null != DTID2 && null != DTCAdditionalInfo2
						&& null != DTCStatus2) {
					dtcInfo2.setDtcId(StringUtil.hexStr2Int(DTID2));
					dtcInfo2.setDtcAdditionalInfo((int) Double
							.parseDouble(DTCAdditionalInfo2));
					dtcInfo2.setDtcStatus((int) Double.parseDouble(DTCStatus2));
				}
				batteryFaultBean.getDtcinfos().add(dtcInfo2);

				try {
					service.publishTcuBatteryFaultAlert(vin, esn,
							batteryFaultBean);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	class TimerTaskTCU extends TimerTask {
		private String vin;
		private String esn;
		private int index = 0;
		private List<Object[]> list;
		private TCUMqttService service;
		private int total = 0;

		public TimerTaskTCU(List<Object[]> list, String esn, int index,
				int total, TCUMqttService service, String vin) {
			this.list = list;
			this.index = index;
			this.total = total;
			this.service = service;
			this.esn = esn;
			this.vin = vin;
		}

		public String getEsn(List<Object[]> list, String esn, int index,
				int total, TCUMqttService service) {
			return esn;
		}

		@Override
		public void run() {
			String BatterySOC = list.get(1)[index].toString();
			String BatteryVoltage = list.get(2)[index].toString();
			String BatteryCurrent = list.get(3)[index].toString();
			String BatteryTemp = list.get(4)[index].toString();
			String VehicleStartInhibit = list.get(5)[index].toString();
			String BatteryShutdown = list.get(6)[index].toString();
			String BatteryAcceptPower = list.get(7)[index].toString();
			String BatteryProvidePower = list.get(8)[index].toString();
			String BatteryContactorOpen = list.get(9)[index].toString();
			String BatteryServiceRequest = list.get(10)[index].toString();
			String BatteryWarning = list.get(11)[index].toString();
			String VIN = vin;// list.get(12)[index].toString();
			String IgnitionStatus = list.get(13)[index].toString();
			String VehicleSpeed = list.get(14)[index].toString();
			String Mileage = list.get(15)[index].toString();
			String FuelRange = list.get(16)[index].toString();
			String GearLevel = list.get(17)[index].toString();
			String AcceleratorPedalPosition = list.get(18)[index].toString();
			String BrakePedalStatus = list.get(19)[index].toString();
			String EngineSpeed = list.get(20)[index].toString();
			String EngineCoolantTemp = list.get(21)[index].toString();
			String EngineServerRequest = list.get(22)[index].toString();
			String FuelLevel = list.get(23)[index].toString();
			String AmbientAirTemperature = list.get(24)[index].toString();
			String ReferredMotorTorque = list.get(25)[index].toString();
			String PowerStatus = list.get(26)[index].toString();
			String V12VBatterySOC = list.get(27)[index].toString();
			String PositingStatus = list.get(28)[index].toString();
			String Longitude = list.get(29)[index].toString();
			String LongitudeMin = list.get(30)[index].toString();
			String LongitudeMinDec = list.get(31)[index].toString();
			String Latitude = list.get(32)[index].toString();
			String LatitudeMin = list.get(33)[index].toString();
			String LatitudeMinDec = list.get(34)[index].toString();
			String GPSSpeed = list.get(35)[index].toString();
			String TravelDirection = list.get(36)[index].toString();
			String HeadingDegree = list.get(37)[index].toString();

			VehicleBean vehicleBean = new VehicleBean();

			String vin = VIN;
			vehicleBean.setVin(vin);
			vehicleBean.setEsn(esn);

			int GPS_Latitude_Degrees = (int) Double.parseDouble(Latitude);
			int GPS_Latitude_Min_dec = 0;//(int) Double.parseDouble(LatitudeMinDec);// gpsInfo.getLatitude().getGPSLatitudeMinDec();
			int GPS_Latitude_Minutes = (int) Double.parseDouble(LatitudeMin);// gpsInfo.getLatitude().getGPSLatitudeMinutes();

			int GPS_Longitude_Degrees = (int) Double.parseDouble(Longitude);
			int GPS_Longitude_Min_dec = 0;//(int) Double.parseDouble(LongitudeMinDec);// gpsInfo.getLongitude().getGPSLongitudeMinDec();
			int GPS_Longitude_Minutes = (int) Double.parseDouble(LongitudeMin);// gpsInfo.getLongitude().getGPSLongitudeMinutes();

			vehicleBean.setGPS_Latitude_Degrees(GPS_Latitude_Degrees);
			vehicleBean.setGPS_Latitude_Minutes(GPS_Latitude_Minutes);
			vehicleBean.setGPS_Latitude_Min_dec(GPS_Latitude_Min_dec);
			vehicleBean.setGPS_Longitude_Degrees(GPS_Longitude_Degrees);
			vehicleBean.setGPS_Longitude_Minutes(GPS_Longitude_Minutes);
			vehicleBean.setGPS_Longitude_Min_dec(GPS_Longitude_Min_dec);

			// double lat = GPS_Latitude_Degrees + (GPS_Latitude_Minutes +
			// GPS_Latitude_Min_dec*0.0001)/60;
			// vehicleBean.setLat(lat);
			// double lng = GPS_Longitude_Degrees + (GPS_Longitude_Minutes +
			// GPS_Longitude_Min_dec*0.0001)/60;
			// vehicleBean.setLng(lng);

			int GPS_Speed = (int) Double.parseDouble(GPSSpeed);
			vehicleBean.setGPSSpeed(GPS_Speed);
			int GPS_Compass_direction = (int) Double
					.parseDouble(TravelDirection);
			vehicleBean.setGPSCompassDirection(GPS_Compass_direction);
			int GPS_Heading = (int) Double.parseDouble(HeadingDegree);
			vehicleBean.setGPSHeading(GPS_Heading);
			int GPS_actual_vs_infer_pos = (int) Double
					.parseDouble(PositingStatus);
			vehicleBean.setGPSActualVsInferPos(GPS_actual_vs_infer_pos);

			int Ignition_status = (int) Double.parseDouble(IgnitionStatus);
			vehicleBean.setIgnitionStatus(Ignition_status);
			int Veh_V_ActlEng = (int) Double.parseDouble(VehicleSpeed);
			vehicleBean.setVehVActlEng(Veh_V_ActlEng);
			int OdometerMasterValue = (int) Double.parseDouble(Mileage);
			vehicleBean.setOdometerMasterValue(OdometerMasterValue);
			int FuelRange_L_Dsply = (int) Double.parseDouble(FuelRange);
			vehicleBean.setFuelRangeLDsply(FuelRange_L_Dsply);
			int GearLvrPos_D_Actl = (int) Double.parseDouble(GearLevel);
			vehicleBean.setGearLvrPosDActl(GearLvrPos_D_Actl);
			int BpedDrvAppl_D_Actl = (int) Double.parseDouble(BrakePedalStatus);
			vehicleBean.setBpedDrvApplDActl(BpedDrvAppl_D_Actl);
			int ApedPos_Pc_ActlArb = (int) Double
					.parseDouble(AcceleratorPedalPosition);
			vehicleBean.setApedPosPcActlArb(ApedPos_Pc_ActlArb);
			int EngAout_N_Actl = (int) Double.parseDouble(EngineSpeed);
			vehicleBean.setEngAoutNActl(EngAout_N_Actl);
			int EngClnt_Te_Actl = (int) Double.parseDouble(EngineCoolantTemp);
			vehicleBean.setEngClntTeActl(EngClnt_Te_Actl);
			int EngSrvcRqd_B_Rq = (int) Double.parseDouble(EngineServerRequest);
			vehicleBean.setEngSrvcRqdBRq(EngSrvcRqd_B_Rq);
			int FuelLvl_Pc_Dsply = (int) Double.parseDouble(FuelLevel);
			vehicleBean.setFuelLvlPcDsply(FuelLvl_Pc_Dsply);
			int AirAmb_Te_ActlFilt = (int) Double
					.parseDouble(AmbientAirTemperature);
			vehicleBean.setAirAmbTeActlFilt(AirAmb_Te_ActlFilt);
			int PrplWhlTot2_Tq_Actl = (int) Double
					.parseDouble(ReferredMotorTorque);
			vehicleBean.setPrplWhlTot2TqActl(PrplWhlTot2_Tq_Actl);
			int PwPckTq_D_Stat = (int) Double.parseDouble(PowerStatus);
			vehicleBean.setPwPckTqDStat(PwPckTq_D_Stat);
			int BSBattSOC = (int) Double.parseDouble(V12VBatterySOC);
			vehicleBean.setbSBattSOC(BSBattSOC);

			int BattTrac_U_Actl = (int) Double.parseDouble(BatteryVoltage);
			vehicleBean.setBattTracUActl(BattTrac_U_Actl);
			int BattTrac_I_Actl = (int) Double.parseDouble(BatteryCurrent);
			vehicleBean.setBattTracIActl(BattTrac_I_Actl);
			int BattTracSoc2_Pc_Actl = (int) Double.parseDouble(BatterySOC);
			vehicleBean.setBattTracSoc2PcActl(BattTracSoc2_Pc_Actl);
			int BattTrac_Te_Actl = (int) Double.parseDouble(BatteryTemp);
			vehicleBean.setBattTracTeActl(BattTrac_Te_Actl);
			int VehStrtInhbt_B_RqBatt = (int) Double
					.parseDouble(VehicleStartInhibit);
			vehicleBean.setVehStrtInhbtBRqBatt(VehStrtInhbt_B_RqBatt);
			int BattTracOff_B_Actl = (int) Double.parseDouble(BatteryShutdown);
			vehicleBean.setBattTracOffBActl(BattTracOff_B_Actl);
			int BattTrac_Pw_LimChrg = (int) Double
					.parseDouble(BatteryAcceptPower);
			vehicleBean.setBattTracPwLimChrg(BattTrac_Pw_LimChrg);
			int BattTrac_Pw_LimDchrg = (int) Double
					.parseDouble(BatteryProvidePower);
			vehicleBean.setBattTracOffFstDActl(BattTrac_Pw_LimDchrg);
			int BattTracOffFst_D_Actl = (int) Double
					.parseDouble(BatteryContactorOpen);
			vehicleBean.setBattTracOffFstDActl(BattTracOffFst_D_Actl);
			int BattTracWarnLamp_B_Rq = (int) Double
					.parseDouble(BatteryWarning);
			vehicleBean.setBattTracWarnLampBRq(BattTracWarnLamp_B_Rq);
			int BattTracSrvcRqd_B_Rq = (int) Double
					.parseDouble(BatteryServiceRequest);
			vehicleBean.setBattTracSrvcRqdBRq(BattTracSrvcRqd_B_Rq);
			vehicleBean.setInsertDate(new Date());

			try {

				service.publishTcuDataMonitorAlert(vin, esn, vehicleBean);
			} catch (Exception e) {
				e.printStackTrace();
			}
			// service.insertVehicleRecord(vehicleBean);
			if (index == total - 1) {
				this.cancel();
				return;
			}
			index = index + 1;
		}

		public void setEsn(String esn) {
			this.esn = esn;
		}

	}

	private static final long serialVersionUID = 6436559484191982330L;

	RestLoginUserBean apiBean;

	@Autowired
	private AzureService azureService;

	List<BatteryFault> batteryFaultList;

	private String city;

	private int correlateMsgId;

	private String esn;

	private List<TcuVehicle> esnOptions;

	private String fromDate;

	Logger logger = Logger.getLogger(MainAction.class.getName());

	private File mockData; // �ϴ����ļ�

	private File mockDataBatt; // �ϴ����ļ�

	private String mockDataFileName; // �ļ�����

	private String mockDataBattContentType;

	private String mockDataBattFileName; // �ļ�����

	public String getMockDataBattFileName() {
		return mockDataBattFileName;
	}

	public void setMockDataBattFileName(String mockDataBattFileName) {
		this.mockDataBattFileName = mockDataBattFileName;
	}

	private String mockDataContentType; // �ļ�����

	@Autowired
	private MqttService mqttService;

	private String msg;
	private String pskey;

	@Autowired
	private RestAPIService restApiService;

	private List<RestLoginUserBean> restBeans;

	private CommonResult result;

	@Autowired
	private VehicleService service;

	@Autowired
	private TCUMqttService tcuMqttService;

	private List<TcuFtcpRecord> tcuRecordList;

	private String toDate;

	private String typeName;

	VehicleBean vehicleBean;

	private List<VehicleBean> vehicleInfos = new ArrayList<VehicleBean>();

	private String vin;



	public String diagnosticCommand() throws Exception {
		int cloundMessageId = mqttService.publishTcuCommand(vin, esn, pskey);
		result = new CommonResult();
		result.setCloundMessageId(cloundMessageId);
		return SUCCESS;
	}

	public String faultRecord() {
		Object sessionObj = getSessionUsername();
		if (null == sessionObj || "".equals(sessionObj)) {
			return "login";
		}
		esnOptions = azureService.getAllEsns(sessionObj.toString());
		batteryFaultList = service.findAllBatteryFault();
		return SUCCESS;
	}

	public String findAllProCityNullVehicles() {
		vehicleInfos = service.findAllProCityNullVehicles();
		return SUCCESS;
	}

	public String findCityVehicles() {
		vehicleInfos = service.findCityVehicles(city);
		return SUCCESS;
	}

	public RestLoginUserBean getApiBean() {
		return apiBean;
	}

	public AzureService getAzureService() {
		return azureService;
	}

	public List<BatteryFault> getBatteryFaultList() {
		return batteryFaultList;
	}

	public String getCity() {
		return city;
	}

	public int getCorrelateMsgId() {
		return correlateMsgId;
	}

	public String getEsn() {
		return esn;
	}

	public List<TcuVehicle> getEsnOptions() {
		return esnOptions;
	}

	public String getFromDate() {
		return fromDate;
	}

	public File getMockData() {
		return mockData;
	}

	public File getMockDataBatt() {
		return mockDataBatt;
	}

	public String getMockDataBattContentType() {
		return mockDataBattContentType;
	}

	public String getMockDataContentType() {
		return mockDataContentType;
	}

	public String getMockDataFileName() {
		return mockDataFileName;
	}

	public MqttService getMqttService() {
		return mqttService;
	}

	public String getMsg() {
		return msg;
	}

	public String getPskey() {
		return pskey;
	}

	public String getRestApiDailyCounting() {
		apiBean = restApiService.selectFailSuccessPercent(typeName, fromDate,
				toDate);
		return SUCCESS;
	}

	public String getRestApiPerformance() {
		restBeans = restApiService.selectPerformanceByType(typeName, fromDate,
				toDate);
		return SUCCESS;
	}

	public RestAPIService getRestApiService() {
		return restApiService;
	}

	public List<RestLoginUserBean> getRestBeans() {
		return restBeans;
	}

	public CommonResult getResult() {
		return result;
	}

	public VehicleService getService() {
		return service;
	}

	public TCUMqttService getTcuMqttService() {
		return tcuMqttService;
	}

	public List<TcuFtcpRecord> getTcuRecordList() {
		return tcuRecordList;
	}

	public String getToDate() {
		return toDate;
	}

	public String getTypeName() {
		return typeName;
	}

	public VehicleBean getVehicleBean() {
		return vehicleBean;
	}

	public List<VehicleBean> getVehicleInfos() {
		return vehicleInfos;
	}

	public String getVin() {
		return vin;
	}

	public String groupCityVehCnt() {
		vehicleInfos = service.findCityVehicleCnt();
		return SUCCESS;
	}

	public String historyQuery() {
		vehicleInfos = service.findAllVehicles();
		return SUCCESS;
	}

	public String home() {
		return SUCCESS;
	}

	public String homeMapMain() {
		vehicleInfos = service.findAllVehicles();
		// mqttService.initMQTT();
		return SUCCESS;
	}

	public String remoteDiagnostic() {
		return SUCCESS;
	}

	public String restapi() {
		return SUCCESS;
	}

	public String rspAlertFromTcu() {
		tcuRecordList = service.selectTcuRecordByCorid(correlateMsgId);
		return SUCCESS;
	}

	public String searchByVin() {
		// VehicleBean bean = new VehicleBean();
		// bean.setLat(39.907761);
		// bean.setLng(116.415467);
		// bean.setVin("5LMCJ2A90FUJ00101");

		vehicleInfos = service.findVehicleByVin(vin);

		// vehicleInfos.add(bean);

		return SUCCESS;
	}

	public void setApiBean(RestLoginUserBean apiBean) {
		this.apiBean = apiBean;
	}

	public void setAzureService(AzureService azureService) {
		this.azureService = azureService;
	}

	public void setBatteryFaultList(List<BatteryFault> batteryFaultList) {
		this.batteryFaultList = batteryFaultList;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setCorrelateMsgId(int correlateMsgId) {
		this.correlateMsgId = correlateMsgId;
	}

	public void setEsn(String esn) {
		this.esn = esn;
	}

	public void setEsnOptions(List<TcuVehicle> esnOptions) {
		this.esnOptions = esnOptions;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public void setMockData(File mockData) {
		this.mockData = mockData;
	}

	public void setMockDataBatt(File mockDataBatt) {
		this.mockDataBatt = mockDataBatt;
	}

	public void setMockDataBattContentType(String mockDataBattContentType) {
		this.mockDataBattContentType = mockDataBattContentType;
	}

	public void setMockDataContentType(String mockDataContentType) {
		this.mockDataContentType = mockDataContentType;
	}

	public void setMockDataFileName(String mockDataFileName) {
		this.mockDataFileName = mockDataFileName;
	}

	public void setMqttService(MqttService mqttService) {
		this.mqttService = mqttService;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public void setPskey(String pskey) {
		this.pskey = pskey;
	}

	public void setRestApiService(RestAPIService restApiService) {
		this.restApiService = restApiService;
	}

	public void setRestBeans(List<RestLoginUserBean> restBeans) {
		this.restBeans = restBeans;
	}

	public void setResult(CommonResult result) {
		this.result = result;
	}

	public void setService(VehicleService service) {
		this.service = service;
	}

	public void setTcuMqttService(TCUMqttService tcuMqttService) {
		this.tcuMqttService = tcuMqttService;
	}

	public void setTcuRecordList(List<TcuFtcpRecord> tcuRecordList) {
		this.tcuRecordList = tcuRecordList;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public void setVehicleBean(VehicleBean vehicleBean) {
		this.vehicleBean = vehicleBean;
	}

	public void setVehicleInfos(List<VehicleBean> vehicleInfos) {
		this.vehicleInfos = vehicleInfos;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String updProvinceCity() {
		logger.info("province: " + vehicleBean.getProvince() + " , city: "
				+ vehicleBean.getCity());
		if (service.updateVehicle(vehicleBean) > 0) {
			msg = "SUCCESS";
		}
		return SUCCESS;
	}



	public String vehicleDetail() {
		vehicleInfos = service.findAllVehicles();
		/*
		 * vehicleInfos = service.findVehicleByVin(vin);
		 * 
		 * HttpServletRequest request = ServletActionContext.getRequest();
		 * String realPath =
		 * request.getSession().getServletContext().getRealPath("/");
		 * 
		 * DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		 * 
		 * for (VehicleBean bean : vehicleInfos) {
		 * dataset.addValue(bean.getGPSSpeed(), "GPS_Speed",
		 * bean.getInsertDate()); dataset.addValue(bean.getGPSHeading(),
		 * "GPS_Heading", bean.getInsertDate()); }
		 * 
		 * try { JFreeChartUtil.GenerateLine(realPath + "upload\\vinchart_" +
		 * vin +".jpg", "", "X", "Y", dataset); } catch (IOException e) {
		 * e.printStackTrace(); }
		 */

		return SUCCESS;
	}

	public String vehicleDetailAjax() throws Exception {
		vehicleInfos = service.findVehicleByVin(vin);

		// HttpServletRequest request = ServletActionContext.getRequest();
		// String realPath = request.getSession().getServletContext()
		// .getRealPath("/");
		//
		// DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		// SimpleDateFormat XDateFormat = new SimpleDateFormat("HH:mm:ss");
		//
		// for (VehicleBean bean : vehicleInfos) {
		// dataset.addValue(bean.getGPSSpeed(), "GPS_Speed",
		// XDateFormat.format(bean.getInsertDate()));
		// }
		//
		// JFreeChartUtil.GenerateLine(realPath + "upload\\GPS_Speed_" + vin
		// + ".jpg", "", "Monitor Time", "GPS Speed(m/h)", dataset);
		//
		// dataset = new DefaultCategoryDataset();
		//
		// for (VehicleBean bean : vehicleInfos) {
		//
		// dataset.addValue(bean.getGPSHeading(), "GPS_Heading",
		// XDateFormat.format(bean.getInsertDate()));
		// }
		//
		// JFreeChartUtil.GenerateLine(realPath + "upload\\GPS_Heading_" + vin
		// + ".jpg", "", "Monitor Time", "GPS Heading(degree)", dataset);

		return SUCCESS;
	}

	private String username;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	private String password;
	
	public String login() {
		result = new CommonResult();
		if (null == username || null == password || "".equals(username) || "".equals(password)) {

			result.setSuccess(false);
			result.setMsg("Please input name and password.");
			return SUCCESS;
		}
		boolean isExistsUser = tcuMqttService.isExistsUser(username, password);
		if (isExistsUser) {
			ActionContext actionContext = ActionContext.getContext();
			Map<String, Object> session = actionContext.getSession();
			session.put("USER_NAME", username);
			result.setSuccess(true);
		} else {
			result.setSuccess(false);
			result.setMsg("Name or password is not correct.");
		}
		return SUCCESS;
	}
	
	public String clearBatteryFaultAlert() {
		if (esn == null || esn.equals("")) {
			return ERROR;
		}
		Object sessionObj = getSessionUsername();
		if (null == sessionObj || "".equals(sessionObj)) {
			return "login";
		}
		esnOptions = azureService.getAllEsns(sessionObj.toString());
		try {
			BatteryFault batteryFaultBean = new BatteryFault();
			batteryFaultBean.setEcuId(0);
			batteryFaultBean.setEcuStatus(ECUStatusEnum.CAN_GDS);
			errMsgs = tcuMqttService.publishClearBatteryFaultAlert(vin, esn, batteryFaultBean);
		} catch (Exception e) {
			errMsgs = errMsgs + StringUtil.getStackMsg(e);
		}
		return SUCCESS;
	}
	
	public String batteryFaultAlert() {
		if (esn == null || esn.equals("")) {
			return ERROR;
		}
		Object sessionObj = getSessionUsername();
		if (null == sessionObj || "".equals(sessionObj)) {
			return "login";
		}
		// tcuMqttService.initMQTT();
		esnOptions = azureService.getAllEsns(sessionObj.toString());
		try {
			String realpath = ServletActionContext.getServletContext()
					.getRealPath("/upload");
			UUID uuid = UUID.randomUUID();
			String realFilePath = realpath + uuid.toString()
					+ this.mockDataBattFileName;
			File savefile = new File(realFilePath);
			if (!savefile.getParentFile().exists())
				savefile.getParentFile().mkdirs();
			FileUtils.copyFile(this.mockDataBatt, savefile);

			Workbook wb = ExcelReader.createWb(realFilePath);

			// ��ȡWorkbook��Sheet����
			int sheetTotal = wb.getNumberOfSheets();
			System.out.println("sheetTotal: " + sheetTotal);
			// ��ȡSheet
			Sheet sheet = ExcelReader.getSheet(wb, 0);

			// ����Sheet, ����������38�оͽ���
			List<Object[]> list = ExcelReader.listFromSheet(sheet, 38);

			if (list.size() >= 3) {
				Object[] oneRow = list.get(2);
				
				String BATTTRAC_U_ACTL_R = oneRow[0].toString();
				String BATTTRAC_I_ACTL_R = oneRow[1].toString();
				String BATTTRACSOC2_PC_ACTL_R = oneRow[2].toString();
				String BATTTRAC_TE_ACTL_R = oneRow[3].toString();
				String VEHSTRTINHBT_B_RQBATT_R = oneRow[4].toString();
				String BATTTRACOFF_B_ACTL_R = oneRow[5].toString();
				String BATTTRAC_PW_LIMCHRG_R = oneRow[6].toString();
				String BATTTRAC_PW_LIMDCHRG_R = oneRow[7].toString();
				String BATTTRACOFFFST_D_ACTL_R = oneRow[8].toString();
				
				String HEVBatteryFaultSeverity = oneRow[9].toString();
				String ECUID = oneRow[10].toString();
				String ECUStatus = oneRow[11].toString();
				String DTID1 = oneRow[12].toString();
				String DTCAdditionalInfo1 = oneRow[13].toString();
				String DTCStatus1 = oneRow[14].toString();
				String DTID2 = oneRow[15].toString();
				String DTCAdditionalInfo2 = oneRow[16].toString();
				String DTCStatus2 = oneRow[17].toString();

				BatteryFault batteryFaultBean = new BatteryFault();
				
				batteryFaultBean.setBattTracUActl(BATTTRAC_U_ACTL_R.toLowerCase().contains("0x") ? StringUtil.hexStr2Int(BATTTRAC_U_ACTL_R) : (int) Double
						.parseDouble(BATTTRAC_U_ACTL_R));//voltage
				batteryFaultBean.setBattTracIActl(BATTTRAC_I_ACTL_R.toLowerCase().contains("0x") ? StringUtil.hexStr2Int(BATTTRAC_I_ACTL_R) : (int) Double
						.parseDouble(BATTTRAC_I_ACTL_R));//current
				batteryFaultBean.setBattTracSoc2PcActl(BATTTRACSOC2_PC_ACTL_R.toLowerCase().contains("0x") ? StringUtil.hexStr2Int(BATTTRACSOC2_PC_ACTL_R) : (int) Double
						.parseDouble(BATTTRACSOC2_PC_ACTL_R));// SOC
				batteryFaultBean.setBattTracTeActl(BATTTRAC_TE_ACTL_R.toLowerCase().contains("0x") ? StringUtil.hexStr2Int(BATTTRAC_TE_ACTL_R) : (int) Double
						.parseDouble(BATTTRAC_TE_ACTL_R));//temperature
				batteryFaultBean.setVehStrtInhbtBRqBatt(VEHSTRTINHBT_B_RQBATT_R.toLowerCase().contains("0x") ? StringUtil.hexStr2Int(VEHSTRTINHBT_B_RQBATT_R) : (int) Double
						.parseDouble(VEHSTRTINHBT_B_RQBATT_R));// inhibit
				batteryFaultBean.setBattTracOffBActl(BATTTRACOFF_B_ACTL_R.toLowerCase().contains("0x") ? StringUtil.hexStr2Int(BATTTRACOFF_B_ACTL_R) : (int) Double
						.parseDouble(BATTTRACOFF_B_ACTL_R));//shutdown or about to shutdown
				batteryFaultBean.setBattTracPwLimChrg(BATTTRAC_PW_LIMCHRG_R.toLowerCase().contains("0x") ? StringUtil.hexStr2Int(BATTTRAC_PW_LIMCHRG_R) : (int) Double
						.parseDouble(BATTTRAC_PW_LIMCHRG_R));
				batteryFaultBean.setBattTracPwLimDchrg(BATTTRAC_PW_LIMDCHRG_R.toLowerCase().contains("0x") ? StringUtil.hexStr2Int(BATTTRAC_PW_LIMDCHRG_R) : (int) Double
						.parseDouble(BATTTRAC_PW_LIMDCHRG_R));
				batteryFaultBean.setBattTracOffFstDActl(BATTTRACOFFFST_D_ACTL_R.toLowerCase().contains("0x") ? StringUtil.hexStr2Int(BATTTRACOFFFST_D_ACTL_R) : (int) Double
						.parseDouble(BATTTRACOFFFST_D_ACTL_R));
				
				if ("WARNING".equalsIgnoreCase(HEVBatteryFaultSeverity)) {
					batteryFaultBean
							.setHevBatteryFaultSeverity(HEVBatteryFaultSeverityEnum.WARNING);
				} else {
					batteryFaultBean
							.setHevBatteryFaultSeverity(HEVBatteryFaultSeverityEnum.SERVICE);
				}
				batteryFaultBean.setEcuId(StringUtil.hexStr2Int(ECUID));

				// NO_COMMUNICATION = 0; CAN_GDS = 1; GGDS = 2; UNKNOWN = 3;
				if ("NO_COMMUNICATION".equalsIgnoreCase(ECUStatus)) {
					batteryFaultBean
							.setEcuStatus(ECUStatusEnum.NO_COMMUNICATION);
				} else if ("CAN_GDS".equalsIgnoreCase(ECUStatus)) {
					batteryFaultBean.setEcuStatus(ECUStatusEnum.CAN_GDS);
				} else if ("GGDS".equalsIgnoreCase(ECUStatus)) {
					batteryFaultBean.setEcuStatus(ECUStatusEnum.GGDS);
				} else if ("UNKNOWN".equalsIgnoreCase(ECUStatus)) {
					batteryFaultBean.setEcuStatus(ECUStatusEnum.UNKNOWN);
				}

				BFDTCInfo dtcInfo1 = new BFDTCInfo();
				if (null != DTID1 && null != DTCAdditionalInfo1
						&& null != DTCStatus1) {
					dtcInfo1.setDtcId(StringUtil.hexStr2Int(DTID1));
					dtcInfo1.setDtcAdditionalInfo((int) Double
							.parseDouble(DTCAdditionalInfo1));
					dtcInfo1.setDtcStatus((int) Double.parseDouble(DTCStatus1));
				}
				batteryFaultBean.getDtcinfos().add(dtcInfo1);

				BFDTCInfo dtcInfo2 = new BFDTCInfo();
				if (null != DTID2 && null != DTCAdditionalInfo2
						&& null != DTCStatus2) {
					dtcInfo2.setDtcId(StringUtil.hexStr2Int(DTID2));
					dtcInfo2.setDtcAdditionalInfo((int) Double
							.parseDouble(DTCAdditionalInfo2));
					dtcInfo2.setDtcStatus((int) Double.parseDouble(DTCStatus2));
				}
				batteryFaultBean.getDtcinfos().add(dtcInfo2);
				errMsgs = tcuMqttService.publishTcuBatteryFaultAlert(vin, esn,
						batteryFaultBean);
			}

		} catch (Exception e) {
			errMsgs = errMsgs + StringUtil.getStackMsg(e);
		}
		return SUCCESS;

		/*
		 * tcuMqttService.publishTcuBatteryFaultAlert(vin, esn, pskey); //
		 * result = new CommonResult(); // result.setSuccess(true); //
		 * result.setMsg("publish to MQTT success."); return SUCCESS;
		 */
	}
	
	public String uploadMockData() {
		if (esn == null || esn.equals("")) {
			return ERROR;
		}
		Object sessionObj = getSessionUsername();
		if (null == sessionObj || "".equals(sessionObj)) {
			return "login";
		}
		
		esnOptions = azureService.getAllEsns(sessionObj.toString());
		try {
			String realpath = ServletActionContext.getServletContext()
					.getRealPath("/upload");
			UUID uuid = UUID.randomUUID();
			String realFilePath = realpath + uuid.toString()
					+ this.mockDataFileName;
			File savefile = new File(realFilePath);
			if (!savefile.getParentFile().exists())
				savefile.getParentFile().mkdirs();
			FileUtils.copyFile(this.mockData, savefile);

			Workbook wb = ExcelReader.createWb(realFilePath);

			// ��ȡWorkbook��Sheet����
			int sheetTotal = wb.getNumberOfSheets();
			System.out.println("sheetTotal: " + sheetTotal);
			// ��ȡSheet
			Sheet sheet = ExcelReader.getSheet(wb, 0);

			// ����Sheet, ����������38�оͽ���
			List<Object[]> list = ExcelReader.listFromSheet(sheet, 38);

			if (list.size() > 1) {
				Date date = new Date();
				GregorianCalendar baseCal = new GregorianCalendar();
				baseCal.setTime(date);

				Timer timer = new Timer();
				int total = list.get(1).length;
				int index = 8;
				int timeInterval = 20000;
				
				errMsgs = "HEV Data Monitor Alert will send every " + (timeInterval/1000) + ", please check SDN storage alert to find alert status.";
				timer.schedule(new TimerTaskTCU(list, esn, index, total,
						tcuMqttService, vin), 0, timeInterval);

			}
		} catch (Exception e) {
			errMsgs = errMsgs + StringUtil.getStackMsg(e);
		}
		return SUCCESS;
	}
	
	private Object getSessionUsername() {
		ActionContext actionContext = ActionContext.getContext();
		Map<String, Object> session = actionContext.getSession();
		Object unameObj = session.get("USER_NAME");
		return unameObj;
	}
	
	public String tcu() throws Exception {
		Object sessionObj = getSessionUsername();
		if (null == sessionObj || "".equals(sessionObj)) {
			return "login";
		}
		esnOptions = azureService.getAllEsns(sessionObj.toString());
		if (esnOptions.size()>0) {
			vin = esnOptions.get(0).getVin();
		}
		return SUCCESS;
	}

	public String publishProvisioningAlert() {
		if (this.esn == null || this.vin == null) {
			return ERROR;
		}
		
		Object sessionObj = getSessionUsername();
		if (null == sessionObj || "".equals(sessionObj)) {
			return "login";
		}
		
		esnOptions = azureService.getAllEsns(sessionObj.toString());
		
		try {
			errMsgs = tcuMqttService.publishProvisioningALert(vin, esn);
		} catch (Exception e) {
			errMsgs = errMsgs + StringUtil.getStackMsg(e);
		}

		return SUCCESS;
	}
	
	public String logout() {
		ActionContext actionContext = ActionContext.getContext();
		Map<String, Object> session = actionContext.getSession();
		session.put("USER_NAME", "");
		return "login";
	}
}
