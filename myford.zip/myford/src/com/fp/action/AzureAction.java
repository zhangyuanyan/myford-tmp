package com.fp.action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.fp.action.tools.AlertEntity;
import com.fp.action.tools.CommandEntity;
import com.fp.action.tools.ResponseEntity;
import com.fp.domain.TcuVehicle;
import com.fp.service.AzureService;
import com.fp.util.Constants;
import com.fp.util.RestfulMainHttpsUtil;
import com.opensymphony.xwork2.ActionSupport;

@Controller
@Scope("prototype")
public class AzureAction extends ActionSupport {
	private static final long serialVersionUID = -1709522344665842891L;
	private String esn;
	private String dbaddress;
	public String getDbaddress() {
		return dbaddress;
	}

	public void setDbaddress(String dbaddress) {
		this.dbaddress = dbaddress;
	}

	public String getDbname() {
		return dbname;
	}

	public void setDbname(String dbname) {
		this.dbname = dbname;
	}

	public String getDbaccount() {
		return dbaccount;
	}

	public void setDbaccount(String dbaccount) {
		this.dbaccount = dbaccount;
	}

	public String getDbpassword() {
		return dbpassword;
	}

	public void setDbpassword(String dbpassword) {
		this.dbpassword = dbpassword;
	}

	private String dbname;
	private String dbaccount;
	private String dbpassword;
	
	private String accountName;
	private List<TcuVehicle> esnOptions;

	public List<TcuVehicle> getEsnOptions() {
		return esnOptions;
	}

	public void setEsnOptions(List<TcuVehicle> esnOptions) {
		this.esnOptions = esnOptions;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountKey() {
		return accountKey;
	}

	public void setAccountKey(String accountKey) {
		this.accountKey = accountKey;
	}

	private String accountKey;
	public String getEsn() {
		return esn;
	}

	public void setEsn(String esn) {
		this.esn = esn;
	}

	@Autowired
	private AzureService service;
	
	public AzureService getService() {
		return service;
	}

	public void setService(AzureService service) {
		this.service = service;
	}
	List<AlertEntity> alerts;
	List<ResponseEntity> responses;
	public List<ResponseEntity> getResponses() {
		return responses;
	}

	public void setResponses(List<ResponseEntity> responses) {
		this.responses = responses;
	}

	public List<AlertEntity> getAlerts() {
		return alerts;
	}

	public void setAlerts(List<AlertEntity> alerts) {
		this.alerts = alerts;
	}

	public String getAlert() {
		esnOptions = service.getAllEsns("");
		if (null != esn && null != accountKey && null != accountName) {
			//accountKey = "LYHVkO2Qy+Qq3eUCnVlSdPSIK3p0iIeMgH9HkttSSqgblarvhEyx80gi7WVvV481CEGDUOXLwdxX3yUaPfT67g==";
			alerts = service.getAzureAlerts(esn, accountName, accountKey);
		}
		return SUCCESS;
	}
	
	public String getResponse() {
		esnOptions = service.getAllEsns("");
		if (null != esn && null != accountKey && null != accountName) {
			//accountKey = "LYHVkO2Qy+Qq3eUCnVlSdPSIK3p0iIeMgH9HkttSSqgblarvhEyx80gi7WVvV481CEGDUOXLwdxX3yUaPfT67g==";
			responses = service.getAzureResponses(esn, accountName, accountKey);
		}
		return SUCCESS;
	}
	private String username;
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	private String password;
	private String lhToken;
	public String getLhToken() {
		return lhToken;
	}

	public void setLhToken(String lhToken) {
		this.lhToken = lhToken;
	}

	public String getLHToken() throws Exception {
		if (null != username && null != password) {
			lhToken = RestfulMainHttpsUtil.loginLightHouse(Constants.LIGHT_HOUSE_URL, username, password);
		}
		return SUCCESS;
	}
	
	private List<CommandEntity> commands;
	public List<CommandEntity> getCommands() {
		return commands;
	}

	public void setCommands(List<CommandEntity> commands) {
		this.commands = commands;
	}

	public String getCommand() {
		esnOptions = service.getAllEsns("");
		if (null != esn && null != dbaddress && null != dbname && null != dbaccount && null != dbpassword) {
			commands = service.getAzureCommands(esn, dbaddress, dbname, dbaccount, dbpassword);
		}
		return SUCCESS;
	}
}
