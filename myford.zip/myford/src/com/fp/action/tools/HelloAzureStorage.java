package com.fp.action.tools;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONObject;

import com.ford.ftcp.FTCP3.TCUAlert;
import com.ford.ftcp.FTCP3.TCUConnectionStatusAlert;
import com.ford.ftcp.util.SyncpUtil;
import com.google.protobuf.InvalidProtocolBufferException;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.table.CloudTable;
import com.microsoft.azure.storage.table.CloudTableClient;
import com.microsoft.azure.storage.table.TableQuery;
import com.microsoft.azure.storage.table.TableQuery.QueryComparisons;

public class HelloAzureStorage {
	public static final String storageConnectionString = 
		    "DefaultEndpointsProtocol=http;" + 
		    "TableEndpoint=http://fcnetelem1qa.table.core.chinacloudapi.cn;" +
		    "AccountName=fcnetelem1qa;" + 
		    "AccountKey=jCqNIZC4p3n5LXMJLxctUNRA52h+q/yElCBtf6NPXh09KIeu4aHVaeHyrFfcZP+HevXahxSPWtsgS9NndokZSA==";
	public final static String PARTITION_KEY = "PartitionKey";
	public final static String ROW_KEY = "RowKey";
	public final static String TIMESTAMP = "Timestamp";
	public final static String FROM = "From";
	
	public static List<AlertEntity> getAzureAlerts(String esn) {
		List<AlertEntity> retList = new ArrayList<AlertEntity>();
		try
		{
		    // Retrieve storage account from connection-string.
		    CloudStorageAccount storageAccount =
		       CloudStorageAccount.parse(storageConnectionString);

		    // Create the table client.
		    CloudTableClient tableClient = storageAccount.createCloudTableClient();

		    // Loop through the collection of table names.
		    for (String table : tableClient.listTables())
		    {
		      // Output each table name.
		      System.out.println(table);
		    }
		    
		    // Create a cloud table object for the table.
		    CloudTable cloudTable = tableClient.getTableReference("alert");

		  
		     // Create a filter condition where the partition key is "Smith".
		     String partitionFilter = TableQuery.generateFilterCondition(
								    	FROM, 
								        QueryComparisons.EQUAL,
								        esn);

		    // Specify a partition query, using "Smith" as the partition key filter.
		    TableQuery<AlertEntity> partitionQuery =
		        TableQuery.from(AlertEntity.class)
		        .where(partitionFilter);

		     // Loop through the results, displaying information about the entity.
		     for (AlertEntity entity : cloudTable.execute(partitionQuery)) {
		    	 retList.add(entity);
//		         System.out.println(entity.getPartitionKey() +
//		             " " + entity.getRowKey() + " " + entity.getFrom() + " " +entity.getOpCode() + " "+entity.getPayload());
		         byte[] syncpBytes = hexStringToBytes(bytesToHexString(Base64.decodeBase64(entity.getPayload())));
		         //System.out.println(entity.getEnqueuedTimeUtc() + " "+bytesToHexString(Base64.decodeBase64(entity.getPayload())));
		         
		         System.out.println(new String(syncpBytes, "utf-8"));
		         
//		         byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(
//							syncpBytes, "gGQgP5vIC+QnsHiHM6pcuw==");
//		         TCUConnectionStatusAlert alert = TCUConnectionStatusAlert.parseFrom(decodedBytes);
//					System.out.println(alert);
		    }
		}
		catch (Exception e)
		{
		    // Output the stack trace.
		    e.printStackTrace();
		}
		return retList;
	}
	
	public static String bytesToHexString(byte[] src) {
		StringBuilder stringBuilder = new StringBuilder("");
		if (src == null || src.length <= 0) {
			return null;
		}
		for (int i = 0; i < src.length; i++) {
			int v = src[i] & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}
		return stringBuilder.toString();
	}
	
	public static byte[] hexStringToBytes(String hexString) {
		if (hexString == null || hexString.equals("")) {
			return null;
		}
		hexString = hexString.toUpperCase();
		int length = hexString.length() / 2;
		char[] hexChars = hexString.toCharArray();
		byte[] d = new byte[length];
		for (int i = 0; i < length; i++) {
			int pos = i * 2;
			d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
		}
		return d;
	}
	
	private static byte charToByte(char c) {
		return (byte) "0123456789ABCDEF".indexOf(c);
	}
	
	public static void main(String[] args) throws Exception {
		//getAzureAlerts("T4860029");
        /*String tmp = "DwAAAAABwVQ1MVcwMDA4q/Ala0LQNr42Au36eeqAj4Dv0w/B0dhcL2J0HLbdIGF6QGxd8pfrPtUqghAMS/nRpV3M0SZACMfhMpL0HopNWR3AIUgkgv4fk6V08Bvkln65y9mGBD7yQQ4nF59lEZQVoWvjgwhXW3SV3yqy45NA0ZNeFayGpYT0CXN67I6VDMhiCy10dwbn8bLukpukspHnp/tI0U2gn/BgSWCJRtSGUI5sZ030NDBOjzpIC9puzhv7PKScFA41EmPErZxlBzLpfe+k/ZihFG3zcL54e1gFiqSeLz5KcNqLS2fPMtHdVWMoIm7g2i0RlfZWmzoGrA3WM9tLFOwsfUmFx9VsbybPNMM5cH9JqueWqbkMU3koGPcNtsUjfv2FSxbLlvbgfNGuEFBQLbJx2W2r9QdnJrDIXvC3cXMkJOhR1OPcm2jdPZu0oyF68fhcQluFWNyqZodMjsRDFzOUCkJtDlKNgm2g/Y35r5ivuuu0jhKHnceXCeQT7NplAOIVhO9437KO2JPGNekfPDo6la3T3Z8WyNB9ihZASddhYLh+vLebAJi6oCqid/pceyOQwQ3ZFFcZVgKn2NOhh0pTAXTnwAQM3g3/j6qft5wyKYK1LU88QAdoeYegbQpDW7QWWL59gbPyO6Zv4g==";
        byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(
       		 hexStringToBytes(bytesToHexString(Base64.decodeBase64(tmp))), "7u6dPKtNdd1h/t/myOKNHQ==");
        System.out.println(TCUConnectionStatusAlert.parseFrom(decodedBytes));*/
        
        
		String tmp = "eyJtZXNzYWdlIjoiRHdRUUFBQUE4MVEwT0RZd01ESTVNVEU0TkRJM05qRUF6TXpNek16TXpDeGdWcWRBU3A1Z0dYRGhlV1MwZTFGeGZBTURpbEkwcjN2ZWhteW8wQlc2Q1dRdm1mWk1hdWN5SkRJbWY2eVV4Zmh5MzQ2YTV1dVV3OFVDcUNXUElLWWptdW5TSDc1dzJCU2I0UEM2eFZCOFBXTEJkb3krdXZxQkZ5WlBvRk8vOTdsR0VzbUlzSmF0TWMyK2NSbHVPZjNJNmRFcElEWEtTUTYyWTNzS1Z6NXc0V3BqWTZiSHNkOE9QaGw2L0RJR00wNldtWngrQXhrSzdlbU9nSTNYRHh4MVgrTGk2ajFMa0xuendZd3JHbFF4VllyWGhrTzJzUmtWNHpEUmdZN1laaHJna3FtaXFvS0JsUzkxS1dTVmlhcVdMZExvcEl0RkpIOExXRVh0WVRIem5RNzB5bFl1VDFacGQrWEhJdlJoYnVBWExBL1ppYTFxbjZGV01TaU42aC84WnVRPSJ9";
        byte[] syncpBytes = SyncpUtil.hexStringToBytes(SyncpUtil
				.bytesToHexString(Base64.decodeBase64(tmp)));
		String jsonMessage = new String(syncpBytes, "utf-8");
		String messageVal = new JSONObject(jsonMessage).getString("message");
		
		System.out.println(messageVal);
		
		byte[] decodedBytes = SyncpUtil.decodeSyncpPacket(Base64.decodeBase64(messageVal), "h7Qx9UVgF2jPJJPSLKIpKg==");
		
		System.out.println(TCUAlert.parseFrom(decodedBytes));
		
		//System.out.println("alert: " + TCUAlert.parseFrom(decodedBytes));
		/*try
		{
		    // Retrieve storage account from connection-string.
		    CloudStorageAccount storageAccount =
		       CloudStorageAccount.parse(storageConnectionString);

		    // Create the table client.
		    CloudTableClient tableClient = storageAccount.createCloudTableClient();

		    // Loop through the collection of table names.
		    for (String table : tableClient.listTables())
		    {
		      // Output each table name.
		      System.out.println(table);
		    }
		    
		    // Create a cloud table object for the table.
		    CloudTable cloudTable = tableClient.getTableReference("alert");

		     // Create a filter condition where the partition key is "Smith".
		     String partitionFilter = TableQuery.generateFilterCondition(
		        PARTITION_KEY, 
		        QueryComparisons.EQUAL,
		        "635602920000000000");

		    // Specify a partition query, using "Smith" as the partition key filter.
		    TableQuery<AlertEntity> partitionQuery =
		        TableQuery.from(AlertEntity.class)
		        .where(partitionFilter);

		     // Loop through the results, displaying information about the entity.
		     for (AlertEntity entity : cloudTable.execute(partitionQuery)) {
		         System.out.println(entity.getPartitionKey() +
		             " " + entity.getRowKey() + " " + entity.getFrom() + " " +entity.get__payload());
		    }
		}
		catch (Exception e)
		{
		    // Output the stack trace.
		    e.printStackTrace();
		}*/
	}

}
