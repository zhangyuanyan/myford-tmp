package com.fp.action.tools;
import java.util.Date;

import com.microsoft.azure.storage.table.TableServiceEntity;


public class ResponseEntity extends TableServiceEntity{
	private String __payload;
	private String payload;
	
	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	private String decodedPayLoad;
	public String getDecodedPayLoad() {
		return decodedPayLoad;
	}

	public void setDecodedPayLoad(String decodedPayLoad) {
		this.decodedPayLoad = decodedPayLoad;
	}

	private Date enqueuedTimeUtc;
	public String get__payload() {
		return __payload;
	}

	public void set__payload(String __payload) {
		this.__payload = __payload;
	}

	public Date getEnqueuedTimeUtc() {
		return enqueuedTimeUtc;
	}

	public void setEnqueuedTimeUtc(Date enqueuedTimeUtc) {
		this.enqueuedTimeUtc = enqueuedTimeUtc;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getOpCode() {
		return opCode;
	}

	public void setOpCode(String opCode) {
		this.opCode = opCode;
	}

	public Date getReceived() {
		return received;
	}

	public void setReceived(Date received) {
		this.received = received;
	}

	public Date getSys_ExpiresAtUtc() {
		return sys_ExpiresAtUtc;
	}

	public void setSys_ExpiresAtUtc(Date sys_ExpiresAtUtc) {
		this.sys_ExpiresAtUtc = sys_ExpiresAtUtc;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	private String from;
	private String opCode;
	private String opcode;
	public String getOpcode() {
		return opcode;
	}

	public void setOpcode(String opcode) {
		this.opcode = opcode;
	}

	private Date received;

	private Date sys_ExpiresAtUtc;

	private Date time;

	
}
