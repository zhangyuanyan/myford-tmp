package com.fp.action.tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HelloSQLAzure {

	public static void main(String[] args) {
		
		List<CommandEntity> commands = new ArrayList<CommandEntity>();
		String connectionString = "jdbc:sqlserver://pjydjzealg.database.chinacloudapi.cn:1433"
				+ ";"
				+ "database=sdn"
				+ ";"
				+ "user=sdnGuest"
				+ ";"
				+ "password=password~1";
		String esn = "T4CF0040";
		// The types for the following variables are
		// defined in the java.sql library.
		Connection connection = null; // For making the connection
		PreparedStatement pstatement = null; // For the SQL statement
		ResultSet resultSet = null; // For the result set, if applicable

		try {
			// Ensure the SQL Server driver class is available.
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			// Establish the connection.
			connection = DriverManager.getConnection(connectionString);

			// Define the SQL string.
			StringBuffer sb = new StringBuffer();

			sb.append(" select A.CommandId,A.CloudUtcDateTime,F.ModemUtcDateTime,D.Esn, ");
			sb.append(" G.CommandResponseName,A.CloudMessageId,A.CorrelationId,A.AppCorrelationId,A.Payload, ");
			sb.append(" B.CommandName, ");
			sb.append(" C.CommandStatusName, ");
			sb.append(" D.Vin, D.ActiveFrom, D.ActiveTo, ");
			sb.append(" E.Email, E.LoginName, ");
			sb.append(" F.TcuMessageId,F.CorrelationId, F.InCarHecTime ");
			sb.append(" from Command as A ");
			sb.append(" join CommandType as B on A.CommandTypeId = B.CommandTypeId ");
			sb.append(" join CommandStatus as C on A.CommandStatusId = C.CommandStatusId ");
			sb.append(" join TcuVehicle as D on A.TcuVehicleId = D.TcuVehicleId ");
			sb.append(" join [User] as E on A.UserId = E.UserID ");
			sb.append(" join [CommandResponse] as F on A.CommandId = F.CommandId ");
			sb.append(" join CommandResponseType as G on F.CommandResponseTypeId = G.CommandResponseTypeId ");
			sb.append(" where esn = ? ");
			sb.append(" order by A.CommandId desc ");
			
			pstatement = connection.prepareStatement(sb.toString());
			pstatement.setString(1, esn);

			resultSet = pstatement.executeQuery();
			
			while (resultSet.next()) {
				
				CommandEntity entity = new CommandEntity();
				entity.setCommandId(resultSet.getString("CommandId"));
				entity.setCloudUtcDateTime(resultSet.getDate("CloudUtcDateTime"));
				entity.setModemUtcDateTime(resultSet.getDate("ModemUtcDateTime"));
				entity.setEsn(resultSet.getString("Esn"));
				entity.setCommandResponseName(resultSet.getString("CommandResponseName"));
				entity.setCommandStatusName(resultSet.getString("CommandStatusName"));
				entity.setVin(resultSet.getString("Vin"));
				entity.setActiveFrom(resultSet.getDate("ActiveFrom"));
				entity.setActiveTo(resultSet.getDate("ActiveTo"));
				entity.setEmail(resultSet.getString("Email"));
				entity.setLoginName(resultSet.getString("LoginName"));
				entity.setTcuMessageId(resultSet.getString("TcuMessageId"));
				entity.setCorrelationId(resultSet.getString("CorrelationId"));
				entity.setInCarHecTime(resultSet.getDate("InCarHecTime"));
				commands.add(entity);
			}

		}
		// Exception handling
		catch (ClassNotFoundException cnfe) {

			System.out.println("ClassNotFoundException " + cnfe.getMessage());
		} catch (Exception e) {
			System.out.println("Exception " + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				// Close resources.
				if (null != connection)
					connection.close();
				if (null != pstatement)
					pstatement.close();
				if (null != resultSet)
					resultSet.close();
			} catch (SQLException sqlException) {
				// No additional action if close() statements fail.
			}
		}

	}

}