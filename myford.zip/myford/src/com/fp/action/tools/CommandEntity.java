package com.fp.action.tools;
import java.util.Date;

public class CommandEntity {
	private Date createdDate;
	private Date lastModifiedDate;
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public int getCommandDiff() {
		return commandDiff;
	}
	public void setCommandDiff(int commandDiff) {
		this.commandDiff = commandDiff;
	}
	private int commandDiff;
	private String commandId;
	private Date modemUtcDateTime;
	public Date getModemUtcDateTime() {
		return modemUtcDateTime;
	}
	public void setModemUtcDateTime(Date modemUtcDateTime) {
		this.modemUtcDateTime = modemUtcDateTime;
	}
	public String getCommandId() {
		return commandId;
	}
	public void setCommandId(String commandId) {
		this.commandId = commandId;
	}
	public Date getCloudUtcDateTime() {
		return cloudUtcDateTime;
	}
	public void setCloudUtcDateTime(Date cloudUtcDateTime) {
		this.cloudUtcDateTime = cloudUtcDateTime;
	}
	public String getEsn() {
		return esn;
	}
	public void setEsn(String esn) {
		this.esn = esn;
	}
	public String getCommandResponseName() {
		return commandResponseName;
	}
	public void setCommandResponseName(String commandResponseName) {
		this.commandResponseName = commandResponseName;
	}
	public String getPayload() {
		return payload;
	}
	public void setPayload(String payload) {
		this.payload = payload;
	}
	public String getDecodedPayload() {
		return decodedPayload;
	}
	public void setDecodedPayload(String decodedPayload) {
		this.decodedPayload = decodedPayload;
	}
	public String getCommandName() {
		return commandName;
	}
	public void setCommandName(String commandName) {
		this.commandName = commandName;
	}
	public String getCommandStatusName() {
		return commandStatusName;
	}
	public void setCommandStatusName(String commandStatusName) {
		this.commandStatusName = commandStatusName;
	}
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public Date getActiveFrom() {
		return activeFrom;
	}
	public void setActiveFrom(Date activeFrom) {
		this.activeFrom = activeFrom;
	}
	public Date getActiveTo() {
		return activeTo;
	}
	public void setActiveTo(Date activeTo) {
		this.activeTo = activeTo;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	private Date cloudUtcDateTime;
	private String esn;
	private String commandResponseName;
	
	private String payload;
	private String decodedPayload;
	private String commandName;
	private String commandStatusName;
	private String vin;
	private Date activeFrom;
	private Date activeTo;
	private String loginName;
	private String email;
	private String tcuMessageId;
	private String correlationId;
	private Date inCarHecTime;
	public Date getInCarHecTime() {
		return inCarHecTime;
	}
	public void setInCarHecTime(Date inCarHecTime) {
		this.inCarHecTime = inCarHecTime;
	}
	public String getCorrelationId() {
		return correlationId;
	}
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
	public String getTcuMessageId() {
		return tcuMessageId;
	}
	public void setTcuMessageId(String tcuMessageId) {
		this.tcuMessageId = tcuMessageId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}
