package com.fp.action;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts2.ServletActionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.fp.domain.RestLoginUserBean;
import com.fp.service.RestAPIService;
import com.opensymphony.xwork2.ActionSupport;

@Controller
@Scope("prototype")
public class MlmcAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	
	private String isExport;
	public String getIsExport() {
		return isExport;
	}

	public void setIsExport(String isExport) {
		this.isExport = isExport;
	}

	private String dtFrom;
	public String getDtFrom() {
		return dtFrom;
	}

	public void setDtFrom(String dtFrom) {
		this.dtFrom = dtFrom;
	}

	public String getDtTo() {
		return dtTo;
	}

	public void setDtTo(String dtTo) {
		this.dtTo = dtTo;
	}

	private String dtTo;
	
	private String apiName;
	
	public String getApiName() {
		return apiName;
	}

	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

	@Autowired
	private RestAPIService service;

	private int currentPage = 1;
	
	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	private int pageSize = 15;
	
	private int recordCount;
	
	private int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private List<RestLoginUserBean> performanceBeans;
	
	private RestLoginUserBean performanceBean;

	public RestLoginUserBean getPerformanceBean() {
		return performanceBean;
	}

	public void setPerformanceBean(RestLoginUserBean performanceBean) {
		this.performanceBean = performanceBean;
	}

	public List<RestLoginUserBean> getPerformanceBeans() {
		return performanceBeans;
	}

	public void setPerformanceBeans(List<RestLoginUserBean> performanceBeans) {
		this.performanceBeans = performanceBeans;
	}

	private List<Integer> layoutPageNums;
	public List<Integer> getLayoutPageNums() {
		return layoutPageNums;
	}

	public void setLayoutPageNums(List<Integer> layoutPageNums) {
		this.layoutPageNums = layoutPageNums;
	}

	private int pageCount;
	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	public String performance() {
		
		if(isExport != null && isExport.equals("yes")) {
			performanceBeans = service.selectPerformanceByPager(apiName, dtFrom, dtTo, 0, 0);
	    	createExcel(performanceBeans, ServletActionContext.getServletContext().getRealPath("/")+"upload\\performance.xls");
	        return "excel";  
		} else {
			performanceBeans = service.selectPerformanceByPager(apiName, dtFrom, dtTo, currentPage, pageSize);
			
			recordCount = service.getTotalCount(apiName, dtFrom, dtTo);
			
			layoutPageNums = new ArrayList<Integer>();
			
			pageCount = (recordCount+1)/pageSize;
			
			if (currentPage < 1) {
				currentPage = 1;
			} 
			if (currentPage > pageCount) {
				currentPage = pageCount;
			}
			
			/*int maxPageNum = (currentPage / 5 + 1) * 5;
			int minPageNum = (currentPage / 5) * 5;
			
			for (int i = minPageNum; i < maxPageNum; i++) {
				layoutPageNums.add(i);
			}*/
			
			if (currentPage == 1 || currentPage == 2) {
				layoutPageNums.add(1);
				layoutPageNums.add(2);
				layoutPageNums.add(3);
				layoutPageNums.add(4);
				layoutPageNums.add(5);
			}
	 		if (currentPage > 2 && currentPage <= pageCount-2) {
				layoutPageNums.add(currentPage-2);
				layoutPageNums.add(currentPage-1);
				layoutPageNums.add(currentPage);
				layoutPageNums.add(currentPage+1);
				layoutPageNums.add(currentPage+2);
			}
	 		
	 		if (currentPage == pageCount -1 || currentPage == pageCount) {
	 			layoutPageNums.add(pageCount-4);
				layoutPageNums.add(pageCount-3);
				layoutPageNums.add(pageCount-2);
				layoutPageNums.add(pageCount-1);
				layoutPageNums.add(pageCount);
	 		}
			
			return SUCCESS;
		}
	}
	
	public String performanceById() {
		performanceBean = service.selectPerformanceById(id);
		
		return SUCCESS;
	}
	
    public String export(){  
    	performanceBeans = service.selectPerformanceByPager("", "", "", 0, 0);
    	createExcel(performanceBeans, ServletActionContext.getServletContext().getRealPath("/")+"upload\\performance.xls");
        return "excel";  
    }  

    public InputStream getExcelStream() {  
    	ServletContext servletContext = ServletActionContext.getServletContext();
        return servletContext.getResourceAsStream("/upload/performance.xls");  
    }  
    
	private void createExcel(List<RestLoginUserBean> restList, String filePath) {
		// ��һ��������һ��webbook����Ӧһ��Excel�ļ�
		HSSFWorkbook wb = new HSSFWorkbook();

		// �ڶ�������webbook������һ��sheet,��ӦExcel�ļ��е�sheet
		HSSFSheet sheet = wb.createSheet("Data");
		// ����������sheet�����ӱ�ͷ��0��,ע���ϰ汾poi��Excel����������������short
		HSSFRow row = sheet.createRow((int) 0);

		row.createCell(0).setCellValue("Light House");
		row.createCell(1).setCellValue("SDN Login User");
		row.createCell(2).setCellValue("SDN Get User Profile");
		row.createCell(3).setCellValue("Total");
		row.createCell(4).setCellValue("API Name");
		row.createCell(5).setCellValue("Input Param");
		row.createCell(6).setCellValue("Result Description");
		row.createCell(7).setCellValue("Insert Date");
		row.createCell(8).setCellValue("Is Success");

		// ���Ĳ���������Ԫ�񣬲�����ֵ��ͷ ���ñ�ͷ����
		HSSFCellStyle style = wb.createCellStyle();
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // ����һ�����и�ʽ

		for (int i = 0; i < restList.size(); i++) {
			row = sheet.createRow((int) i + 1);
			RestLoginUserBean stu = restList.get(i);
			// ���Ĳ���������Ԫ�񣬲�����ֵ
				row.createCell(0).setCellValue(stu.getLightHouseCost());
				row.createCell(1).setCellValue(stu.getSdnLoginUserCost());
				row.createCell(2).setCellValue(stu.getSdnGetUserProfileCost());
				row.createCell(3).setCellValue(stu.getTotalCost());
				row.createCell(4).setCellValue(stu.getRestApiName());
				row.createCell(5).setCellValue(stu.getExeParam());
				if (stu.getStatusDesc() != null) {
					row.createCell(6).setCellValue(stu.getStatusDesc().length()> 30000 ? stu.getStatusDesc().substring(0, 30000) : stu.getStatusDesc());
				}
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				row.createCell(7).setCellValue(sdf.format(stu.getInsertDate()));
				row.createCell(8).setCellValue(stu.getOperationStatus());
		}
		// �����������ļ��浽ָ��λ��
		try {
			FileOutputStream fout = new FileOutputStream(filePath);
			wb.write(fout);
			fout.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
