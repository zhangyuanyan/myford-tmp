delimiter $$

CREATE TABLE `vehicle_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vin` varchar(45) DEFAULT NULL,
  `esn` varchar(45) DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `insert_date` datetime DEFAULT NULL,
  `GPS_Speed` int(11) DEFAULT NULL,
  `GPS_Compass_direction` int(11) DEFAULT NULL,
  `GPS_Heading` int(11) DEFAULT NULL,
  `GPS_actual_vs_infer_pos` int(11) DEFAULT '0',
  `Ignition_status` int(11) DEFAULT NULL,
  `Veh_V_ActlEng` int(11) DEFAULT NULL,
  `OdometerMasterValue` int(11) DEFAULT NULL,
  `FuelRange_L_Dsply` int(11) DEFAULT NULL,
  `GearLvrPos_D_Actl` int(11) DEFAULT NULL,
  `BpedDrvAppl_D_Actl` int(11) DEFAULT NULL,
  `ApedPos_Pc_ActlArb` int(11) DEFAULT NULL,
  `EngAout_N_Actl` int(11) DEFAULT NULL,
  `EngClnt_Te_Actl` int(11) DEFAULT NULL,
  `EngSrvcRqd_B_Rq` int(11) DEFAULT NULL,
  `FuelLvl_Pc_Dsply` int(11) DEFAULT NULL,
  `AirAmb_Te_ActlFilt` int(11) DEFAULT NULL,
  `PrplWhlTot2_Tq_Actl` int(11) DEFAULT NULL,
  `PwPckTq_D_Stat` int(11) DEFAULT NULL,
  `BSBattSOC` int(11) DEFAULT NULL,
  `BattTrac_U_Actl` int(11) DEFAULT NULL,
  `BattTrac_I_Actl` int(11) DEFAULT NULL,
  `BattTracSoc2_Pc_Actl` int(11) DEFAULT NULL,
  `BattTrac_Te_Actl` int(11) DEFAULT NULL,
  `VehStrtInhbt_B_RqBatt` int(11) DEFAULT NULL,
  `BattTracOff_B_Actl` int(11) DEFAULT NULL,
  `BattTrac_Pw_LimChrg` int(11) DEFAULT NULL,
  `BattTrac_Pw_LimDchrg` int(11) DEFAULT NULL,
  `BattTracOffFst_D_Actl` int(11) DEFAULT NULL,
  `BattTracWarnLamp_B_Rq` int(11) DEFAULT NULL,
  `BattTracSrvcRqd_B_Rq` int(11) DEFAULT NULL,
  `province` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8$$


CREATE  TABLE `fp`.`battery_fault` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `vin` VARCHAR(45) NULL ,
  `esn` VARCHAR(45) NULL ,
  `BattTrac_I_Actl` INT NULL ,
  `BattTracOff_B_Actl` INT NULL ,
  `BattTracOffFst_D_Actl` INT NULL ,
  `BattTrac_Pw_LimChrg` INT NULL ,
  `BattTrac_Pw_LimDchrg` INT NULL ,
  `BattTracSoc2_Pc_Actl` INT NULL ,
  `BattTrac_Te_Actl` INT NULL ,
  `BattTrac_U_Actl` INT NULL ,
  `VehStrtInhbt_B_RqBatt` INT NULL ,
  `dtc` VARCHAR(1000) NULL ,
  `insert_date` DATETIME NULL ,
  PRIMARY KEY (`id`) );

delimiter $$

CREATE TABLE `tcu_ftcp_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `record` varchar(5000) DEFAULT NULL,
  `insert_date` datetime DEFAULT NULL,
  `correlate_msg_id` int(11) DEFAULT NULL,
  `vin` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8$$

CREATE  TABLE `fp`.`tcu_vehicle` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `vin` VARCHAR(45) NULL ,
  `esn` VARCHAR(45) NULL ,
  `pskey` VARCHAR(100) NULL ,
  PRIMARY KEY (`id`) );
