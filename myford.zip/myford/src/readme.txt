-Login
	-isUserAlreadyExists() 快速登录

	